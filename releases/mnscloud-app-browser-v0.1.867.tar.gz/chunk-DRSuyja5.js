import {T}from'./chunk-iQKjp5MQ.js';import'./chunk-BgBTryGD.js';import {c as cn,k as ke,d as dn}from'./chunk-DojkFxg9.js';import'./chunk-BzSTWe_t.js';import {g,d as dt,B,F,A as Ae,q as qt,a as gT,e as V$1,b as qc,bp as it$1,bq as Cv,c as q,C as Cl,f as ii,h as je,k as V$2,y as yt,T as Tt,r as dt$1,m as yt$1,n as wt,L as Lt,R as Rt,W as W$1,K as Kt,s as Ss,E as Tm,x as iT,z as zb,D as xl,G as nb,X as XC,O as vm,M as XI,N as aT,U as Um,P as rb,Q as Pl,a0 as Ml,_ as JC,aS as Fn,aT as Pt,aV as GU,af as wt$1,b4 as Ve,aW as Cy,b0 as w,b8 as Xt,aY as je$1,ba as dS,bb as Rt$1,bc as cy,aX as ue,be as yt$2,bf as m,br as Ns,a_ as WT,bg as mb,H as Dm,bh as yb,a5 as wb,a9 as Fm,am as Km,a$ as xe,bs as q$1,bk as xi,bd as qT,al as Cm,aJ as Ob,bi as Nm,b2 as Db,b3 as Eb,a6 as ub,a3 as hb,ac as $m,bt as dp,a7 as Xf,a8 as Jf,aL as zm}from'./main-TWBBQLGX.js';import {L as Le,D as De}from'./chunk-Cu_T49z0.js';import'./chunk-DY7fUsYV.js';var $e=["switch"],Qe=["*"];function Ye(u,t){u&1&&(Ss(0,"span",11),dp(),Ss(1,"svg",13),Dm(2,"path",14),xl(),Ss(3,"svg",15),Dm(4,"path",16),xl()());}var Ze=new w("mat-slide-toggle-default-options",{providedIn:"root",factory:()=>({disableToggleValue:false,hideIcon:false,disabledInteractive:false})}),V=class{source;checked;constructor(t,e){this.source=t,this.checked=e;}},W=(()=>{class u{_elementRef=g(wt$1);_focusMonitor=g(Ve);_changeDetectorRef=g(Cy);defaults=g(Ze);_onChange=e=>{};_onTouched=()=>{};_validatorOnChange=()=>{};_uniqueId;_checked=false;_createChangeEvent(e){return new V(this,e)}_labelId;get buttonId(){return `${this.id||this._uniqueId}-button`}_switchElement;focus(){this._switchElement.nativeElement.focus();}_noopAnimations=Xt();_focused=false;name=null;id;labelPosition="after";ariaLabel=null;ariaLabelledby=null;ariaDescribedby;required=false;color;disabled=false;disableRipple=false;tabIndex=0;get checked(){return this._checked}set checked(e){this._checked=e,this._changeDetectorRef.markForCheck();}hideIcon;disabledInteractive;change=new je$1;toggleChange=new je$1;get inputId(){return `${this.id||this._uniqueId}-input`}constructor(){g(dS).load(Rt$1);let e=g(new cy("tabindex"),{optional:true}),i=this.defaults;this.tabIndex=e==null?0:parseInt(e)||0,this.color=i.color||"accent",this.id=this._uniqueId=g(ue).getId("mat-mdc-slide-toggle-"),this.hideIcon=i.hideIcon??false,this.disabledInteractive=i.disabledInteractive??false,this._labelId=this._uniqueId+"-label";}ngAfterContentInit(){this._focusMonitor.monitor(this._elementRef,true).subscribe(e=>{e==="keyboard"||e==="program"?(this._focused=true,this._changeDetectorRef.markForCheck()):e||Promise.resolve().then(()=>{this._focused=false,this._onTouched(),this._changeDetectorRef.markForCheck();});});}ngOnChanges(e){e.required&&this._validatorOnChange();}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef);}writeValue(e){this.checked=!!e;}registerOnChange(e){this._onChange=e;}registerOnTouched(e){this._onTouched=e;}validate(e){return this.required&&e.value!==true?{required:true}:null}registerOnValidatorChange(e){this._validatorOnChange=e;}setDisabledState(e){this.disabled=e,this._changeDetectorRef.markForCheck();}toggle(){this.checked=!this.checked,this._onChange(this.checked);}_emitChangeEvent(){this._onChange(this.checked),this.change.emit(this._createChangeEvent(this.checked));}_handleClick(){this.disabled||(this.toggleChange.emit(),this.defaults.disableToggleValue||(this.checked=!this.checked,this._onChange(this.checked),this.change.emit(new V(this,this.checked))));}_getAriaLabelledBy(){return this.ariaLabelledby?this.ariaLabelledby:this.ariaLabel?null:this._labelId}static \u0275fac=function(i){return new(i||u)};static \u0275cmp=Cl({type:u,selectors:[["mat-slide-toggle"]],viewQuery:function(i,a){if(i&1&&Nm($e,5),i&2){let o;Db(o=Eb())&&(a._switchElement=o.first);}},hostAttrs:[1,"mat-mdc-slide-toggle"],hostVars:13,hostBindings:function(i,a){i&2&&(Cm("id",a.id),Ml("tabindex",null)("aria-label",null)("name",null)("aria-labelledby",null),Ob(a.color?"mat-"+a.color:""),Fm("mat-mdc-slide-toggle-focused",a._focused)("mat-mdc-slide-toggle-checked",a.checked)("_mat-animation-noopable",a._noopAnimations));},inputs:{name:"name",id:"id",labelPosition:"labelPosition",ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],ariaDescribedby:[0,"aria-describedby","ariaDescribedby"],required:[2,"required","required",WT],color:"color",disabled:[2,"disabled","disabled",WT],disableRipple:[2,"disableRipple","disableRipple",WT],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?0:qT(e)],checked:[2,"checked","checked",WT],hideIcon:[2,"hideIcon","hideIcon",WT],disabledInteractive:[2,"disabledInteractive","disabledInteractive",WT]},outputs:{change:"change",toggleChange:"toggleChange"},exportAs:["matSlideToggle"],features:[Km([{provide:xe,useExisting:xi(()=>u),multi:true},{provide:q$1,useExisting:u,multi:true}]),Ns],ngContentSelectors:Qe,decls:14,vars:27,consts:[["switch",""],["mat-internal-form-field","",3,"labelPosition"],["role","switch","type","button",1,"mdc-switch",3,"click","tabIndex","disabled"],[1,"mat-mdc-slide-toggle-touch-target"],[1,"mdc-switch__track"],[1,"mdc-switch__handle-track"],[1,"mdc-switch__handle"],[1,"mdc-switch__shadow"],[1,"mdc-elevation-overlay"],[1,"mdc-switch__ripple"],["mat-ripple","",1,"mat-mdc-slide-toggle-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled","matRippleCentered"],[1,"mdc-switch__icons"],[1,"mdc-label",3,"click","for"],["viewBox","0 0 24 24","aria-hidden","true",1,"mdc-switch__icon","mdc-switch__icon--on"],["d","M19.69,5.23L8.96,15.96l-4.23-4.23L2.96,13.5l6,6L21.46,7L19.69,5.23z"],["viewBox","0 0 24 24","aria-hidden","true",1,"mdc-switch__icon","mdc-switch__icon--off"],["d","M20 13H4v-2h16v2z"]],template:function(i,a){if(i&1&&(mb(),Ss(0,"div",1)(1,"button",2,0),Tm("click",function(){return a._handleClick()}),Dm(3,"div",3)(4,"span",4),Ss(5,"span",5)(6,"span",6)(7,"span",7),Dm(8,"span",8),xl(),Ss(9,"span",9),Dm(10,"span",10),xl(),XC(11,Ye,5,0,"span",11),xl()()(),Ss(12,"label",12),Tm("click",function(y){return y.stopPropagation()}),yb(13),xl()()),i&2){let o=wb(2);vm("labelPosition",a.labelPosition),XI(),Fm("mdc-switch--selected",a.checked)("mdc-switch--unselected",!a.checked)("mdc-switch--checked",a.checked)("mdc-switch--disabled",a.disabled)("mat-mdc-slide-toggle-disabled-interactive",a.disabledInteractive),vm("tabIndex",a.disabled&&!a.disabledInteractive?-1:a.tabIndex)("disabled",a.disabled&&!a.disabledInteractive),Ml("id",a.buttonId)("name",a.name)("aria-label",a.ariaLabel)("aria-labelledby",a._getAriaLabelledBy())("aria-describedby",a.ariaDescribedby)("aria-required",a.required||null)("aria-checked",a.checked)("aria-disabled",a.disabled&&a.disabledInteractive?"true":null),XI(9),vm("matRippleTrigger",o)("matRippleDisabled",a.disableRipple||a.disabled)("matRippleCentered",true),XI(),JC(a.hideIcon?-1:11),XI(),vm("for",a.buttonId),Ml("id",a._labelId);}},dependencies:[yt$2,m],styles:[`.mdc-switch {
  align-items: center;
  background: none;
  border: none;
  cursor: pointer;
  display: inline-flex;
  flex-shrink: 0;
  margin: 0;
  outline: none;
  overflow: visible;
  padding: 0;
  position: relative;
  width: var(--mat-slide-toggle-track-width, 52px);
}
.mdc-switch.mdc-switch--disabled {
  cursor: default;
  pointer-events: none;
}
.mdc-switch.mat-mdc-slide-toggle-disabled-interactive {
  pointer-events: auto;
}

.mdc-switch__track {
  overflow: hidden;
  position: relative;
  width: 100%;
  height: var(--mat-slide-toggle-track-height, 32px);
  border-radius: var(--mat-slide-toggle-track-shape, var(--mat-sys-corner-full));
}
.mdc-switch--disabled.mdc-switch .mdc-switch__track {
  opacity: var(--mat-slide-toggle-disabled-track-opacity, 0.12);
}
.mdc-switch__track::before, .mdc-switch__track::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  height: 100%;
  left: 0;
  position: absolute;
  width: 100%;
  border-width: var(--mat-slide-toggle-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-track-outline-color, var(--mat-sys-outline));
}
.mdc-switch--selected .mdc-switch__track::before, .mdc-switch--selected .mdc-switch__track::after {
  border-width: var(--mat-slide-toggle-selected-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-selected-track-outline-color, transparent);
}
.mdc-switch--disabled .mdc-switch__track::before, .mdc-switch--disabled .mdc-switch__track::after {
  border-width: var(--mat-slide-toggle-disabled-unselected-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-disabled-unselected-track-outline-color, var(--mat-sys-on-surface));
}
@media (forced-colors: active) {
  .mdc-switch__track {
    border-color: currentColor;
  }
}
.mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0, 0, 0.2, 1);
  transform: translateX(0);
  background: var(--mat-slide-toggle-unselected-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch--selected .mdc-switch__track::before {
  transform: translateX(-100%);
}
.mdc-switch--selected .mdc-switch__track::before {
  opacity: var(--mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::before {
  opacity: var(--mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-hover-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-focus-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch:enabled:active .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-pressed-track-color, var(--mat-sys-surface-variant));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__track::before, .mdc-switch.mdc-switch--disabled .mdc-switch__track::before {
  background: var(--mat-slide-toggle-disabled-unselected-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch__track::after {
  transform: translateX(-100%);
  background: var(--mat-slide-toggle-selected-track-color, var(--mat-sys-primary));
}
[dir=rtl] .mdc-switch__track::after {
  transform: translateX(100%);
}
.mdc-switch--selected .mdc-switch__track::after {
  transform: translateX(0);
}
.mdc-switch--selected .mdc-switch__track::after {
  opacity: var(--mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::after {
  opacity: var(--mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-hover-track-color, var(--mat-sys-primary));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-focus-track-color, var(--mat-sys-primary));
}
.mdc-switch:enabled:active .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-pressed-track-color, var(--mat-sys-primary));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__track::after, .mdc-switch.mdc-switch--disabled .mdc-switch__track::after {
  background: var(--mat-slide-toggle-disabled-selected-track-color, var(--mat-sys-on-surface));
}

.mdc-switch__handle-track {
  height: 100%;
  pointer-events: none;
  position: absolute;
  top: 0;
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  left: 0;
  right: auto;
  transform: translateX(0);
  width: calc(100% - var(--mat-slide-toggle-handle-width));
}
[dir=rtl] .mdc-switch__handle-track {
  left: auto;
  right: 0;
}
.mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(-100%);
}

.mdc-switch__handle {
  display: flex;
  pointer-events: auto;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  left: 0;
  right: auto;
  transition: width 75ms cubic-bezier(0.4, 0, 0.2, 1), height 75ms cubic-bezier(0.4, 0, 0.2, 1), margin 75ms cubic-bezier(0.4, 0, 0.2, 1);
  width: var(--mat-slide-toggle-handle-width);
  height: var(--mat-slide-toggle-handle-height);
  border-radius: var(--mat-slide-toggle-handle-shape, var(--mat-sys-corner-full));
}
[dir=rtl] .mdc-switch__handle {
  left: auto;
  right: 0;
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle {
  width: var(--mat-slide-toggle-unselected-handle-size, 16px);
  height: var(--mat-slide-toggle-unselected-handle-size, 16px);
  margin: var(--mat-slide-toggle-unselected-handle-horizontal-margin, 0 8px);
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--mat-slide-toggle-unselected-with-icon-handle-horizontal-margin, 0 4px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle {
  width: var(--mat-slide-toggle-selected-handle-size, 24px);
  height: var(--mat-slide-toggle-selected-handle-size, 24px);
  margin: var(--mat-slide-toggle-selected-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--mat-slide-toggle-selected-with-icon-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch__handle:has(.mdc-switch__icons) {
  width: var(--mat-slide-toggle-with-icon-handle-size, 24px);
  height: var(--mat-slide-toggle-with-icon-handle-size, 24px);
}
.mat-mdc-slide-toggle .mdc-switch:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  width: var(--mat-slide-toggle-pressed-handle-size, 28px);
  height: var(--mat-slide-toggle-pressed-handle-size, 28px);
}
.mat-mdc-slide-toggle .mdc-switch--selected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--mat-slide-toggle-selected-pressed-handle-horizontal-margin, 0 22px);
}
.mat-mdc-slide-toggle .mdc-switch--unselected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--mat-slide-toggle-unselected-pressed-handle-horizontal-margin, 0 2px);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__handle::after {
  opacity: var(--mat-slide-toggle-disabled-selected-handle-opacity, 1);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__handle::after {
  opacity: var(--mat-slide-toggle-disabled-unselected-handle-opacity, 0.38);
}
.mdc-switch__handle::before, .mdc-switch__handle::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  width: 100%;
  height: 100%;
  left: 0;
  position: absolute;
  top: 0;
  transition: background-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1), border-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  z-index: -1;
}
@media (forced-colors: active) {
  .mdc-switch__handle::before, .mdc-switch__handle::after {
    border-color: currentColor;
  }
}
.mdc-switch--selected:enabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-handle-color, var(--mat-sys-on-primary));
}
.mdc-switch--selected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-hover-handle-color, var(--mat-sys-primary-container));
}
.mdc-switch--selected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-focus-handle-color, var(--mat-sys-primary-container));
}
.mdc-switch--selected:enabled:active .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-pressed-handle-color, var(--mat-sys-primary-container));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:hover:not(:focus):not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:focus:not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:active .mdc-switch__handle::after, .mdc-switch--selected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-disabled-selected-handle-color, var(--mat-sys-surface));
}
.mdc-switch--unselected:enabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-handle-color, var(--mat-sys-outline));
}
.mdc-switch--unselected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-hover-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-focus-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected:enabled:active .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-pressed-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-disabled-unselected-handle-color, var(--mat-sys-on-surface));
}
.mdc-switch__handle::before {
  background: var(--mat-slide-toggle-handle-surface-color);
}

.mdc-switch__shadow {
  border-radius: inherit;
  bottom: 0;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
}
.mdc-switch:enabled .mdc-switch__shadow {
  box-shadow: var(--mat-slide-toggle-handle-elevation-shadow);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__shadow, .mdc-switch.mdc-switch--disabled .mdc-switch__shadow {
  box-shadow: var(--mat-slide-toggle-disabled-handle-elevation-shadow);
}

.mdc-switch__ripple {
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  z-index: -1;
  width: var(--mat-slide-toggle-state-layer-size, 40px);
  height: var(--mat-slide-toggle-state-layer-size, 40px);
}
.mdc-switch__ripple::after {
  content: "";
  opacity: 0;
}
.mdc-switch--disabled .mdc-switch__ripple::after {
  display: none;
}
.mat-mdc-slide-toggle-disabled-interactive .mdc-switch__ripple::after {
  display: block;
}
.mdc-switch:hover .mdc-switch__ripple::after {
  transition: 75ms opacity cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:focus .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:active .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:hover:not(:focus) .mdc-switch__ripple::after, .mdc-switch--unselected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mdc-switch--unselected:enabled:focus .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mdc-switch--unselected:enabled:active .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-pressed-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}
.mdc-switch--selected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-hover-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mdc-switch--selected:enabled:focus .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-focus-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mdc-switch--selected:enabled:active .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-pressed-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}

.mdc-switch__icons {
  position: relative;
  height: 100%;
  width: 100%;
  z-index: 1;
  transform: translateZ(0);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__icons {
  opacity: var(--mat-slide-toggle-disabled-unselected-icon-opacity, 0.38);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__icons {
  opacity: var(--mat-slide-toggle-disabled-selected-icon-opacity, 0.38);
}

.mdc-switch__icon {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  opacity: 0;
  transition: opacity 30ms 0ms cubic-bezier(0.4, 0, 1, 1);
}
.mdc-switch--unselected .mdc-switch__icon {
  width: var(--mat-slide-toggle-unselected-icon-size, 16px);
  height: var(--mat-slide-toggle-unselected-icon-size, 16px);
  fill: var(--mat-slide-toggle-unselected-icon-color, var(--mat-sys-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--mat-slide-toggle-disabled-unselected-icon-color, var(--mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__icon {
  width: var(--mat-slide-toggle-selected-icon-size, 16px);
  height: var(--mat-slide-toggle-selected-icon-size, 16px);
  fill: var(--mat-slide-toggle-selected-icon-color, var(--mat-sys-on-primary-container));
}
.mdc-switch--selected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--mat-slide-toggle-disabled-selected-icon-color, var(--mat-sys-on-surface));
}

.mdc-switch--selected .mdc-switch__icon--on,
.mdc-switch--unselected .mdc-switch__icon--off {
  opacity: 1;
  transition: opacity 45ms 30ms cubic-bezier(0, 0, 0.2, 1);
}

.mat-mdc-slide-toggle {
  -webkit-user-select: none;
  user-select: none;
  display: inline-block;
  -webkit-tap-highlight-color: transparent;
  outline: 0;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple,
.mat-mdc-slide-toggle .mdc-switch__ripple::after {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple:not(:empty),
.mat-mdc-slide-toggle .mdc-switch__ripple::after:not(:empty) {
  transform: translateZ(0);
}
.mat-mdc-slide-toggle.mat-mdc-slide-toggle-focused .mat-focus-indicator::before {
  content: "";
}
.mat-mdc-slide-toggle .mat-internal-form-field {
  color: var(--mat-slide-toggle-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-slide-toggle-label-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-slide-toggle-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-slide-toggle-label-text-size, var(--mat-sys-body-medium-size));
  letter-spacing: var(--mat-slide-toggle-label-text-tracking, var(--mat-sys-body-medium-tracking));
  font-weight: var(--mat-slide-toggle-label-text-weight, var(--mat-sys-body-medium-weight));
}
.mat-mdc-slide-toggle .mat-ripple-element {
  opacity: 0.12;
}
.mat-mdc-slide-toggle .mat-focus-indicator::before {
  border-radius: 50%;
}
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle-track,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__icon,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::after,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::after {
  transition: none;
}
.mat-mdc-slide-toggle .mdc-switch:enabled + .mdc-label {
  cursor: pointer;
}
.mat-mdc-slide-toggle .mdc-switch--disabled + label {
  color: var(--mat-slide-toggle-disabled-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-slide-toggle label:empty {
  display: none;
}

.mat-mdc-slide-toggle-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--mat-slide-toggle-touch-target-size, 48px);
  width: 100%;
  transform: translate(-50%, -50%);
  display: var(--mat-slide-toggle-touch-target-display, block);
}
[dir=rtl] .mat-mdc-slide-toggle-touch-target {
  left: auto;
  right: 50%;
  transform: translate(50%, -50%);
}
`],encapsulation:2})}return u})(),We=(()=>{class u{static \u0275fac=function(i){return new(i||u)};static \u0275mod=Fn({type:u});static \u0275inj=Pt({imports:[W,GU]})}return u})();var et=(u,t)=>t.code,Xe=(u,t)=>t.HsaUUID;function tt(u,t){if(u&1&&(Ss(0,"mat-option",9),zb(1),iT(2,"transloco"),xl()),u&2){let e=t.$implicit;vm("value",e.code),XI(),Pl(" ",aT(2,2,e.labelKey)," ");}}function it(u,t){if(u&1&&(zb(0),iT(1,"transloco"),iT(2,"transloco")),u&2){let e=hb(2);zm(" ",aT(1,3,"SIAD Credentials Configured")," \xB7 ",aT(2,5,"Certificate expires"),": ",e.siadItem().credential?.certificateNotAfter," ");}}function at(u,t){u&1&&(zb(0),iT(1,"transloco")),u&2&&Pl(" ",aT(1,1,"SIAD Credentials Pending")," ");}function nt(u,t){if(u&1){let e=ub();Ss(0,"mat-tab",4),iT(1,"transloco"),Ss(2,"mat-tab-group",34)(3,"mat-tab",4),iT(4,"transloco"),Ss(5,"form",5)(6,"mat-form-field",35)(7,"mat-label"),zb(8),iT(9,"transloco"),xl(),Ss(10,"mat-select",29),Tm("selectionChange",function(a){Xf(e);let o=hb();return Jf(o.updateSiad({environment:a.value}))}),Ss(11,"mat-option",36),zb(12),iT(13,"transloco"),xl(),Ss(14,"mat-option",37),zb(15),iT(16,"transloco"),xl(),Ss(17,"mat-option",38),zb(18),iT(19,"transloco"),xl()()(),Ss(20,"mat-form-field",35)(21,"mat-label"),zb(22),iT(23,"transloco"),xl(),Ss(24,"input",39),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateSiad({origin:a.target.value}))}),xl()(),Ss(25,"mat-form-field",35)(26,"mat-label"),zb(27),iT(28,"transloco"),xl(),Ss(29,"input",39),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateSiad({suborigin:a.target.value}))}),xl()(),Ss(30,"mat-form-field",35)(31,"mat-label"),zb(32),iT(33,"transloco"),xl(),Ss(34,"input",40),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateSiad({referenciado:a.target.value}))}),xl()(),Ss(35,"mat-form-field",6)(36,"mat-label"),zb(37),iT(38,"transloco"),xl(),Ss(39,"input",41),iT(40,"transloco"),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateSiadCredentials({clientId:a.target.value}))}),xl()(),Ss(41,"mat-form-field",6)(42,"mat-label"),zb(43),iT(44,"transloco"),xl(),Ss(45,"input",42),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateSiadCredentials({clientSecret:a.target.value}))}),xl(),Ss(46,"button",16),iT(47,"transloco"),Tm("click",function(){Xf(e);let a=hb();return Jf(a.showSiadClientSecret.set(!a.showSiadClientSecret()))}),Ss(48,"mat-icon"),zb(49),xl()()(),Ss(50,"input",43,0),Tm("change",function(a){Xf(e);let o=hb();return Jf(o.selectSiadCertificate(a))}),xl(),Ss(52,"input",44,1),Tm("change",function(a){Xf(e);let o=hb();return Jf(o.selectSiadPrivateKey(a))}),xl(),Ss(54,"mat-form-field",6)(55,"mat-label"),zb(56),iT(57,"transloco"),xl(),Dm(58,"input",45),iT(59,"transloco"),Ss(60,"button",16),iT(61,"transloco"),Tm("click",function(){Xf(e);let a=wb(51);return Jf(a.click())}),Ss(62,"mat-icon"),zb(63,"upload_file"),xl()()(),Ss(64,"mat-form-field",6)(65,"mat-label"),zb(66),iT(67,"transloco"),xl(),Dm(68,"input",45),iT(69,"transloco"),Ss(70,"button",16),iT(71,"transloco"),Tm("click",function(){Xf(e);let a=wb(53);return Jf(a.click())}),Ss(72,"mat-icon"),zb(73,"upload_file"),xl()()(),Ss(74,"p",46),XC(75,it,3,7)(76,at,2,3),xl(),Ss(77,"div",11)(78,"mat-slide-toggle",12),Tm("change",function(a){Xf(e);let o=hb();return Jf(o.updateSiad({isActive:a.checked}))}),zb(79),iT(80,"transloco"),xl()()()()()();}if(u&2){let e=hb();vm("label",aT(1,32,"Bradesco")),XI(3),vm("label",aT(4,34,"SIAD")),XI(5),Um(aT(9,36,"SIAD Environment")),XI(2),vm("value",e.siadItem().environment),XI(2),Um(aT(13,38,"Development")),XI(3),Um(aT(16,40,"Homologation")),XI(3),Um(aT(19,42,"Production")),XI(4),Um(aT(23,44,"Origin")),XI(2),vm("value",e.siadItem().origin),XI(3),Um(aT(28,46,"Suborigin")),XI(2),vm("value",e.siadItem().suborigin),XI(3),Um(aT(33,48,"Referenced")),XI(2),vm("value",e.siadItem().referenciado),XI(3),Um(aT(38,50,"Client ID")),XI(2),vm("value",e.siadCredentials().clientId)("placeholder",e.siadItem().credentialsConfigured?aT(40,52,"Configured. Enter to replace."):""),XI(4),Um(aT(44,54,"Client Secret")),XI(2),vm("type",e.showSiadClientSecret()?"text":"password")("value",e.siadCredentials().clientSecret),XI(),Ml("aria-label",aT(47,56,"Toggle credential visibility")),XI(3),Um(e.showSiadClientSecret()?"visibility_off":"visibility"),XI(7),Um(aT(57,58,"mTLS Certificate")),XI(2),vm("value",e.siadCertificateFile()?.name??e.siadItem().credential?.certificateFilename??"")("placeholder",aT(59,60,"Select certificate file")),XI(2),Ml("aria-label",aT(61,62,"Select certificate file")),XI(6),Um(aT(67,64,"mTLS Private Key")),XI(2),vm("value",e.siadPrivateKeyFile()?.name??"")("placeholder",aT(69,66,"Select private key file")),XI(2),Ml("aria-label",aT(71,68,"Select private key file")),XI(5),JC(e.siadItem().credentialsConfigured&&e.siadItem().credential?75:76),XI(3),vm("checked",e.siadItem().isActive),XI(),Pl(" ",aT(80,70,"SIAD Integration Active")," ");}}function rt(u,t){if(u&1){let e=ub();Ss(0,"mat-tab",4),iT(1,"transloco"),Ss(2,"form",5)(3,"mat-form-field",14)(4,"mat-label"),zb(5),iT(6,"transloco"),xl(),Ss(7,"input",15),iT(8,"transloco"),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateItem({signalWireRepoToken:a.target.value}))}),xl(),Ss(9,"button",16),iT(10,"transloco"),Tm("click",function(){Xf(e);let a=hb();return Jf(a.showSignalWireRepoToken.set(!a.showSignalWireRepoToken()))}),Ss(11,"mat-icon"),zb(12),xl()()(),Ss(13,"div",11)(14,"mat-slide-toggle",12),Tm("change",function(a){Xf(e);let o=hb();return Jf(o.updateItem({signalWireRepoTokenIsActive:a.checked}))}),zb(15),iT(16,"transloco"),xl()()()();}if(u&2){let e=hb();vm("label",aT(1,9,"SignalWire")),XI(5),Um(aT(6,11,"SignalWire Repo Token")),XI(2),vm("type",e.showSignalWireRepoToken()?"text":"password")("placeholder",aT(8,13,"SignalWire repository token for FreeSWITCH packages"))("value",e.item().signalWireRepoToken),XI(2),Ml("aria-label",aT(10,15,e.showSignalWireRepoToken()?"Hide SignalWire token":"Show SignalWire token")),XI(3),Um(e.showSignalWireRepoToken()?"visibility_off":"visibility"),XI(2),vm("checked",e.item().signalWireRepoTokenIsActive),XI(),Pl(" ",aT(16,17,"SignalWire Repo Token Active")," ");}}function ot(u,t){if(u&1){let e=ub();Ss(0,"mat-tab",4),iT(1,"transloco"),Ss(2,"form",5)(3,"mat-form-field",20)(4,"mat-label"),zb(5),iT(6,"transloco"),xl(),Ss(7,"input",47),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateItem({billingSignupTrialAmount:a.target.value}))}),xl()(),Ss(8,"mat-form-field",20)(9,"mat-label"),zb(10),iT(11,"transloco"),xl(),Ss(12,"input",7),iT(13,"transloco"),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateItem({billingSignupTrialCurrency:a.target.value}))}),xl()(),Ss(14,"mat-form-field",20)(15,"mat-label"),zb(16),iT(17,"transloco"),xl(),Ss(18,"input",48),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateItem({billingSignupTrialExpiresDays:a.target.value}))}),xl()(),Ss(19,"mat-form-field",20)(20,"mat-label"),zb(21),iT(22,"transloco"),xl(),Ss(23,"input",49),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateItem({signupMaxAccountsPerIpDay:a.target.value}))}),xl()(),Ss(24,"mat-form-field",20)(25,"mat-label"),zb(26),iT(27,"transloco"),xl(),Ss(28,"input",50),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateItem({authSessionHours:a.target.value}))}),xl()(),Ss(29,"mat-form-field",20)(30,"mat-label"),zb(31),iT(32,"transloco"),xl(),Ss(33,"input",51),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateItem({authRememberMeHours:a.target.value}))}),xl()(),Ss(34,"mat-form-field",20)(35,"mat-label"),zb(36),iT(37,"transloco"),xl(),Ss(38,"mat-select",29),Tm("selectionChange",function(a){Xf(e);let o=hb();return Jf(o.updateItem({signupCaptchaProvider:a.value}))}),Ss(39,"mat-option",21),zb(40),iT(41,"transloco"),xl(),Ss(42,"mat-option",52),zb(43),iT(44,"transloco"),xl(),Ss(45,"mat-option",53),zb(46),iT(47,"transloco"),xl()()(),Ss(48,"mat-form-field",54)(49,"mat-label"),zb(50),iT(51,"transloco"),xl(),Ss(52,"input",10),iT(53,"transloco"),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateItem({signupCaptchaSiteKey:a.target.value}))}),xl()(),Ss(54,"mat-form-field",14)(55,"mat-label"),zb(56),iT(57,"transloco"),xl(),Ss(58,"input",15),iT(59,"transloco"),Tm("input",function(a){Xf(e);let o=hb();return Jf(o.updateItem({signupCaptchaSecret:a.target.value}))}),xl(),Ss(60,"button",16),iT(61,"transloco"),Tm("click",function(){Xf(e);let a=hb();return Jf(a.showSignupCaptchaSecret.set(!a.showSignupCaptchaSecret()))}),Ss(62,"mat-icon"),zb(63),xl()()(),Ss(64,"div",11)(65,"mat-slide-toggle",12),Tm("change",function(a){Xf(e);let o=hb();return Jf(o.updateItem({billingSignupTrialEnabled:a.checked}))}),zb(66),iT(67,"transloco"),xl(),Ss(68,"mat-slide-toggle",12),Tm("change",function(a){Xf(e);let o=hb();return Jf(o.updateItem({billingSignupTrialRequireEmailVerified:a.checked}))}),zb(69),iT(70,"transloco"),xl(),Ss(71,"mat-slide-toggle",12),Tm("change",function(a){Xf(e);let o=hb();return Jf(o.updateItem({signupCaptchaEnabled:a.checked}))}),zb(72),iT(73,"transloco"),xl(),Ss(74,"mat-slide-toggle",12),Tm("change",function(a){Xf(e);let o=hb();return Jf(o.updateItem({loginCaptchaEnabled:a.checked}))}),zb(75),iT(76,"transloco"),xl(),Ss(77,"mat-slide-toggle",12),Tm("change",function(a){Xf(e);let o=hb();return Jf(o.updateItem({authRememberMeEnabled:a.checked}))}),zb(78),iT(79,"transloco"),xl()()()();}if(u&2){let e=hb();vm("label",aT(1,38,"Access")),XI(5),Um(aT(6,40,"Trial Credit Amount")),XI(2),vm("value",e.item().billingSignupTrialAmount),XI(3),Um(aT(11,42,"Trial Credit Currency")),XI(2),vm("placeholder",aT(13,44,"BRL"))("value",e.item().billingSignupTrialCurrency),XI(4),Um(aT(17,46,"Trial Expires Days")),XI(2),vm("value",e.item().billingSignupTrialExpiresDays),XI(3),Um(aT(22,48,"Max Accounts per IP/Day")),XI(2),vm("value",e.item().signupMaxAccountsPerIpDay),XI(3),Um(aT(27,50,"Session Hours")),XI(2),vm("value",e.item().authSessionHours),XI(3),Um(aT(32,52,"Remember Me Hours")),XI(2),vm("value",e.item().authRememberMeHours),XI(3),Um(aT(37,54,"Captcha Provider")),XI(2),vm("value",e.item().signupCaptchaProvider),XI(2),Um(aT(41,56,"None")),XI(3),Um(aT(44,58,"Cloudflare Turnstile")),XI(3),Um(aT(47,60,"hCaptcha")),XI(4),Um(aT(51,62,"Captcha Site Key")),XI(2),vm("placeholder",aT(53,64,"Public site key"))("value",e.item().signupCaptchaSiteKey),XI(4),Um(aT(57,66,"Captcha Secret")),XI(2),vm("type",e.showSignupCaptchaSecret()?"text":"password")("placeholder",aT(59,68,"Private validation secret"))("value",e.item().signupCaptchaSecret),XI(2),Ml("aria-label",aT(61,70,e.showSignupCaptchaSecret()?"Hide captcha secret":"Show captcha secret")),XI(3),Um(e.showSignupCaptchaSecret()?"visibility_off":"visibility"),XI(2),vm("checked",e.item().billingSignupTrialEnabled),XI(),Pl(" ",aT(67,72,"Trial Credit Active")," "),XI(2),vm("checked",e.item().billingSignupTrialRequireEmailVerified),XI(),Pl(" ",aT(70,74,"Require Verified Email")," "),XI(2),vm("checked",e.item().signupCaptchaEnabled),XI(),Pl(" ",aT(73,76,"Signup Captcha Active")," "),XI(2),vm("checked",e.item().loginCaptchaEnabled),XI(),Pl(" ",aT(76,78,"Login Captcha Active")," "),XI(2),vm("checked",e.item().authRememberMeEnabled),XI(),Pl(" ",aT(79,80,"Remember Me Active")," ");}}function lt(u,t){if(u&1&&(Ss(0,"mat-option",9),zb(1),xl()),u&2){let e=t.$implicit;vm("value",e.HsaUUID),XI(),$m(" ",e.HsaName," \xB7 ",e.HspProvider||e.HspName," ");}}function st(u,t){if(u&1&&(Ss(0,"mat-option",9),zb(1),xl()),u&2){let e=t.$implicit;vm("value",e.HsaUUID),XI(),$m(" ",e.HsaName," \xB7 ",e.HspProvider||e.HspName," ");}}var X={environment:"dsv",origin:"",suborigin:"",referenciado:"",isActive:false,credentialsConfigured:false,credentialsUpdatedAt:null,credential:null},z={clientId:"",clientSecret:""},A={sprUUID:null,googleMapsEmbedApiKey:"",googleMapsEmbedApiKeyIsActive:true,mapboxToken:"",mapboxTokenIsActive:true,signalWireRepoToken:"",signalWireRepoTokenIsActive:true,defaultCurrency:"BRL",defaultCurrencyIsActive:true,defaultLanguage:"pt-BR",defaultLanguageIsActive:true,defaultTimezone:"",defaultTimezoneIsActive:true,voipPabxRecordingStorageMode:"",voipPabxRecordingStorageAccountUUID:"",voipPabxRecordingStorageIsActive:true,voipPabxMediaStorageMode:"",voipPabxMediaStorageAccountUUID:"",voipPabxMediaStorageIsActive:true,voipPabxMediaDeliveryMode:"",voipPabxMediaDeliveryModeIsActive:true,voipPabxRemoteCommandExecutor:"",voipPabxRemoteCommandExecutorIsActive:true,voipPabxAutoDomainEnabled:true,voipPabxAutoDomainBase:"pabx.publichost.cloud",voipPabxAutoDomainLabelMode:"uuid_short",voipPabxAutoDomainUuidLength:12,voipPabxAutoDomainSetDefault:true,voipPabxAutoDomainDnsMode:"identity_only",voipPabxAutoDomainIsActive:true,billingSignupTrialEnabled:false,billingSignupTrialAmount:0,billingSignupTrialCurrency:"BRL",billingSignupTrialExpiresDays:15,billingSignupTrialRequireEmailVerified:true,signupCaptchaEnabled:false,signupCaptchaProvider:"",signupCaptchaSiteKey:"",signupCaptchaSecret:"",signupMaxAccountsPerIpDay:3,loginCaptchaEnabled:false,authRememberMeEnabled:true,authSessionHours:12,authRememberMeHours:720},Ge=class u{api=g(dt);route=g(B);i18n=g(F);scope=Ae(this.route.snapshot.data?.scope??"tenant");isMaster=qt(()=>this.scope()==="master");pageTitle=qt(()=>this.isMaster()?"System Parameters":"Parameters");pageSubtitle=qt(()=>this.isMaster()?"Single master record with global default values.":"Single tenant record. Empty tenant values fallback to master defaults.");defaultTimezonePlaceholder=qt(()=>this.isMaster()?"UTC":"Master timezone");voipPabxRecordingStoragePlaceholder=qt(()=>this.isMaster()?"Filesystem":"Master recording storage");voipPabxMediaStoragePlaceholder=qt(()=>this.isMaster()?"Filesystem":"Master media file storage");voipPabxMediaDeliveryPlaceholder=qt(()=>this.isMaster()?"Offline":"Master media file delivery");voipPabxRemoteCommandExecutorPlaceholder=qt(()=>this.isMaster()?"Agent":"Master remote command executor");voipPabxAutoDomainBasePlaceholder=qt(()=>this.isMaster()?"pabx.publichost.cloud":"Master PABX SIP realm base");baseEndpoint=qt(()=>this.isMaster()?"system/parameters":"settings/parameters");languageOptions=this.i18n.availableLanguages;parametersResource=gT({params:()=>({endpoint:this.baseEndpoint(),isMaster:this.isMaster()}),defaultValue:{item:V$1({},A),storageAccounts:[]},loader:({params:t})=>this.loadParametersSnapshot(t.endpoint,t.isMaster)});siadResource=gT({params:()=>this.isMaster()?void 0:true,defaultValue:V$1({},X),loader:()=>this.loadSiad()});loading=qt(()=>this.parametersResource.isLoading()||!this.isMaster()&&this.siadResource.isLoading());saving=Ae(false);feedback=Ae(null);success=Ae(null);showGoogleMapsEmbedApiKey=Ae(false);showMapboxToken=Ae(false);showSignalWireRepoToken=Ae(false);showSignupCaptchaSecret=Ae(false);item=Ae(V$1({},A));baselineItem=Ae(V$1({},A));storageAccounts=Ae([]);baselineSignature=Ae("");siadItem=Ae(V$1({},X));baselineSiad=Ae(V$1({},X));siadCredentials=Ae(V$1({},z));siadCertificateFile=Ae(null);siadPrivateKeyFile=Ae(null);baselineSiadSignature=Ae("");showSiadClientSecret=Ae(false);showSiadPrivateKey=Ae(false);hasChanges=qt(()=>this.buildSignature(this.item())!==this.baselineSignature()||!this.isMaster()&&this.buildSiadSignature(this.siadItem())!==this.baselineSiadSignature()||!this.isMaster()&&Object.values(this.siadCredentials()).some(t=>t.trim()!==""));constructor(){qc(()=>{let t=this.parametersResource.hasValue()?this.parametersResource.value():void 0;t&&(this.storageAccounts.set(t.storageAccounts),this.item.set(t.item),this.baselineItem.set(V$1({},t.item)),this.baselineSignature.set(this.buildSignature(t.item)));}),qc(()=>{if(this.isMaster()||!this.siadResource.hasValue())return;let t=this.siadResource.value();this.siadItem.set(t),this.baselineSiad.set(V$1({},t)),this.baselineSiadSignature.set(this.buildSiadSignature(t)),this.siadCredentials.set(V$1({},z));}),qc(()=>{let t=this.parametersResource.error();t&&(this.feedback.set(this.friendlyError(t,"Failed to load parameters.")),this.item.set(V$1({},A)),this.baselineItem.set(V$1({},A)),this.storageAccounts.set([]),this.baselineSignature.set(this.buildSignature(A)));}),qc(()=>{if(this.isMaster())return;let t=this.siadResource.error();t&&this.feedback.set(this.friendlyError(t,"Failed to load SIAD integration."));});}refreshItems(){this.hasChanges()||this.saving()||(this.feedback.set(null),this.success.set(null),this.parametersResource.reload(),this.isMaster()||this.siadResource.reload());}updateItem(t){this.item.set(V$1(V$1({},this.item()),t));}updateSiad(t){this.siadItem.set(V$1(V$1({},this.siadItem()),t));}updateSiadCredentials(t){this.siadCredentials.set(V$1(V$1({},this.siadCredentials()),t));}selectSiadCertificate(t){let e=t.target,i=e.files?.[0]??null;this.siadCertificateFile.set(i),e.value="";}selectSiadPrivateKey(t){let e=t.target,i=e.files?.[0]??null;this.siadPrivateKeyFile.set(i),e.value="";}cancelChanges(){this.item.set(V$1({},this.baselineItem())),this.siadItem.set(V$1({},this.baselineSiad())),this.siadCredentials.set(V$1({},z)),this.siadCertificateFile.set(null),this.siadPrivateKeyFile.set(null),this.feedback.set(null),this.success.set(null);}async saveAll(){if(!(!this.hasChanges()||this.saving()||this.loading())){this.saving.set(true),this.feedback.set(null),this.success.set(null);try{if(this.buildSignature(this.item())!==this.baselineSignature()){let e=this.normalizeForSave(this.item()),i=await this.api.put(this.baseEndpoint(),{item:e}),a=this.readItem(i);this.item.set(a),this.baselineItem.set(V$1({},a)),this.baselineSignature.set(this.buildSignature(a)),a.defaultLanguageIsActive&&it$1(a.defaultLanguage)&&this.i18n.applyResolvedSystemLanguage(a.defaultLanguage,!0);}if(!this.isMaster()){let e=this.buildSiadSignature(this.siadItem())!==this.baselineSiadSignature(),i=this.siadItem();if(e){let w=await this.api.put("settings/integrations/bradesco/siad",this.siadItem());i=this.readSiad(w);}let a=this.siadCertificateFile(),o=this.siadPrivateKeyFile();if(Object.values(this.siadCredentials()).some(w=>w.trim()!=="")||a||o){if(!a||!o)throw new Error("Select both the SIAD certificate and private key.");let w=new FormData;w.set("clientId",this.siadCredentials().clientId),w.set("clientSecret",this.siadCredentials().clientSecret),w.set("certificate",a,a.name),w.set("privateKey",o,o.name);let qe=await Cv(this.api.postFormWithProgress("settings/integrations/bradesco/siad/credentials",w));i=this.readSiad(qe.response);}this.siadItem.set(i),this.baselineSiad.set(V$1({},i)),this.baselineSiadSignature.set(this.buildSiadSignature(i)),this.siadCredentials.set(V$1({},z)),this.siadCertificateFile.set(null),this.siadPrivateKeyFile.set(null);}this.success.set("Parameters saved successfully.");}catch(t){this.feedback.set(this.friendlyError(t,"Failed to save parameters."));}finally{this.saving.set(false);}}}readItem(t){let e=t?.data?.item;if(e&&typeof e=="object")return this.normalizeIncoming(e);let i=Array.isArray(t?.data?.items)?t.data.items:[];return this.fromLegacyItems(i)}fromLegacyItems(t){let e=V$1({},A);for(let i of t){let a=String(i?.SprKey??"").toUpperCase(),o=i?.SprValue===null||i?.SprValue===void 0?"":String(i.SprValue),y=Number(i?.SprIsActive??1)===1;a==="GOOGLE_MAPS_EMBED_API_KEY"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.googleMapsEmbedApiKey=o,e.googleMapsEmbedApiKeyIsActive=y):a==="MAPBOX_TOKEN"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.mapboxToken=o,e.mapboxTokenIsActive=y):a==="SIGNALWIRE_REPO_TOKEN"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.signalWireRepoToken=o,e.signalWireRepoTokenIsActive=y):a==="DEFAULT_CURRENCY"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.defaultCurrency=o||"BRL",e.defaultCurrencyIsActive=y):a==="DEFAULT_LANGUAGE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.defaultLanguage=o||"pt-BR",e.defaultLanguageIsActive=y):a==="DEFAULT_TIMEZONE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.defaultTimezone=o,e.defaultTimezoneIsActive=y):a==="VOIP_PABX_RECORDING_STORAGE_MODE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxRecordingStorageMode=this.normalizeStorageMode(o),e.voipPabxRecordingStorageIsActive=y):a==="VOIP_PABX_RECORDING_STORAGE_ACCOUNT"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxRecordingStorageAccountUUID=o):a==="VOIP_PABX_MEDIA_STORAGE_MODE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxMediaStorageMode=this.normalizeStorageMode(o),e.voipPabxMediaStorageIsActive=y):a==="VOIP_PABX_MEDIA_STORAGE_ACCOUNT"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxMediaStorageAccountUUID=o):a==="VOIP_PABX_MEDIA_DELIVERY_MODE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxMediaDeliveryMode=this.normalizeDeliveryMode(o),e.voipPabxMediaDeliveryModeIsActive=y):a==="VOIP_PABX_REMOTE_COMMAND_EXECUTOR"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxRemoteCommandExecutor=this.normalizeRemoteCommandExecutor(o),e.voipPabxRemoteCommandExecutorIsActive=y):a==="VOIP_PABX_AUTO_DOMAIN_ENABLED"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainEnabled=o===""?true:Number(o)!==0):a==="VOIP_PABX_AUTO_DOMAIN_BASE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainBase=o||A.voipPabxAutoDomainBase):a==="VOIP_PABX_AUTO_DOMAIN_LABEL_MODE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainLabelMode=this.normalizePabxAutoDomainLabelMode(o)):a==="VOIP_PABX_AUTO_DOMAIN_UUID_LENGTH"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainUuidLength=this.clampInteger(o||12,8,32)):a==="VOIP_PABX_AUTO_DOMAIN_SET_DEFAULT"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainSetDefault=o===""?true:Number(o)!==0):a==="VOIP_PABX_AUTO_DOMAIN_DNS_MODE"&&(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainDnsMode=this.normalizePabxAutoDomainDnsMode(o),e.voipPabxAutoDomainIsActive=y);}return e}normalizeIncoming(t){return {sprUUID:typeof t?.sprUUID=="string"&&t.sprUUID.trim()?t.sprUUID:null,googleMapsEmbedApiKey:String(t?.googleMapsEmbedApiKey??""),googleMapsEmbedApiKeyIsActive:t?.googleMapsEmbedApiKeyIsActive!==false,mapboxToken:String(t?.mapboxToken??""),mapboxTokenIsActive:t?.mapboxTokenIsActive!==false,signalWireRepoToken:String(t?.signalWireRepoToken??""),signalWireRepoTokenIsActive:t?.signalWireRepoTokenIsActive!==false,defaultCurrency:String(t?.defaultCurrency??"BRL")||"BRL",defaultCurrencyIsActive:t?.defaultCurrencyIsActive!==false,defaultLanguage:String(t?.defaultLanguage??"pt-BR")||"pt-BR",defaultLanguageIsActive:t?.defaultLanguageIsActive!==false,defaultTimezone:String(t?.defaultTimezone??""),defaultTimezoneIsActive:t?.defaultTimezoneIsActive!==false,voipPabxRecordingStorageMode:this.normalizeStorageMode(t?.voipPabxRecordingStorageMode),voipPabxRecordingStorageAccountUUID:String(t?.voipPabxRecordingStorageAccountUUID??""),voipPabxRecordingStorageIsActive:t?.voipPabxRecordingStorageIsActive!==false,voipPabxMediaStorageMode:this.normalizeStorageMode(t?.voipPabxMediaStorageMode),voipPabxMediaStorageAccountUUID:String(t?.voipPabxMediaStorageAccountUUID??""),voipPabxMediaStorageIsActive:t?.voipPabxMediaStorageIsActive!==false,voipPabxMediaDeliveryMode:this.normalizeDeliveryMode(t?.voipPabxMediaDeliveryMode),voipPabxMediaDeliveryModeIsActive:t?.voipPabxMediaDeliveryModeIsActive!==false,voipPabxRemoteCommandExecutor:this.normalizeRemoteCommandExecutor(t?.voipPabxRemoteCommandExecutor),voipPabxRemoteCommandExecutorIsActive:t?.voipPabxRemoteCommandExecutorIsActive!==false,voipPabxAutoDomainEnabled:t?.voipPabxAutoDomainEnabled!==false,voipPabxAutoDomainBase:String(t?.voipPabxAutoDomainBase??A.voipPabxAutoDomainBase).trim()||A.voipPabxAutoDomainBase,voipPabxAutoDomainLabelMode:this.normalizePabxAutoDomainLabelMode(t?.voipPabxAutoDomainLabelMode),voipPabxAutoDomainUuidLength:this.clampInteger(t?.voipPabxAutoDomainUuidLength??12,8,32),voipPabxAutoDomainSetDefault:t?.voipPabxAutoDomainSetDefault!==false,voipPabxAutoDomainDnsMode:this.normalizePabxAutoDomainDnsMode(t?.voipPabxAutoDomainDnsMode),voipPabxAutoDomainIsActive:t?.voipPabxAutoDomainIsActive!==false,billingSignupTrialEnabled:t?.billingSignupTrialEnabled===true,billingSignupTrialAmount:this.normalizeNumber(t?.billingSignupTrialAmount,0),billingSignupTrialCurrency:String(t?.billingSignupTrialCurrency??"BRL")||"BRL",billingSignupTrialExpiresDays:this.normalizeInteger(t?.billingSignupTrialExpiresDays,15),billingSignupTrialRequireEmailVerified:t?.billingSignupTrialRequireEmailVerified!==false,signupCaptchaEnabled:t?.signupCaptchaEnabled===true,signupCaptchaProvider:this.normalizeCaptchaProvider(t?.signupCaptchaProvider),signupCaptchaSiteKey:String(t?.signupCaptchaSiteKey??""),signupCaptchaSecret:String(t?.signupCaptchaSecret??""),signupMaxAccountsPerIpDay:this.normalizeInteger(t?.signupMaxAccountsPerIpDay,3),loginCaptchaEnabled:t?.loginCaptchaEnabled===true,authRememberMeEnabled:t?.authRememberMeEnabled!==false,authSessionHours:this.normalizeInteger(t?.authSessionHours,12),authRememberMeHours:this.normalizeInteger(t?.authRememberMeHours,720)}}normalizeForSave(t){return q(V$1({},t),{googleMapsEmbedApiKey:t.googleMapsEmbedApiKey.trim(),mapboxToken:t.mapboxToken.trim(),signalWireRepoToken:this.isMaster()?t.signalWireRepoToken.trim():"",defaultCurrency:(t.defaultCurrency.trim()||"BRL").toUpperCase(),defaultLanguage:it$1(t.defaultLanguage)?t.defaultLanguage:"pt-BR",defaultTimezone:t.defaultTimezone.trim(),voipPabxRecordingStorageMode:t.voipPabxRecordingStorageMode,voipPabxRecordingStorageAccountUUID:t.voipPabxRecordingStorageMode==="storage"?t.voipPabxRecordingStorageAccountUUID:"",voipPabxMediaStorageMode:t.voipPabxMediaStorageMode,voipPabxMediaStorageAccountUUID:t.voipPabxMediaStorageMode==="storage"?t.voipPabxMediaStorageAccountUUID:"",voipPabxMediaDeliveryMode:t.voipPabxMediaDeliveryMode,voipPabxRemoteCommandExecutor:t.voipPabxRemoteCommandExecutor,voipPabxAutoDomainBase:t.voipPabxAutoDomainBase.trim().toLowerCase().replace(/^\.+|\.+$/g,"")||A.voipPabxAutoDomainBase,voipPabxAutoDomainLabelMode:this.normalizePabxAutoDomainLabelMode(t.voipPabxAutoDomainLabelMode),voipPabxAutoDomainUuidLength:this.clampInteger(t.voipPabxAutoDomainUuidLength,8,32),voipPabxAutoDomainDnsMode:this.normalizePabxAutoDomainDnsMode(t.voipPabxAutoDomainDnsMode),billingSignupTrialAmount:Math.max(Number(t.billingSignupTrialAmount||0),0),billingSignupTrialCurrency:(t.billingSignupTrialCurrency.trim()||"BRL").toUpperCase(),billingSignupTrialExpiresDays:this.clampInteger(t.billingSignupTrialExpiresDays,1,365),signupCaptchaProvider:t.signupCaptchaProvider,signupCaptchaSiteKey:t.signupCaptchaSiteKey.trim(),signupCaptchaSecret:t.signupCaptchaSecret.trim(),signupMaxAccountsPerIpDay:this.clampInteger(t.signupMaxAccountsPerIpDay,1,100),authSessionHours:this.clampInteger(t.authSessionHours,1,168),authRememberMeHours:this.clampInteger(t.authRememberMeHours,1,2160)})}buildSignature(t){return JSON.stringify({googleMapsEmbedApiKey:t.googleMapsEmbedApiKey,googleMapsEmbedApiKeyIsActive:t.googleMapsEmbedApiKeyIsActive,mapboxToken:t.mapboxToken,mapboxTokenIsActive:t.mapboxTokenIsActive,signalWireRepoToken:t.signalWireRepoToken,signalWireRepoTokenIsActive:t.signalWireRepoTokenIsActive,defaultCurrency:t.defaultCurrency,defaultCurrencyIsActive:t.defaultCurrencyIsActive,defaultLanguage:t.defaultLanguage,defaultLanguageIsActive:t.defaultLanguageIsActive,defaultTimezone:t.defaultTimezone,defaultTimezoneIsActive:t.defaultTimezoneIsActive,voipPabxRecordingStorageMode:t.voipPabxRecordingStorageMode,voipPabxRecordingStorageAccountUUID:t.voipPabxRecordingStorageAccountUUID,voipPabxRecordingStorageIsActive:t.voipPabxRecordingStorageIsActive,voipPabxMediaStorageMode:t.voipPabxMediaStorageMode,voipPabxMediaStorageAccountUUID:t.voipPabxMediaStorageAccountUUID,voipPabxMediaStorageIsActive:t.voipPabxMediaStorageIsActive,voipPabxMediaDeliveryMode:t.voipPabxMediaDeliveryMode,voipPabxMediaDeliveryModeIsActive:t.voipPabxMediaDeliveryModeIsActive,voipPabxRemoteCommandExecutor:t.voipPabxRemoteCommandExecutor,voipPabxRemoteCommandExecutorIsActive:t.voipPabxRemoteCommandExecutorIsActive,voipPabxAutoDomainEnabled:t.voipPabxAutoDomainEnabled,voipPabxAutoDomainBase:t.voipPabxAutoDomainBase,voipPabxAutoDomainLabelMode:t.voipPabxAutoDomainLabelMode,voipPabxAutoDomainUuidLength:t.voipPabxAutoDomainUuidLength,voipPabxAutoDomainSetDefault:t.voipPabxAutoDomainSetDefault,voipPabxAutoDomainDnsMode:t.voipPabxAutoDomainDnsMode,voipPabxAutoDomainIsActive:t.voipPabxAutoDomainIsActive,billingSignupTrialEnabled:t.billingSignupTrialEnabled,billingSignupTrialAmount:t.billingSignupTrialAmount,billingSignupTrialCurrency:t.billingSignupTrialCurrency,billingSignupTrialExpiresDays:t.billingSignupTrialExpiresDays,billingSignupTrialRequireEmailVerified:t.billingSignupTrialRequireEmailVerified,signupCaptchaEnabled:t.signupCaptchaEnabled,signupCaptchaProvider:t.signupCaptchaProvider,signupCaptchaSiteKey:t.signupCaptchaSiteKey,signupCaptchaSecret:t.signupCaptchaSecret,signupMaxAccountsPerIpDay:t.signupMaxAccountsPerIpDay,loginCaptchaEnabled:t.loginCaptchaEnabled,authRememberMeEnabled:t.authRememberMeEnabled,authSessionHours:t.authSessionHours,authRememberMeHours:t.authRememberMeHours})}buildSiadSignature(t){return JSON.stringify({environment:t.environment,origin:t.origin,suborigin:t.suborigin,referenciado:t.referenciado,isActive:t.isActive})}async loadSiad(){return this.readSiad(await this.api.get("settings/integrations/bradesco/siad"))}readSiad(t){let e=t?.data?.item??t?.item??t??{},i=String(e?.environment??"dsv").toLowerCase();return {environment:i==="hml"||i==="prd"?i:"dsv",origin:String(e?.origin??""),suborigin:String(e?.suborigin??""),referenciado:String(e?.referenciado??""),isActive:e?.isActive===true,credentialsConfigured:e?.credentialsConfigured===true,credentialsUpdatedAt:e?.credentialsUpdatedAt?String(e.credentialsUpdatedAt):null,credential:e?.credential&&typeof e.credential=="object"?{certificateFilename:String(e.credential.certificateFilename??""),certificateFingerprintSha256:String(e.credential.certificateFingerprintSha256??""),certificateNotAfter:String(e.credential.certificateNotAfter??"")}:null}}async loadParametersSnapshot(t,e){let[i,a]=await Promise.all([this.api.get(t),this.fetchStorageAccounts(e)]);return {item:this.readItem(i),storageAccounts:a}}async fetchStorageAccounts(t){let e=t?"system/hosting/storage/accounts":"hosting/storage/accounts";try{return (await this.api.get(e))?.data?.items??[]}catch{return []}}normalizeStorageMode(t){let e=String(t??"").trim().toLowerCase();return e==="filesystem"||e==="storage"?e:""}normalizeDeliveryMode(t){let e=String(t??"").trim().toLowerCase();return e==="online"||e==="offline"?e:""}normalizeRemoteCommandExecutor(t){let e=String(t??"").trim().toLowerCase();return e==="agent"||e==="esl_ami"?e:""}normalizePabxAutoDomainLabelMode(t){return "uuid_short"}normalizePabxAutoDomainDnsMode(t){return "identity_only"}normalizeCaptchaProvider(t){let e=String(t??"").trim().toLowerCase();return e==="turnstile"||e==="hcaptcha"?e:""}normalizeNumber(t,e){let i=Number(t);return Number.isFinite(i)?i:e}normalizeInteger(t,e){let i=Math.trunc(Number(t));return Number.isFinite(i)?i:e}clampInteger(t,e,i){let a=this.normalizeInteger(t,e);return Math.min(Math.max(a,e),i)}friendlyError(t,e){let i=t?.error?.error;if(typeof i=="string"&&i.trim())return i;let a=t?.message;return typeof a=="string"&&a.trim()?a:e}static \u0275fac=function(e){return new(e||u)};static \u0275cmp=Cl({type:u,selectors:[["app-settings-parameters"]],hostAttrs:[1,"app-fade-in-host"],decls:232,vars:240,consts:[["siadCertificateInput",""],["siadPrivateKeyInput",""],[3,"refresh","cancel","save","title","description","loading","saving","dirty","error","success"],[1,"form-tabs"],[3,"label"],[1,"tab-content","form-grid"],["appearance","outline",1,"span-2"],["matInput","","maxlength","3",3,"input","placeholder","value"],[3,"selectionChange","placeholder","value"],[3,"value"],["matInput","",3,"input","placeholder","value"],[1,"toggle-grid","span-4"],[3,"change","checked"],[1,"nested-tabs","integration-tabs"],["appearance","outline",1,"span-4"],["matInput","",3,"input","type","placeholder","value"],["mat-icon-button","","matSuffix","","type","button",3,"click"],[1,"nested-tabs"],[1,"tab-content","empty-tab"],[1,"nested-tabs","pabx-parameter-tabs"],["appearance","outline"],["value",""],["value","filesystem"],["value","storage"],[3,"selectionChange","disabled","value"],["value","online"],["value","offline"],["value","agent"],["value","esl_ami"],[3,"selectionChange","value"],["value","uuid_short"],["matInput","","type","number","min","8","max","32",3,"input","value"],["value","identity_only"],[1,"parameter-hint","span-4"],[1,"nested-tabs","siad-tabs"],["appearance","outline",1,"span-1"],["value","dsv"],["value","hml"],["value","prd"],["matInput","","maxlength","20",3,"input","value"],["matInput","","maxlength","10",3,"input","value"],["matInput","",3,"input","value","placeholder"],["matInput","",3,"input","type","value"],["type","file","hidden","","accept",".pem,.crt,.cer,application/x-pem-file",3,"change"],["type","file","hidden","","accept",".pem,.key,application/x-pem-file",3,"change"],["matInput","","readonly","",3,"value","placeholder"],[1,"integration-secret-state","span-4"],["matInput","","type","number","min","0","step","0.01",3,"input","value"],["matInput","","type","number","min","1","max","365",3,"input","value"],["matInput","","type","number","min","1","max","100",3,"input","value"],["matInput","","type","number","min","1","max","168",3,"input","value"],["matInput","","type","number","min","1","max","2160",3,"input","value"],["value","turnstile"],["value","hcaptcha"],["appearance","outline",1,"span-3"]],template:function(e,i){e&1&&(Ss(0,"mns-settings-page",2),Tm("refresh",function(){return i.refreshItems()})("cancel",function(){return i.cancelChanges()})("save",function(){return i.saveAll()}),Ss(1,"mat-tab-group",3)(2,"mat-tab",4),iT(3,"transloco"),Ss(4,"form",5)(5,"mat-form-field",6)(6,"mat-label"),zb(7),iT(8,"transloco"),xl(),Ss(9,"input",7),iT(10,"transloco"),Tm("input",function(o){return i.updateItem({defaultCurrency:o.target.value})}),xl()(),Ss(11,"mat-form-field",6)(12,"mat-label"),zb(13),iT(14,"transloco"),xl(),Ss(15,"mat-select",8),iT(16,"transloco"),Tm("selectionChange",function(o){return i.updateItem({defaultLanguage:o.value})}),nb(17,tt,3,4,"mat-option",9,et),xl()(),Ss(19,"mat-form-field",6)(20,"mat-label"),zb(21),iT(22,"transloco"),xl(),Ss(23,"input",10),Tm("input",function(o){return i.updateItem({defaultTimezone:o.target.value})}),xl()(),Ss(24,"div",11)(25,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({defaultCurrencyIsActive:o.checked})}),zb(26),iT(27,"transloco"),xl(),Ss(28,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({defaultLanguageIsActive:o.checked})}),zb(29),iT(30,"transloco"),xl(),Ss(31,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({defaultTimezoneIsActive:o.checked})}),zb(32),iT(33,"transloco"),xl()()()(),Ss(34,"mat-tab",4),iT(35,"transloco"),Ss(36,"mat-tab-group",13)(37,"mat-tab",4),iT(38,"transloco"),Ss(39,"form",5)(40,"mat-form-field",14)(41,"mat-label"),zb(42),iT(43,"transloco"),xl(),Ss(44,"input",15),iT(45,"transloco"),Tm("input",function(o){return i.updateItem({googleMapsEmbedApiKey:o.target.value})}),xl(),Ss(46,"button",16),iT(47,"transloco"),Tm("click",function(){return i.showGoogleMapsEmbedApiKey.set(!i.showGoogleMapsEmbedApiKey())}),Ss(48,"mat-icon"),zb(49),xl()()(),Ss(50,"div",11)(51,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({googleMapsEmbedApiKeyIsActive:o.checked})}),zb(52),iT(53,"transloco"),xl()()()(),Ss(54,"mat-tab",4),iT(55,"transloco"),Ss(56,"form",5)(57,"mat-form-field",14)(58,"mat-label"),zb(59),iT(60,"transloco"),xl(),Ss(61,"input",15),iT(62,"transloco"),Tm("input",function(o){return i.updateItem({mapboxToken:o.target.value})}),xl(),Ss(63,"button",16),iT(64,"transloco"),Tm("click",function(){return i.showMapboxToken.set(!i.showMapboxToken())}),Ss(65,"mat-icon"),zb(66),xl()()(),Ss(67,"div",11)(68,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({mapboxTokenIsActive:o.checked})}),zb(69),iT(70,"transloco"),xl()()()(),XC(71,nt,81,72,"mat-tab",4)(72,rt,17,19,"mat-tab",4),xl()(),XC(73,ot,80,82,"mat-tab",4),Ss(74,"mat-tab",4),iT(75,"transloco"),Ss(76,"mat-tab-group",17)(77,"mat-tab",4),iT(78,"transloco"),Ss(79,"div",18),zb(80),iT(81,"transloco"),xl()(),Ss(82,"mat-tab",4),iT(83,"transloco"),Ss(84,"div",18),zb(85),iT(86,"transloco"),xl()(),Ss(87,"mat-tab",4),iT(88,"transloco"),Ss(89,"mat-tab-group",19)(90,"mat-tab",4),iT(91,"transloco"),Ss(92,"form",5)(93,"mat-form-field",20)(94,"mat-label"),zb(95),iT(96,"transloco"),xl(),Ss(97,"mat-select",8),Tm("selectionChange",function(o){return i.updateItem({voipPabxRecordingStorageMode:o.value})}),Ss(98,"mat-option",21),zb(99),iT(100,"transloco"),xl(),Ss(101,"mat-option",22),zb(102),iT(103,"transloco"),xl(),Ss(104,"mat-option",23),zb(105),iT(106,"transloco"),xl()()(),Ss(107,"mat-form-field",6)(108,"mat-label"),zb(109),iT(110,"transloco"),xl(),Ss(111,"mat-select",24),Tm("selectionChange",function(o){return i.updateItem({voipPabxRecordingStorageAccountUUID:o.value})}),Ss(112,"mat-option",21),zb(113),iT(114,"transloco"),xl(),nb(115,lt,2,3,"mat-option",9,Xe),xl()(),Ss(117,"mat-form-field",20)(118,"mat-label"),zb(119),iT(120,"transloco"),xl(),Ss(121,"mat-select",8),Tm("selectionChange",function(o){return i.updateItem({voipPabxMediaStorageMode:o.value})}),Ss(122,"mat-option",21),zb(123),iT(124,"transloco"),xl(),Ss(125,"mat-option",22),zb(126),iT(127,"transloco"),xl(),Ss(128,"mat-option",23),zb(129),iT(130,"transloco"),xl()()(),Ss(131,"mat-form-field",6)(132,"mat-label"),zb(133),iT(134,"transloco"),xl(),Ss(135,"mat-select",24),Tm("selectionChange",function(o){return i.updateItem({voipPabxMediaStorageAccountUUID:o.value})}),Ss(136,"mat-option",21),zb(137),iT(138,"transloco"),xl(),nb(139,st,2,3,"mat-option",9,Xe),xl()(),Ss(141,"div",11)(142,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({voipPabxRecordingStorageIsActive:o.checked})}),zb(143),iT(144,"transloco"),xl(),Ss(145,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({voipPabxMediaStorageIsActive:o.checked})}),zb(146),iT(147,"transloco"),xl()()()(),Ss(148,"mat-tab",4),iT(149,"transloco"),Ss(150,"form",5)(151,"mat-form-field",20)(152,"mat-label"),zb(153),iT(154,"transloco"),xl(),Ss(155,"mat-select",8),Tm("selectionChange",function(o){return i.updateItem({voipPabxMediaDeliveryMode:o.value})}),Ss(156,"mat-option",21),zb(157),iT(158,"transloco"),xl(),Ss(159,"mat-option",25),zb(160),iT(161,"transloco"),xl(),Ss(162,"mat-option",26),zb(163),iT(164,"transloco"),xl()()(),Ss(165,"div",11)(166,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({voipPabxMediaDeliveryModeIsActive:o.checked})}),zb(167),iT(168,"transloco"),xl()()()(),Ss(169,"mat-tab",4),iT(170,"transloco"),Ss(171,"form",5)(172,"mat-form-field",20)(173,"mat-label"),zb(174),iT(175,"transloco"),xl(),Ss(176,"mat-select",8),Tm("selectionChange",function(o){return i.updateItem({voipPabxRemoteCommandExecutor:o.value})}),Ss(177,"mat-option",21),zb(178),iT(179,"transloco"),xl(),Ss(180,"mat-option",27),zb(181),iT(182,"transloco"),xl(),Ss(183,"mat-option",28),zb(184),iT(185,"transloco"),xl()()(),Ss(186,"div",11)(187,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({voipPabxRemoteCommandExecutorIsActive:o.checked})}),zb(188),iT(189,"transloco"),xl()()()(),Ss(190,"mat-tab",4),iT(191,"transloco"),Ss(192,"form",5)(193,"mat-form-field",6)(194,"mat-label"),zb(195),iT(196,"transloco"),xl(),Ss(197,"input",10),Tm("input",function(o){return i.updateItem({voipPabxAutoDomainBase:o.target.value})}),xl()(),Ss(198,"mat-form-field",20)(199,"mat-label"),zb(200),iT(201,"transloco"),xl(),Ss(202,"mat-select",29),Tm("selectionChange",function(o){return i.updateItem({voipPabxAutoDomainLabelMode:o.value})}),Ss(203,"mat-option",30),zb(204),iT(205,"transloco"),xl()()(),Ss(206,"mat-form-field",20)(207,"mat-label"),zb(208),iT(209,"transloco"),xl(),Ss(210,"input",31),Tm("input",function(o){return i.updateItem({voipPabxAutoDomainUuidLength:o.target.value})}),xl()(),Ss(211,"mat-form-field",20)(212,"mat-label"),zb(213),iT(214,"transloco"),xl(),Ss(215,"mat-select",29),Tm("selectionChange",function(o){return i.updateItem({voipPabxAutoDomainDnsMode:o.value})}),Ss(216,"mat-option",32),zb(217),iT(218,"transloco"),xl()()(),Ss(219,"div",33),zb(220),iT(221,"transloco"),xl(),Ss(222,"div",11)(223,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({voipPabxAutoDomainEnabled:o.checked})}),zb(224),iT(225,"transloco"),xl(),Ss(226,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({voipPabxAutoDomainSetDefault:o.checked})}),zb(227),iT(228,"transloco"),xl(),Ss(229,"mat-slide-toggle",12),Tm("change",function(o){return i.updateItem({voipPabxAutoDomainIsActive:o.checked})}),zb(230),iT(231,"transloco"),xl()()()()()()()()()()),e&2&&(vm("title",i.pageTitle())("description",i.pageSubtitle())("loading",i.loading())("saving",i.saving())("dirty",i.hasChanges())("error",i.feedback())("success",i.success()),XI(2),vm("label",aT(3,112,"Record")),XI(5),Um(aT(8,114,"Default Currency")),XI(2),vm("placeholder",aT(10,116,"BRL"))("value",i.item().defaultCurrency),XI(4),Um(aT(14,118,"Default Language")),XI(2),vm("placeholder",aT(16,120,"pt-BR"))("value",i.item().defaultLanguage),XI(2),rb(i.languageOptions),XI(4),Um(aT(22,122,"Default Timezone")),XI(2),vm("placeholder",i.defaultTimezonePlaceholder())("value",i.item().defaultTimezone),XI(2),vm("checked",i.item().defaultCurrencyIsActive),XI(),Pl(" ",aT(27,124,"Default Currency Active")," "),XI(2),vm("checked",i.item().defaultLanguageIsActive),XI(),Pl(" ",aT(30,126,"Default Language Active")," "),XI(2),vm("checked",i.item().defaultTimezoneIsActive),XI(),Pl(" ",aT(33,128,"Default Timezone Active")," "),XI(2),vm("label",aT(35,130,"Integrations")),XI(3),vm("label",aT(38,132,"Google")),XI(5),Um(aT(43,134,"Google Maps Embed API Key")),XI(2),vm("type",i.showGoogleMapsEmbedApiKey()?"text":"password")("placeholder",aT(45,136,"Google Maps Street View embed API key"))("value",i.item().googleMapsEmbedApiKey),XI(2),Ml("aria-label",aT(47,138,i.showGoogleMapsEmbedApiKey()?"Hide Google Maps key":"Show Google Maps key")),XI(3),Um(i.showGoogleMapsEmbedApiKey()?"visibility_off":"visibility"),XI(2),vm("checked",i.item().googleMapsEmbedApiKeyIsActive),XI(),Pl(" ",aT(53,140,"Google Maps Key Active")," "),XI(2),vm("label",aT(55,142,"Mapbox")),XI(5),Um(aT(60,144,"Mapbox Token")),XI(2),vm("type",i.showMapboxToken()?"text":"password")("placeholder",aT(62,146,"Mapbox public token"))("value",i.item().mapboxToken),XI(2),Ml("aria-label",aT(64,148,i.showMapboxToken()?"Hide Mapbox token":"Show Mapbox token")),XI(3),Um(i.showMapboxToken()?"visibility_off":"visibility"),XI(2),vm("checked",i.item().mapboxTokenIsActive),XI(),Pl(" ",aT(70,150,"Mapbox Token Active")," "),XI(2),JC(i.isMaster()?72:71),XI(2),JC(i.isMaster()?73:-1),XI(),vm("label",aT(75,152,"VoIP")),XI(3),vm("label",aT(78,154,"SBC")),XI(3),Um(aT(81,156,"No SBC defaults configured yet.")),XI(2),vm("label",aT(83,158,"Softswitch")),XI(3),Um(aT(86,160,"No softswitch defaults configured yet.")),XI(2),vm("label",aT(88,162,"PABX")),XI(3),vm("label",aT(91,164,"Storage")),XI(5),Um(aT(96,166,"Storage - Recording")),XI(2),vm("placeholder",i.voipPabxRecordingStoragePlaceholder())("value",i.item().voipPabxRecordingStorageMode),XI(2),Um(aT(100,168,"Default")),XI(3),Um(aT(103,170,"Filesystem")),XI(3),Um(aT(106,172,"Storage")),XI(4),Um(aT(110,174,"Recording storage account")),XI(2),vm("disabled",i.item().voipPabxRecordingStorageMode!=="storage")("value",i.item().voipPabxRecordingStorageAccountUUID),XI(2),Um(aT(114,176,"Default storage account")),XI(2),rb(i.storageAccounts()),XI(4),Um(aT(120,178,"Storage - Media File")),XI(2),vm("placeholder",i.voipPabxMediaStoragePlaceholder())("value",i.item().voipPabxMediaStorageMode),XI(2),Um(aT(124,180,"Default")),XI(3),Um(aT(127,182,"Filesystem")),XI(3),Um(aT(130,184,"Storage")),XI(4),Um(aT(134,186,"Media file storage account")),XI(2),vm("disabled",i.item().voipPabxMediaStorageMode!=="storage")("value",i.item().voipPabxMediaStorageAccountUUID),XI(2),Um(aT(138,188,"Default storage account")),XI(2),rb(i.storageAccounts()),XI(3),vm("checked",i.item().voipPabxRecordingStorageIsActive),XI(),Pl(" ",aT(144,190,"Recording Storage Active")," "),XI(2),vm("checked",i.item().voipPabxMediaStorageIsActive),XI(),Pl(" ",aT(147,192,"Media Storage Active")," "),XI(2),vm("label",aT(149,194,"Media")),XI(5),Um(aT(154,196,"Media File - Delivery Mode")),XI(2),vm("placeholder",i.voipPabxMediaDeliveryPlaceholder())("value",i.item().voipPabxMediaDeliveryMode),XI(2),Um(aT(158,198,"Default")),XI(3),Um(aT(161,200,"Online")),XI(3),Um(aT(164,202,"Offline")),XI(3),vm("checked",i.item().voipPabxMediaDeliveryModeIsActive),XI(),Pl(" ",aT(168,204,"Media Delivery Active")," "),XI(2),vm("label",aT(170,206,"Execution")),XI(5),Um(aT(175,208,"Remote Command Executor")),XI(2),vm("placeholder",i.voipPabxRemoteCommandExecutorPlaceholder())("value",i.item().voipPabxRemoteCommandExecutor),XI(2),Um(aT(179,210,"Default")),XI(3),Um(aT(182,212,"Agent")),XI(3),Um(aT(185,214,"ESL/AMI")),XI(3),vm("checked",i.item().voipPabxRemoteCommandExecutorIsActive),XI(),Pl(" ",aT(189,216,"Remote Command Active")," "),XI(2),vm("label",aT(191,218,"SIP Realm")),XI(5),Um(aT(196,220,"PABX SIP realm base")),XI(2),vm("placeholder",i.voipPabxAutoDomainBasePlaceholder())("value",i.item().voipPabxAutoDomainBase),XI(3),Um(aT(201,222,"PABX SIP realm label")),XI(2),vm("value",i.item().voipPabxAutoDomainLabelMode),XI(2),Um(aT(205,224,"Short UUID")),XI(4),Um(aT(209,226,"PABX SIP realm UUID length")),XI(2),vm("value",i.item().voipPabxAutoDomainUuidLength),XI(3),Um(aT(214,228,"PABX SIP realm DNS mode")),XI(2),vm("value",i.item().voipPabxAutoDomainDnsMode),XI(2),Um(aT(218,230,"Identity only")),XI(3),Pl(" ",aT(221,232,"PABX automatic SIP realms create VoIP domains only. DNS/hosting publication is intentionally not coupled to billing today.")," "),XI(3),vm("checked",i.item().voipPabxAutoDomainEnabled),XI(),Pl(" ",aT(225,234,"Create PABX SIP realm automatically")," "),XI(2),vm("checked",i.item().voipPabxAutoDomainSetDefault),XI(),Pl(" ",aT(228,236,"Set generated PABX SIP realm as default")," "),XI(2),vm("checked",i.item().voipPabxAutoDomainIsActive),XI(),Pl(" ",aT(231,238,"PABX SIP realm automation active")," "));},dependencies:[T,ii,je,V$2,yt,Le,De,Tt,dt$1,yt$1,wt,We,W,cn,ke,dn,Lt,Rt,W$1,Kt],styles:[`.integration-secret-state,.parameter-hint,.empty-tab{color:var(--mat-sys-color-on-surface-variant);font-size:.875rem;line-height:1.45}
`],encapsulation:2})};export{Ge as SettingsParametersPage};