import {bc as v,l,h,bh as fe,bk as $,bd as Sv,bl as Jo,eF as BA,bf as Ie,g as gd,bs as at,bt as Ve,bv as hz,br as BS,cA as bd,db as _y,U as UC,cC as wd,G as Ub,da as Ly,a1 as $C,a2 as Ed,aL as bT,ab as Py}from'./main-2UM3XJTC.js';var m=new v("CONFIGURABLE_CRUD_QUICK_CREATE"),t="platform.master.access",r={AiProviderAipUUID:{label:"Create AI provider",loadComponent:()=>import('./chunk-BtirkKgo.js').then(e=>e.AiProvidersPage),permission:"platform.ai.manage"},AuthenticationClusterAtcUUID:{label:"authentication.clusters",loadComponent:()=>import('./chunk-6SS2Besc.js').then(e=>e.AuthenticationClusterPage),permission:"platform.authentication.manage",routeData:{scope:"master"}},AuthenticationServerAtsUUID:{label:"authentication.servers",loadComponent:()=>import('./chunk-CwKaVIUP.js').then(e=>e.AuthenticationServerPage),permission:"platform.authentication.manage",routeData:{scope:"master"}},AuthenticationAccountAacUUID:{label:"authentication.accounts",loadComponent:()=>import('./chunk-DPrKEBh0.js').then(e=>e.AuthenticationAccountPage),permission:"tenant.authentication.write",routeData:{scope:"tenant"}},AuthenticationRateLimitArlUUID:{label:"authentication.rate-limits",loadComponent:()=>import('./chunk-Be_zZ7hj.js').then(e=>e.AuthenticationRateLimitPage),permission:"tenant.authentication.write",routeData:{scope:"tenant"}},AuthenticationProfileAapUUID:{label:"authentication.profiles",loadComponent:()=>import('./chunk-esC1q0Xy.js').then(e=>e.AuthenticationProfilePage),permission:"tenant.authentication.write",routeData:{scope:"tenant"}},AuthenticationNasAanUUID:{label:"authentication.network-devices",loadComponent:()=>import('./chunk-CkN2AV9X.js').then(e=>e.AuthenticationNasPage),permission:"tenant.authentication.write",routeData:{scope:"tenant"}},AuthenticationGroupAagUUID:{label:"authentication.groups",loadComponent:()=>import('./chunk-sPggp4gk.js').then(e=>e.AuthenticationGroupPage),permission:"tenant.authentication.write",routeData:{scope:"tenant"}},AuthenticationDomainAadUUID:{label:"authentication.domains",loadComponent:()=>import('./chunk-ThczTLwc.js').then(e=>e.AuthenticationDomainPage),permission:"tenant.authentication.write",routeData:{scope:"tenant"}},AuthenticationAccessAaxUUID:{label:"authentication.accesses",loadComponent:()=>import('./chunk-CeDvOZpp.js').then(e=>e.AuthenticationAccessPage),permission:"tenant.authentication.write",routeData:{scope:"tenant"}},CrmIndustryCinUUID:{label:"crm.title.industries",loadComponent:()=>import('./chunk-BC1SQ9ml.js').then(e=>e.CrmIndustryPage),permission:"tenant.crm.manage"},CrmSourceCsoUUID:{label:"crm.title.sources",loadComponent:()=>import('./chunk-C8JY06OM.js').then(e=>e.CrmSourcePage),permission:"tenant.crm.manage"},CrmLossReasonClrUUID:{label:"crm.title.loss-reasons",loadComponent:()=>import('./chunk-BvzUXOn8.js').then(e=>e.CrmLossReasonPage),permission:"tenant.crm.manage"},CrmPipelineCpiUUID:{label:"crm.title.pipelines",loadComponent:()=>import('./chunk-DmY4eIWt.js').then(e=>e.CrmPipelinePage),permission:"tenant.crm.manage"},CrmStageCstUUID:{label:"crm.title.stages",loadComponent:()=>import('./chunk-C2NThtyU.js').then(e=>e.CrmStagePage),permission:"tenant.crm.manage"},CrmAccountCacUUID:{label:"crm.title.accounts",loadComponent:()=>import('./chunk-CNQ1J-bd.js').then(e=>e.CrmAccountPage),permission:"tenant.crm.write"},CrmContactCcoUUID:{label:"crm.title.contacts",loadComponent:()=>import('./chunk-B1Bm8PoY.js').then(e=>e.CrmContactPage),permission:"tenant.crm.write"},CrmProductCprUUID:{label:"crm.title.products",loadComponent:()=>import('./chunk-DXZGZ01F.js').then(e=>e.CrmProductPage),permission:"tenant.crm.manage"},CrmLeadCleUUID:{label:"crm.title.leads",loadComponent:()=>import('./chunk-DQmbMVOm.js').then(e=>e.CrmLeadPage),permission:"tenant.crm.write"},CrmOpportunityCopUUID:{label:"crm.title.opportunities",loadComponent:()=>import('./chunk-C_bLaw6P.js').then(e=>e.CrmOpportunityPage),permission:"tenant.crm.write"},CrmActivityCatUUID:{label:"crm.title.activities",loadComponent:()=>import('./chunk-D-r5ePe9.js').then(e=>e.CrmActivityPage),permission:"tenant.crm.write"},CrmProposalCppUUID:{label:"crm.title.proposals",loadComponent:()=>import('./chunk-DOZDj-NS.js').then(e=>e.CrmProposalPage),permission:"tenant.crm.write"},CrmProposalItemCptUUID:{label:"crm.title.proposal-items",loadComponent:()=>import('./chunk-tIjYotl2.js').then(function(n){return n.c}).then(e=>e.CrmProposalItemPage),permission:"tenant.crm.write"},CrmHandoffChoUUID:{label:"crm.title.handoffs",loadComponent:()=>import('./chunk-CZ_0TIw_.js').then(e=>e.CrmHandoffPage),permission:"tenant.crm.write"},BillingPackageBpaUUID:{label:"Create package",loadComponent:()=>import('./chunk-B9EBD-Rl.js').then(e=>e.BillingSystemPackagesPage),permission:t},BillingPriceBpcUUID:{label:"Create price",loadComponent:()=>import('./chunk-D-rDLOjb.js').then(e=>e.BillingSystemPricesPage),permission:t},BillingProductBprUUID:{label:"Create product",loadComponent:()=>import('./chunk-D3wE6cG0.js').then(e=>e.BillingSystemProductsPage),permission:t},ClinicAgreementCagUUID:{label:"Create agreement",loadComponent:()=>import('./chunk-zwA-C0H7.js').then(e=>e.ClinicAgreementCatalogPage),routeData:{catalog:"agreements"}},ClinicAgreementPlanCapUUID:{label:"Create plan",loadComponent:()=>import('./chunk-zwA-C0H7.js').then(e=>e.ClinicAgreementCatalogPage),routeData:{catalog:"plans"}},ClinicProcedureCprUUID:{label:"Create procedure",loadComponent:()=>import('./chunk-zwA-C0H7.js').then(e=>e.ClinicAgreementCatalogPage),routeData:{catalog:"procedures"}},CustomerCusUUID:{label:"Create customer",loadComponent:()=>import('./chunk-CMpX6-Xv.js').then(e=>e.ErpCustomerPage)},CyberSecuritySecretAccountCxaUUID:{label:"Create secret account",loadComponent:()=>import('./chunk-BnMfaK7_.js').then(e=>e.CyberSecuritySecretAccountsPage)},CyberSecuritySecretServerCsrUUID:{label:"Create secret server",loadComponent:()=>import('./chunk-xvcn5l74.js').then(e=>e.CyberSecuritySecretServersPage),permission:t},CyberSecurityTrustedNodeCtnUUID:{label:"Create trusted node",loadComponent:()=>import('./chunk-CocGElao.js').then(e=>e.CyberSecurityTrustedNodesPage)},ErpCompanyComUUID:{label:"Create company",loadComponent:()=>import('./chunk-Cb-8aWQL.js').then(e=>e.ErpCompaniesPage)},ErpComplexEcxUUID:{label:"Create complex",loadComponent:()=>import('./chunk-CHAIOzHp.js').then(e=>e.ErpComplexPage)},ErpFinPayGatewayAccountEfgUUID:{label:"Create gateway account",loadComponent:()=>import('./chunk-B4IrVPh2.js').then(e=>e.FinancialPaymentGatewayPage)},ErpHrDepartmentEhdUUID:{label:"Create department",loadComponent:()=>import('./chunk-Bq-QwxzY.js').then(e=>e.ErpHumanResourcesDepartmentsPage)},ErpHrEmployeeEmpUUID:{label:"Create employee",loadComponent:()=>import('./chunk-C3S73rAp.js').then(e=>e.ErpHumanResourcesEmployeesPage)},ErpHrPositionEhpUUID:{label:"Create position",loadComponent:()=>import('./chunk-Bx_SWSof.js').then(e=>e.ErpHumanResourcesPositionsPage)},ErpSupplierSupUUID:{label:"Create supplier",loadComponent:()=>import('./chunk-0LAADxEZ.js').then(e=>e.ErpSupplierPage)},HostingDnsProviderHdpUUID:{label:"Create DNS provider",loadComponent:()=>import('./chunk-CnQWan6z.js').then(e=>e.HostingDnsProvidersPage)},HostingDnsRegisterHrgUUID:{label:"Create DNS register",loadComponent:()=>import('./chunk-Cb5C7SnS.js').then(e=>e.HostingDnsRegistersPage)},HostingSmtpAccountHsaUUID:{label:"Create SMTP account",loadComponent:()=>import('./chunk-u7FQ1PZD.js').then(e=>e.HostingSmtpAccountsPage)},HostingSmtpProviderHspUUID:{label:"Create SMTP provider",loadComponent:()=>import('./chunk-D-uk17qQ.js').then(e=>e.HostingSmtpProvidersPage)},HostingStorageAccountHsaUUID:{label:"Create storage account",loadComponent:()=>import('./chunk-Dpj4Z7Oc.js').then(e=>e.HostingStorageAccountsPage)},HostingStorageProviderHspUUID:{label:"Create storage provider",loadComponent:()=>import('./chunk-BGQ3nS_r.js').then(e=>e.HostingStorageProvidersPage),permission:t},HostingVpsContainerPlanHcnUUID:{label:"Create container plan",loadComponent:()=>import('./chunk-CHHq0W_4.js').then(e=>e.HostingVpsContainerPlansPage)},HostingVpsContainerProviderHcpUUID:{label:"Create container provider",loadComponent:()=>import('./chunk-DMvhkn52.js').then(e=>e.HostingVpsContainerProviderPage)},HostingVpsInstanceHviUUID:{label:"Create VPS instance",loadComponent:()=>import('./chunk-CJhzaYbl.js').then(e=>e.HostingVpsInstancesPage)},HostingVpsFirewallHvfUUID:{label:"Create firewall profile",loadComponent:()=>import('./chunk-DUmKSZGz.js').then(e=>e.HostingVpsFirewallsPage)},HostingVpsNetworkHvnUUID:{label:"Create private network",loadComponent:()=>import('./chunk-CjdxAtlT.js').then(e=>e.HostingVpsNetworksPage)},HostingVpsPlanHvpUUID:{label:"Create VPS plan",loadComponent:()=>import('./chunk-Csr5c6AL.js').then(e=>e.HostingVpsPlansPage),permission:t},HostingVpsProviderHvrUUID:{label:"Create VPS provider",loadComponent:()=>import('./chunk-Acpn6F0U.js').then(e=>e.HostingVpsProviderPage),permission:t},HostingWebhostDatabaseHwdUUID:{label:"Create database",loadComponent:()=>import('./chunk-BzGbc1TS.js').then(e=>e.HostingWebhostDatabasesPage),routeData:{databaseResource:"databases"}},HostingWebhostDatabaseUserHduUUID:{label:"Create database user",loadComponent:()=>import('./chunk-BzGbc1TS.js').then(e=>e.HostingWebhostDatabasesPage),routeData:{databaseResource:"database-users"}},HostingWebhostHostHwhUUID:{label:"Create host",loadComponent:()=>import('./chunk-BKju6jQZ.js').then(e=>e.HostingWebhostHostsPage)},HostingWebhostPlanHwlUUID:{label:"Create hosting plan",loadComponent:()=>import('./chunk-BMH4c7ZA.js').then(e=>e.HostingWebhostPlansPage),permission:t},HostingWebhostProviderHwpUUID:{label:"Create hosting provider",loadComponent:()=>import('./chunk-DrT_j5qZ.js').then(e=>e.HostingWebhostProvidersPage),permission:t},InfraGisAssetCategoryIacUUID:{label:"Create category",loadComponent:()=>import('./chunk-BK0aWf7I.js').then(e=>e.InfraGisManagementPage),routeData:{resource:"categories"}},InfraGisAssetStatusIgsUUID:{label:"Create asset status",loadComponent:()=>import('./chunk-BK0aWf7I.js').then(e=>e.InfraGisManagementPage),routeData:{resource:"statuses"}},InfraGisAssetTypeIgtUUID:{label:"Create asset type",loadComponent:()=>import('./chunk-BK0aWf7I.js').then(e=>e.InfraGisManagementPage),routeData:{resource:"asset-types"}},InfraGisLayerIglUUID:{label:"Create layer",loadComponent:()=>import('./chunk-BK0aWf7I.js').then(e=>e.InfraGisManagementPage),routeData:{resource:"layers"}},InfraGisProjectIprUUID:{label:"Create project",loadComponent:()=>import('./chunk-BK0aWf7I.js').then(e=>e.InfraGisManagementPage),routeData:{resource:"projects"}},IspPopIppUUID:{label:"Create POP",loadComponent:()=>import('./chunk-CsjeoVcM.js').then(e=>e.IspPopPage)},IspVendorIveUUID:{label:"Create vendor",loadComponent:()=>import('./chunk-C8uIx6gk.js').then(e=>e.IspVendorPage)},IspVendorModelIvmUUID:{label:"Create vendor model",loadComponent:()=>import('./chunk-B0fm0307.js').then(e=>e.IspVendorModelPage)},PayFeePlanPfpUUID:{label:"Create fee plan",loadComponent:()=>import('./chunk-D6xkWlFE.js').then(e=>e.SystemPayFeePlansPage),permission:t},RealtimeDomainRtdUUID:{label:"Create realtime domain",loadComponent:()=>import('./chunk-Dkc9a81G.js').then(e=>e.RealtimeDomainsPage),permission:t},RealtimeDomainTenantRtdUUID:{label:"Create realtime domain",loadComponent:()=>import('./chunk-Dkc9a81G.js').then(e=>e.RealtimeDomainsTenantPage)},RealtimeMediaDomainRmdUUID:{label:"Create media domain",loadComponent:()=>import('./chunk-u8dWzLv0.js').then(e=>e.RealtimeMediaDomainsPage),permission:t},RealtimeMediaServerRmsUUID:{label:"Create media server",loadComponent:()=>import('./chunk-u8dWzLv0.js').then(e=>e.RealtimeMediaServersPage),permission:t},RealtimeTurnServerRtsUUID:{label:"Create TURN server",loadComponent:()=>import('./chunk-Gm2Drl6J.js').then(e=>e.RealtimeTurnServersPage),permission:t},RealtimeWebRtcDomainRwdUUID:{label:"Create WebRTC domain",loadComponent:()=>import('./chunk-yp9XbwcY.js').then(e=>e.RealtimeWebRtcDomainsTenantPage)},RealtimeWebRtcServerRwsUUID:{label:"Create WebRTC server",loadComponent:()=>import('./chunk-yp9XbwcY.js').then(e=>e.RealtimeWebRtcServersPage),permission:t},SaleBrandSbrUUID:{label:"Create brand",loadComponent:()=>import('./chunk-B9oFnDo1.js').then(e=>e.SaleBrandPage)},SaleCategoryScaUUID:{label:"Create category",loadComponent:()=>import('./chunk-CqLbI3UD.js').then(e=>e.SaleCategoryPage)},SaleProductSprUUID:{label:"Create product",loadComponent:()=>import('./chunk-D86JRUFf.js').then(e=>e.SaleProductPage)},SaleStockTypeSstUUID:{label:"Create stock type",loadComponent:()=>import('./chunk-BbQoR7oz.js').then(e=>e.SaleStockTypePage)},SaleUnitSunUUID:{label:"Create unit",loadComponent:()=>import('./chunk-5Jo5sz6r.js').then(e=>e.SaleUnitPage)},SupportTicketPriorityStpUUID:{routeData:{supportDesk:"tenant"},label:"Create priority",loadComponent:()=>import('./chunk-nKxmhSEz.js').then(e=>e.SupportTicketPrioritiesPage)},SupportTeamStmUUID:{routeData:{supportDesk:"tenant"},label:"Create support team",loadComponent:()=>import('./chunk-Bp-IAQfw.js').then(e=>e.SupportTeamsPage)},SupportTicketTypeSttUUID:{routeData:{supportDesk:"tenant"},label:"Create ticket type",loadComponent:()=>import('./chunk-aI5jeIp6.js').then(e=>e.SupportTicketTypesPage)},SupportTicketChannelStcUUID:{routeData:{supportDesk:"tenant"},label:"Create origin",loadComponent:()=>import('./chunk-DwYnDXbw.js').then(e=>e.SupportTicketChannelsPage)},VoipBlacklistVbkUUID:{label:"Create blacklist",loadComponent:()=>import('./chunk-N3HDwHik.js').then(e=>e.VoipPabxBlacklistListPage)},VoipDidOperatorVdoUUID:{label:"Create operator",loadComponent:()=>import('./chunk-ChpJa1WI.js').then(e=>e.VoipDidOperatorPage),permission:t},VoipDidVddUUID:{label:"Create DID",loadComponent:()=>import('./chunk-SBSEmCPE.js').then(e=>e.VoipDidPage),permission:t},VoipDomainVdmUUID:{label:"Create VoIP domain",loadComponent:()=>import('./chunk-IkOnzwav.js').then(e=>e.VoipDomainPage)},VoipPabxAccountVpaUUID:{label:"Create PABX",loadComponent:()=>import('./chunk-D6xk-v8a.js').then(e=>e.VoipPabxAccountPage)},VoipPabxCustomVpcUUID:{label:"Create custom",loadComponent:()=>import('./chunk-B-Vyi-RA.js').then(e=>e.VoipPabxCustomPage)},VoipPabxDialPlanVdpUUID:{label:"Create dial plan",loadComponent:()=>import('./chunk-DwchMYfZ.js').then(e=>e.VoipPabxDialPlanPlanPage)},VoipPabxExtensionVpeUUID:{label:"Create extension",loadComponent:()=>import('./chunk-CXfWa_am.js').then(e=>e.VoipPabxExtensionPage)},VoipPabxMediaFileVmfUUID:{label:"Create media file",loadComponent:()=>import('./chunk-CS_M1nuZ.js').then(e=>e.VoipPabxMediaFilesPage)},VoipPabxServerVpsUUID:{label:"Create PABX server",loadComponent:()=>import('./chunk-Duqls5Un.js').then(e=>e.VoipPabxServerPage),permission:t},VoipPabxTrunkVptUUID:{label:"Create trunk",loadComponent:()=>import('./chunk-DkkiKmE8.js').then(e=>e.VoipPabxTrunkPage)},VoipPortabilityReasonVprUUID:{label:"Create reason",loadComponent:()=>import('./chunk-BDpTbDMM.js').then(e=>e.VoipPortabilityReasonsPage)},VoipSbcAccountVsaUUID:{label:"Create SBC account",loadComponent:()=>import('./chunk-nbJrCe9B.js').then(e=>e.VoipSbcAccountPage)},VoipSbcInterfaceVsiUUID:{label:"Create SBC interface",loadComponent:()=>import('./chunk-BouEJ5uI.js').then(e=>e.VoipSbcInterfacePage),permission:t},VoipSbcPeerVspUUID:{label:"Create SBC peer",loadComponent:()=>import('./chunk-CFxAbGcI.js').then(e=>e.VoipSbcPeerPage)},VoipSbcPipeVbpUUID:{label:"Create SBC pipe",loadComponent:()=>import('./chunk-BCdqKUEU.js').then(e=>e.VoipSbcPipePage)},VoipSbcServerVbsUUID:{label:"Create SBC server",loadComponent:()=>import('./chunk-B55vko9W.js').then(e=>e.VoipSbcServerPage),permission:t},VoipSoftswitchAccountVssUUID:{label:"Create softswitch account",loadComponent:()=>import('./chunk-DBsxS9eJ.js').then(e=>e.VoipSoftswitchAccountsPage)},VoipSoftswitchDialplanVdpUUID:{label:"Create dialplan",loadComponent:()=>import('./chunk-Dv8tgCMM.js').then(e=>e.VoipSoftswitchDialplanPage)},VoipSoftswitchServerVsrUUID:{label:"Create softswitch server",loadComponent:()=>import('./chunk-DDUa_B56.js').then(e=>e.VoipSoftswitchServerPage),permission:t},VoipSoftswitchSubscriberVsuUUID:{label:"Create subscriber",loadComponent:()=>import('./chunk-ClnW4xj8.js').then(e=>e.VoipSoftswitchSubscriberPage)},VoipSoftswitchTrunkGroupVtgUUID:{label:"Create trunk group",loadComponent:()=>import('./chunk-Czy8FpN2.js').then(e=>e.VoipSoftswitchTrunkGroupPage)},VoipSoftswitchTrunkVtkUUID:{label:"Create trunk",loadComponent:()=>import('./chunk-CPYNR0Xt.js').then(e=>e.VoipSoftswitchTrunkPage)}},i=r;function p(e){let o=e?i[e]:void 0;return o?l({},o):null}function C(e,o={}){return l(l({},p(e)),o)}function R(n,d){n&1&&_y(0,"div",2);}var T=new v("MAT_PROGRESS_BAR_DEFAULT_OPTIONS");var L=(()=>{class n{_elementRef=h(fe);_ngZone=h($);_changeDetectorRef=h(Sv);_renderer=h(Jo);_cleanupTransitionEnd;constructor(){let r=BA(),e=h(T,{optional:true});this._isNoopAnimation=r==="di-disabled",r==="reduced-motion"&&this._elementRef.nativeElement.classList.add("mat-progress-bar-reduced-motion"),e&&(e.color&&(this.color=this._defaultColor=e.color),this.mode=e.mode||this.mode);}_isNoopAnimation;get color(){return this._color||this._defaultColor}set color(r){this._color=r;}_color;_defaultColor="primary";get value(){return this._value}set value(r){this._value=A(r||0),this._changeDetectorRef.markForCheck();}_value=0;get bufferValue(){return this._bufferValue||0}set bufferValue(r){this._bufferValue=A(r||0),this._changeDetectorRef.markForCheck();}_bufferValue=0;animationEnd=new Ie;get mode(){return this._mode}set mode(r){this._mode=r,this._changeDetectorRef.markForCheck();}_mode="determinate";ngAfterViewInit(){this._ngZone.runOutsideAngular(()=>{this._cleanupTransitionEnd=this._renderer.listen(this._elementRef.nativeElement,"transitionend",this._transitionendHandler);});}ngOnDestroy(){this._cleanupTransitionEnd?.();}_getPrimaryBarTransform(){return `scaleX(${this._isIndeterminate()?1:this.value/100})`}_getBufferBarFlexBasis(){return `${this.mode==="buffer"?this.bufferValue:100}%`}_isIndeterminate(){return this.mode==="indeterminate"||this.mode==="query"}_transitionendHandler=r=>{this.animationEnd.observers.length===0||!r.target||!r.target.classList.contains("mdc-linear-progress__primary-bar")||(this.mode==="determinate"||this.mode==="buffer")&&this._ngZone.run(()=>this.animationEnd.next({value:this.value}));};static \u0275fac=function(e){return new(e||n)};static \u0275cmp=gd({type:n,selectors:[["mat-progress-bar"]],hostAttrs:["role","progressbar","aria-valuemin","0","aria-valuemax","100","tabindex","-1",1,"mat-mdc-progress-bar","mdc-linear-progress"],hostVars:10,hostBindings:function(e,a){e&2&&(Ed("aria-valuenow",a._isIndeterminate()?null:a.value)("mode",a.mode),bT("mat-"+a.color),Py("_mat-animation-noopable",a._isNoopAnimation)("mdc-linear-progress--animation-ready",!a._isNoopAnimation)("mdc-linear-progress--indeterminate",a._isIndeterminate()));},inputs:{color:"color",value:[2,"value","value",BS],bufferValue:[2,"bufferValue","bufferValue",BS],mode:"mode"},outputs:{animationEnd:"animationEnd"},exportAs:["matProgressBar"],decls:7,vars:5,consts:[["aria-hidden","true",1,"mdc-linear-progress__buffer"],[1,"mdc-linear-progress__buffer-bar"],[1,"mdc-linear-progress__buffer-dots"],["aria-hidden","true",1,"mdc-linear-progress__bar","mdc-linear-progress__primary-bar"],[1,"mdc-linear-progress__bar-inner"],["aria-hidden","true",1,"mdc-linear-progress__bar","mdc-linear-progress__secondary-bar"]],template:function(e,a){e&1&&(bd(0,"div",0),_y(1,"div",1),UC(2,R,1,0,"div",2),wd(),bd(3,"div",3),_y(4,"span",4),wd(),bd(5,"div",5),_y(6,"span",4),wd()),e&2&&(Ub(),Ly("flex-basis",a._getBufferBarFlexBasis()),Ub(),$C(a.mode==="buffer"?2:-1),Ub(),Ly("transform",a._getPrimaryBarTransform()));},styles:[`.mat-mdc-progress-bar {
  --mat-progress-bar-animation-multiplier: 1;
  display: block;
  text-align: start;
}
.mat-mdc-progress-bar[mode=query] {
  transform: scaleX(-1);
}
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__buffer-dots,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__primary-bar,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__secondary-bar,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__bar-inner.mdc-linear-progress__bar-inner {
  animation: none;
}
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__primary-bar,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__buffer-bar {
  transition: transform 1ms;
}

.mat-progress-bar-reduced-motion {
  --mat-progress-bar-animation-multiplier: 2;
}

.mdc-linear-progress {
  position: relative;
  width: 100%;
  transform: translateZ(0);
  outline: 1px solid transparent;
  overflow-x: hidden;
  transition: opacity 250ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  height: max(var(--mat-progress-bar-track-height, 4px), var(--mat-progress-bar-active-indicator-height, 4px));
}
@media (forced-colors: active) {
  .mdc-linear-progress {
    outline-color: CanvasText;
  }
}

.mdc-linear-progress__bar {
  position: absolute;
  top: 0;
  bottom: 0;
  margin: auto 0;
  width: 100%;
  animation: none;
  transform-origin: top left;
  transition: transform 250ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  height: var(--mat-progress-bar-active-indicator-height, 4px);
}
.mdc-linear-progress--indeterminate .mdc-linear-progress__bar {
  transition: none;
}
[dir=rtl] .mdc-linear-progress__bar {
  right: 0;
  transform-origin: center right;
}

.mdc-linear-progress__bar-inner {
  display: inline-block;
  position: absolute;
  width: 100%;
  animation: none;
  border-top-style: solid;
  border-color: var(--mat-progress-bar-active-indicator-color, var(--mat-sys-primary));
  border-top-width: var(--mat-progress-bar-active-indicator-height, 4px);
}

.mdc-linear-progress__buffer {
  display: flex;
  position: absolute;
  top: 0;
  bottom: 0;
  margin: auto 0;
  width: 100%;
  overflow: hidden;
  height: var(--mat-progress-bar-track-height, 4px);
  border-radius: var(--mat-progress-bar-track-shape, var(--mat-sys-corner-none));
}

.mdc-linear-progress__buffer-dots {
  background-image: radial-gradient(circle, var(--mat-progress-bar-track-color, var(--mat-sys-surface-variant)) calc(var(--mat-progress-bar-track-height, 4px) / 2), transparent 0);
  background-repeat: repeat-x;
  background-size: calc(calc(var(--mat-progress-bar-track-height, 4px) / 2) * 5);
  background-position: left;
  flex: auto;
  transform: rotate(180deg);
  animation: mdc-linear-progress-buffering calc(250ms * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
@media (forced-colors: active) {
  .mdc-linear-progress__buffer-dots {
    background-color: ButtonBorder;
  }
}
[dir=rtl] .mdc-linear-progress__buffer-dots {
  animation: mdc-linear-progress-buffering-reverse calc(250ms * var(--mat-progress-bar-animation-multiplier)) infinite linear;
  transform: rotate(0);
}

.mdc-linear-progress__buffer-bar {
  flex: 0 1 100%;
  transition: flex-basis 250ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  background-color: var(--mat-progress-bar-track-color, var(--mat-sys-surface-variant));
}

.mdc-linear-progress__primary-bar {
  transform: scaleX(0);
}
.mdc-linear-progress--indeterminate .mdc-linear-progress__primary-bar {
  left: -145.166611%;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__primary-bar {
  animation: mdc-linear-progress-primary-indeterminate-translate calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__primary-bar > .mdc-linear-progress__bar-inner {
  animation: mdc-linear-progress-primary-indeterminate-scale calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--animation-ready .mdc-linear-progress__primary-bar {
  animation-name: mdc-linear-progress-primary-indeterminate-translate-reverse;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--indeterminate .mdc-linear-progress__primary-bar {
  right: -145.166611%;
  left: auto;
}

.mdc-linear-progress__secondary-bar {
  display: none;
}
.mdc-linear-progress--indeterminate .mdc-linear-progress__secondary-bar {
  left: -54.888891%;
  display: block;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__secondary-bar {
  animation: mdc-linear-progress-secondary-indeterminate-translate calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__secondary-bar > .mdc-linear-progress__bar-inner {
  animation: mdc-linear-progress-secondary-indeterminate-scale calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--animation-ready .mdc-linear-progress__secondary-bar {
  animation-name: mdc-linear-progress-secondary-indeterminate-translate-reverse;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--indeterminate .mdc-linear-progress__secondary-bar {
  right: -54.888891%;
  left: auto;
}

@keyframes mdc-linear-progress-buffering {
  from {
    transform: rotate(180deg) translateX(calc(var(--mat-progress-bar-track-height, 4px) * -2.5));
  }
}
@keyframes mdc-linear-progress-primary-indeterminate-translate {
  0% {
    transform: translateX(0);
  }
  20% {
    animation-timing-function: cubic-bezier(0.5, 0, 0.701732, 0.495819);
    transform: translateX(0);
  }
  59.15% {
    animation-timing-function: cubic-bezier(0.302435, 0.381352, 0.55, 0.956352);
    transform: translateX(83.67142%);
  }
  100% {
    transform: translateX(200.611057%);
  }
}
@keyframes mdc-linear-progress-primary-indeterminate-scale {
  0% {
    transform: scaleX(0.08);
  }
  36.65% {
    animation-timing-function: cubic-bezier(0.334731, 0.12482, 0.785844, 1);
    transform: scaleX(0.08);
  }
  69.15% {
    animation-timing-function: cubic-bezier(0.06, 0.11, 0.6, 1);
    transform: scaleX(0.661479);
  }
  100% {
    transform: scaleX(0.08);
  }
}
@keyframes mdc-linear-progress-secondary-indeterminate-translate {
  0% {
    animation-timing-function: cubic-bezier(0.15, 0, 0.515058, 0.409685);
    transform: translateX(0);
  }
  25% {
    animation-timing-function: cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);
    transform: translateX(37.651913%);
  }
  48.35% {
    animation-timing-function: cubic-bezier(0.4, 0.627035, 0.6, 0.902026);
    transform: translateX(84.386165%);
  }
  100% {
    transform: translateX(160.277782%);
  }
}
@keyframes mdc-linear-progress-secondary-indeterminate-scale {
  0% {
    animation-timing-function: cubic-bezier(0.205028, 0.057051, 0.57661, 0.453971);
    transform: scaleX(0.08);
  }
  19.15% {
    animation-timing-function: cubic-bezier(0.152313, 0.196432, 0.648374, 1.004315);
    transform: scaleX(0.457104);
  }
  44.15% {
    animation-timing-function: cubic-bezier(0.257759, -0.003163, 0.211762, 1.38179);
    transform: scaleX(0.72796);
  }
  100% {
    transform: scaleX(0.08);
  }
}
@keyframes mdc-linear-progress-primary-indeterminate-translate-reverse {
  0% {
    transform: translateX(0);
  }
  20% {
    animation-timing-function: cubic-bezier(0.5, 0, 0.701732, 0.495819);
    transform: translateX(0);
  }
  59.15% {
    animation-timing-function: cubic-bezier(0.302435, 0.381352, 0.55, 0.956352);
    transform: translateX(-83.67142%);
  }
  100% {
    transform: translateX(-200.611057%);
  }
}
@keyframes mdc-linear-progress-secondary-indeterminate-translate-reverse {
  0% {
    animation-timing-function: cubic-bezier(0.15, 0, 0.515058, 0.409685);
    transform: translateX(0);
  }
  25% {
    animation-timing-function: cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);
    transform: translateX(-37.651913%);
  }
  48.35% {
    animation-timing-function: cubic-bezier(0.4, 0.627035, 0.6, 0.902026);
    transform: translateX(-84.386165%);
  }
  100% {
    transform: translateX(-160.277782%);
  }
}
@keyframes mdc-linear-progress-buffering-reverse {
  from {
    transform: translateX(-10px);
  }
}
`],encapsulation:2})}return n})();function A(n,d=0,r=100){return Math.max(d,Math.min(r,n))}var Z=(()=>{class n{static \u0275fac=function(e){return new(e||n)};static \u0275mod=at({type:n});static \u0275inj=Ve({imports:[hz]})}return n})();export{C,L,Z,m,p};