import{Bn as ee,Br as rC,Dr as oD,Er as oC,Fr as qe,Ft as T,Ir as qg,Kr as sC,N as Gl,O as Fg,Qr as tm,Vt as Ug,Yr as tC,_n as aC,an as Y1,ar as jg,bt as Pb,di as x,er as io,fn as Zg,nn as Xe,oi as vd,or as jr,ot as Kl,qt as Vg,rr as jb,s as AC,tr as is,ut as Lw,vt as Ow,wt as Q1}from"./chunk-DFpL9uoJ.js";import{$ as kn,H as Uf,O as Oi,ft as xt,q as et,y as Hi}from"./chunk-CrsoMjnS.js";import{n as Ie,r as Ne,t as De}from"./chunk-c0MZhpu7.js";import{t as m}from"./chunk-hxoBh_sc.js";import{c as Oo}from"./chunk-B9DcGebI.js";var st=new x(`MAT_OPTION_PARENT_COMPONENT`);var mt=new x(`MatOptgroup`);var w=class{source;isUserInput;constructor(l,t=!1){this.source=l,this.isUserInput=t}};var nt=(()=>{class n{_element=T(io);_changeDetectorRef=T(Q1);_parent=T(st,{optional:!0});group=T(mt,{optional:!0});_signalDisableRipple=!1;_selected=!1;_active=!1;_mostRecentViewValue=``;get multiple(){return this._parent&&this._parent.multiple}get selected(){return this._selected}value;id=T(kn).getId(`mat-option-`);get disabled(){return this.group&&this.group.disabled||this._disabled()}set disabled(t){this._disabled.set(t)}_disabled=qe(!1);get disableRipple(){return this._signalDisableRipple?this._parent.disableRipple():!!this._parent?.disableRipple}get hideSingleSelectionIndicator(){return!!(this._parent&&this._parent.hideSingleSelectionIndicator)}onSelectionChange=new Xe;_text;_stateChanges=new ee;constructor(){let t=T(et);t.load(Ie),t.load(xt),this._signalDisableRipple=!!this._parent&&jr(this._parent.disableRipple)}get active(){return this._active}get viewValue(){return(this._text?.nativeElement.textContent||``).trim()}select(t=!0){this._selected||(this._selected=!0,this._changeDetectorRef.markForCheck(),t&&this._emitSelectionChangeEvent())}deselect(t=!0){this._selected&&(this._selected=!1,this._changeDetectorRef.markForCheck(),t&&this._emitSelectionChangeEvent())}focus(t,i){let s=this._getHostElement();typeof s.focus==`function`&&s.focus(i)}setActiveStyles(){this._active||(this._active=!0,this._changeDetectorRef.markForCheck())}setInactiveStyles(){this._active&&(this._active=!1,this._changeDetectorRef.markForCheck())}getLabel(){return this.viewValue}_handleKeydown(t){(t.keyCode===13||t.keyCode===32)&&!Hi(t)&&(this._selectViaInteraction(),t.preventDefault())}_selectViaInteraction(){this.disabled||(this._selected=this.multiple?!this._selected:!0,this._changeDetectorRef.markForCheck(),this._emitSelectionChangeEvent(!0))}_getTabIndex(){return this.disabled?`-1`:`0`}_getHostElement(){return this._element.nativeElement}ngAfterViewChecked(){if(this._selected){let t=this.viewValue;t!==this._mostRecentViewValue&&(this._mostRecentViewValue&&this._stateChanges.next(),this._mostRecentViewValue=t)}}ngOnDestroy(){this._stateChanges.complete()}_emitSelectionChangeEvent(t=!1){this.onSelectionChange.emit(new w(this,t))}static ɵfac=function(i){return new(i||n)};static ɵcmp=(function(){let t=[`text`],i=[[[`mat-icon`]],`*`],s=[`mat-icon`,`*`];function u(o,a){if(o&1&&Vg(0,`mat-pseudo-checkbox`,1),o&2){let e=tC();jg(`disabled`,e.disabled)(`state`,e.selected?`checked`:`unchecked`)}}function m$1(o,a){if(o&1&&Vg(0,`mat-pseudo-checkbox`,3),o&2){let e=tC();jg(`disabled`,e.disabled)}}function ot(o,a){if(o&1&&(is(0,`span`,4),AC(1),Gl()),o&2){let e=tC();oD(),Kl(`(`,e.group.label,`)`)}}return Ow({type:n,selectors:[[`mat-option`]],viewQuery:function(a,e){if(a&1&&Zg(t,7),a&2){let g;sC(g=aC())&&(e._text=g.first)}},hostAttrs:[`role`,`option`,1,`mat-mdc-option`,`mdc-list-item`],hostVars:11,hostBindings:function(a,e){a&1&&qg(`click`,function(){return e._selectViaInteraction()})(`keydown`,function(at){return e._handleKeydown(at)}),a&2&&(Ug(`id`,e.id),Fg(`aria-selected`,e.selected)(`aria-disabled`,e.disabled.toString()),tm(`mdc-list-item--selected`,e.selected)(`mat-mdc-option-multiple`,e.multiple)(`mat-mdc-option-active`,e.active)(`mdc-list-item--disabled`,e.disabled))},inputs:{value:`value`,id:`id`,disabled:[2,`disabled`,`disabled`,Y1]},outputs:{onSelectionChange:`onSelectionChange`},exportAs:[`matOption`],ngContentSelectors:s,decls:8,vars:5,consts:[[`text`,``],[`aria-hidden`,`true`,1,`mat-mdc-option-pseudo-checkbox`,3,`disabled`,`state`],[1,`mdc-list-item__primary-text`],[`state`,`checked`,`aria-hidden`,`true`,`appearance`,`minimal`,1,`mat-mdc-option-pseudo-checkbox`,3,`disabled`],[1,`cdk-visually-hidden`],[`aria-hidden`,`true`,`mat-ripple`,``,1,`mat-mdc-option-ripple`,`mat-focus-indicator`,3,`matRippleTrigger`,`matRippleDisabled`]],template:function(a,e){a&1&&(rC(i),Pb(0,u,1,2,`mat-pseudo-checkbox`,1),oC(1),is(2,`span`,2,0),oC(4,1),Gl(),Pb(5,m$1,1,1,`mat-pseudo-checkbox`,3),Pb(6,ot,2,1,`span`,4),Vg(7,`div`,5)),a&2&&(jb(e.multiple?0:-1),oD(5),jb(!e.multiple&&e.selected&&!e.hideSingleSelectionIndicator?5:-1),oD(),jb(e.group&&e.group._inert?6:-1),oD(),jg(`matRippleTrigger`,e._getHostElement())(`matRippleDisabled`,e.disabled||e.disableRipple))},dependencies:[m,De],styles:[`.mat-mdc-option {
  -webkit-user-select: none;
  user-select: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  min-height: 48px;
  padding: 0 16px;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  color: var(--%NS%mat-option-label-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-option-label-text-font, var(--%NS%mat-sys-label-large-font));
  line-height: var(--%NS%mat-option-label-text-line-height, var(--%NS%mat-sys-label-large-line-height));
  font-size: var(--%NS%mat-option-label-text-size, var(--%NS%mat-sys-body-large-size));
  letter-spacing: var(--%NS%mat-option-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  font-weight: var(--%NS%mat-option-label-text-weight, var(--%NS%mat-sys-body-large-weight));
}
.mat-mdc-option:hover:not(.mdc-list-item--disabled) {
  background-color: var(--%NS%mat-option-hover-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-option:focus.mdc-list-item, .mat-mdc-option.mat-mdc-option-active.mdc-list-item {
  background-color: var(--%NS%mat-option-focus-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-focus-state-layer-opacity) * 100%), transparent));
  outline: 0;
}
.mat-mdc-option.mdc-list-item--%NS%selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) {
  background-color: var(--%NS%mat-option-selected-state-layer-color, var(--%NS%mat-sys-secondary-container));
}
.mat-mdc-option.mdc-list-item--%NS%selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) .mdc-list-item__primary-text {
  color: var(--%NS%mat-option-selected-state-label-text-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-mdc-option .mat-pseudo-checkbox {
  --%NS%mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--%NS%mat-option-selected-state-label-text-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-mdc-option.mdc-list-item {
  align-items: center;
  background: transparent;
}
.mat-mdc-option.mdc-list-item--disabled {
  cursor: default;
  pointer-events: none;
}
.mat-mdc-option.mdc-list-item--disabled .mat-mdc-option-pseudo-checkbox, .mat-mdc-option.mdc-list-item--disabled .mdc-list-item__primary-text, .mat-mdc-option.mdc-list-item--disabled > mat-icon {
  opacity: 0.38;
}
.mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 32px;
}
[dir=rtl] .mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 16px;
  padding-right: 32px;
}
.mat-mdc-option .mat-icon,
.mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-icon,
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 0;
  margin-left: 16px;
}
.mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-left: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-right: 16px;
  margin-left: 0;
}
.mat-mdc-option .mat-mdc-option-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
.mat-mdc-option .mdc-list-item__primary-text {
  white-space: normal;
  font-size: inherit;
  font-weight: inherit;
  letter-spacing: inherit;
  line-height: inherit;
  font-family: inherit;
  text-decoration: inherit;
  text-transform: inherit;
  margin-right: auto;
}
[dir=rtl] .mat-mdc-option .mdc-list-item__primary-text {
  margin-right: 0;
  margin-left: auto;
}
@media (forced-colors: active) {
  .mat-mdc-option.mdc-list-item--%NS%selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    content: "";
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 10px;
    height: 0;
    border-bottom: solid 10px;
    border-radius: 10px;
  }
  [dir=rtl] .mat-mdc-option.mdc-list-item--%NS%selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    right: auto;
    left: 16px;
  }
}

.mat-mdc-option-multiple {
  --%NS%mat-list-list-item-selected-container-color: var(--%NS%mat-list-list-item-container-color, transparent);
}

.mat-mdc-option-active .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2})})()}return n})();function Nt(n,l,t){if(t.length){let i=l.toArray(),s=t.toArray(),u=0;for(let m=0;m<n+1;m++)i[m].group&&i[m].group===s[u]&&u++;return u}return 0}function Ct(n,l,t,i){return n<t?n:n+l>t+i?Math.max(0,n-i+l):t}var Qt=(()=>{class n{static ɵfac=function(i){return new(i||n)};static ɵmod=Lw({type:n});static ɵinj=vd({imports:[Oi,Oo,Uf]})}return n})();var it=(()=>{class n{static ɵfac=function(i){return new(i||n)};static ɵmod=Lw({type:n});static ɵinj=vd({imports:[Uf]})}return n})();var ne=(()=>{class n{static ɵfac=function(i){return new(i||n)};static ɵmod=Lw({type:n});static ɵinj=vd({imports:[Ne,it,nt,Uf]})}return n})();export{ne as a,mt as i,Nt as n,nt as o,Qt as r,st as s,Ct as t};