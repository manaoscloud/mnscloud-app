import{$ as K1,$t as WC,An as ce,Br as rC,Dr as oD,Er as oC,Ft as T,Gn as fh,I as Hb,Ir as qg,Kr as sC,Mn as cm,N as Gl,O as Fg,Ot as Qg,Qr as tm,Ur as ri,Wn as fe,_n as aC,an as Y1,ar as jg,di as x,er as io,f as Bb,fn as Zg,lr as jw,lt as Lc,nn as Xe,oi as vd,pi as xm,qt as Vg,r as $b,s as AC,tr as is,ut as Lw,vt as Ow,wt as Q1}from"./chunk-DFpL9uoJ.js";import{$ as kn,C as Mf,H as Uf,I as Si,n as Af,q as et}from"./chunk-CrsoMjnS.js";import{n as Ie,r as Ne,t as De}from"./chunk-c0MZhpu7.js";import{n as wt,t as Mt}from"./chunk-B-vfu-QP.js";import"./chunk-D2Ks51bV.js";import{r as p}from"./chunk-BSThK4t-.js";import{s as Re}from"./chunk-BCM3o_c-.js";import{r as g,z as f}from"./main-R3SJMNFG.js";import{n as _,t as I}from"./chunk-BGscqpW3.js";var N=class{source;value;constructor(b,e){this.source=b,this.value=e}};var ye={provide:Re,useExisting:ri(()=>G),multi:!0};var be=new x(`MatRadioGroup`);var ke=new x(`mat-radio-default-options`,{providedIn:`root`,factory:()=>({color:`accent`,disabledInteractive:!1})});var G=(()=>{class a{_changeDetector=T(Q1);_value=null;_name=T(kn).getId(`mat-radio-group-`);_selected=null;_isInitialized=!1;_labelPosition=`after`;_disabled=!1;_required=!1;_buttonChanges;_controlValueAccessorChangeFn=()=>{};onTouched=()=>{};change=new Xe;_radios;color;get name(){return this._name}set name(e){this._name=e,this._updateRadioButtonNames()}get labelPosition(){return this._labelPosition}set labelPosition(e){this._labelPosition=e===`before`?`before`:`after`,this._markRadiosForCheck()}get value(){return this._value}set value(e){this._value!==e&&(this._value=e,this._updateSelectedRadioFromValue(),this._checkSelectedRadioButton())}_checkSelectedRadioButton(){this._selected&&!this._selected.checked&&(this._selected.checked=!0)}get selected(){return this._selected}set selected(e){this._selected=e,this.value=e?e.value:null,this._checkSelectedRadioButton()}get disabled(){return this._disabled}set disabled(e){this._disabled=e,this._markRadiosForCheck()}get required(){return this._required}set required(e){this._required=e,this._markRadiosForCheck()}get disabledInteractive(){return this._disabledInteractive}set disabledInteractive(e){this._disabledInteractive=e,this._markRadiosForCheck()}_disabledInteractive=!1;ngAfterContentInit(){this._isInitialized=!0,this._buttonChanges=this._radios.changes.subscribe(()=>{this.selected&&!this._radios.find(e=>e===this.selected)&&(this._selected=null)})}ngOnDestroy(){this._buttonChanges?.unsubscribe()}_touch(){this.onTouched&&this.onTouched()}_updateRadioButtonNames(){this._radios&&this._radios.forEach(e=>{e.name=this.name,e._markForCheck()})}_updateSelectedRadioFromValue(){let e=this._selected!==null&&this._selected.value===this._value;this._radios&&!e&&(this._selected=null,this._radios.forEach(t=>{t.checked=this.value===t.value,t.checked&&(this._selected=t)}))}_emitChangeEvent(){this._isInitialized&&this.change.emit(new N(this._selected,this._value))}_markRadiosForCheck(){this._radios&&this._radios.forEach(e=>e._markForCheck())}writeValue(e){this.value=e,this._changeDetector.markForCheck()}registerOnChange(e){this._controlValueAccessorChangeFn=e}registerOnTouched(e){this.onTouched=e}setDisabledState(e){this.disabled=e,this._changeDetector.markForCheck()}static ɵfac=function(t){return new(t||a)};static ɵdir=jw({type:a,selectors:[[`mat-radio-group`]],contentQueries:function(t,c,m){if(t&1&&Qg(m,w,5),t&2){let s;sC(s=aC())&&(c._radios=s)}},hostAttrs:[`role`,`radiogroup`,1,`mat-mdc-radio-group`],inputs:{color:`color`,name:`name`,labelPosition:`labelPosition`,value:`value`,selected:`selected`,disabled:[2,`disabled`,`disabled`,Y1],required:[2,`required`,`required`,Y1],disabledInteractive:[2,`disabledInteractive`,`disabledInteractive`,Y1]},outputs:{change:`change`},exportAs:[`matRadioGroup`],features:[WC([ye,{provide:be,useExisting:a}])]})}return a})();var w=(()=>{class a{_elementRef=T(io);_changeDetector=T(Q1);_focusMonitor=T(Si);_radioDispatcher=T(p);_defaultOptions=T(ke,{optional:!0});_ngZone=T(fe);_renderer=T(Lc);_uniqueId=T(kn).getId(`mat-radio-`);_cleanupClick;id=this._uniqueId;name;ariaLabel;ariaLabelledby;ariaDescribedby;disableRipple=!1;tabIndex=0;get checked(){return this._checked}set checked(e){this._checked!==e&&(this._checked=e,e&&this.radioGroup&&this.radioGroup.value!==this.value?this.radioGroup.selected=this:!e&&this.radioGroup&&this.radioGroup.value===this.value&&(this.radioGroup.selected=null),e&&this._radioDispatcher.notify(this.id,this.name),this._changeDetector.markForCheck())}get value(){return this._value}set value(e){this._value!==e&&(this._value=e,this.radioGroup!==null&&(this.checked||(this.checked=this.radioGroup.value===e),this.checked&&(this.radioGroup.selected=this)))}get labelPosition(){return this._labelPosition||this.radioGroup&&this.radioGroup.labelPosition||`after`}set labelPosition(e){this._labelPosition=e}_labelPosition;get disabled(){return this._disabled||this.radioGroup!==null&&this.radioGroup.disabled}set disabled(e){this._setDisabled(e)}get required(){return this._required||this.radioGroup&&this.radioGroup.required}set required(e){e!==this._required&&this._changeDetector.markForCheck(),this._required=e}get color(){return this._color||this.radioGroup&&this.radioGroup.color||this._defaultOptions&&this._defaultOptions.color||`accent`}set color(e){this._color=e}_color;get disabledInteractive(){return this._disabledInteractive||this.radioGroup!==null&&this.radioGroup.disabledInteractive}set disabledInteractive(e){this._disabledInteractive=e}_disabledInteractive;change=new Xe;radioGroup;get inputId(){return`${this.id||this._uniqueId}-input`}_checked=!1;_disabled=!1;_required=!1;_value=null;_removeUniqueSelectionListener=()=>{};_previousTabIndex;_inputElement;_rippleTrigger;_noopAnimations=Af();_injector=T(ce);constructor(){T(et).load(Ie);let e=T(be,{optional:!0}),t=T(new xm(`tabindex`),{optional:!0});this.radioGroup=e,this._disabledInteractive=this._defaultOptions?.disabledInteractive??!1,t&&(this.tabIndex=K1(t,0))}focus(e,t){t?this._focusMonitor.focusVia(this._inputElement,t,e):this._inputElement.nativeElement.focus(e)}_markForCheck(){this._changeDetector.markForCheck()}ngOnInit(){this.radioGroup&&(this.checked=this.radioGroup.value===this._value,this.checked&&(this.radioGroup.selected=this),this.name=this.radioGroup.name),this._removeUniqueSelectionListener=this._radioDispatcher.listen((e,t)=>{e!==this.id&&t===this.name&&(this.checked=!1)})}ngDoCheck(){this._updateTabIndex()}ngAfterViewInit(){this._updateTabIndex(),this._focusMonitor.monitor(this._elementRef,!0).subscribe(e=>{!e&&this.radioGroup&&this.radioGroup._touch()}),this._ngZone.runOutsideAngular(()=>{this._cleanupClick=this._renderer.listen(this._inputElement.nativeElement,`click`,this._onInputClick)})}ngOnDestroy(){this._cleanupClick?.(),this._focusMonitor.stopMonitoring(this._elementRef),this._removeUniqueSelectionListener()}_emitChangeEvent(){this.change.emit(new N(this,this._value))}_isRippleDisabled(){return this.disableRipple||this.disabled}_onInputInteraction(e){if(e.stopPropagation(),!this.checked&&!this.disabled){let t=this.radioGroup&&this.value!==this.radioGroup.value;this.checked=!0,this._emitChangeEvent(),this.radioGroup&&(this.radioGroup._controlValueAccessorChangeFn(this.value),t&&this.radioGroup._emitChangeEvent())}}_setDisabled(e){this._disabled!==e&&(this._disabled=e,this._changeDetector.markForCheck())}_onInputClick=e=>{this.disabled&&this.disabledInteractive&&e.preventDefault()};_updateTabIndex(){let e=this.radioGroup,t;if(!e||!e.selected||this.disabled?t=this.tabIndex:t=e.selected===this?this.tabIndex:-1,t!==this._previousTabIndex){let c=this._inputElement?.nativeElement;c&&(c.setAttribute(`tabindex`,t+``),this._previousTabIndex=t,fh(()=>{queueMicrotask(()=>{e&&e.selected&&e.selected!==this&&document.activeElement===c&&(e.selected?._inputElement.nativeElement.focus(),document.activeElement===c&&this._inputElement.nativeElement.blur())})},{injector:this._injector}))}}static ɵfac=function(t){return new(t||a)};static ɵcmp=(function(){let e=[`input`],t=[`formField`];return Ow({type:a,selectors:[[`mat-radio-button`]],viewQuery:function(s,i){if(s&1&&Zg(e,5)(t,7,io),s&2){let _;sC(_=aC())&&(i._inputElement=_.first),sC(_=aC())&&(i._rippleTrigger=_.first)}},hostAttrs:[1,`mat-mdc-radio-button`],hostVars:19,hostBindings:function(s,i){s&1&&qg(`focus`,function(){return i._inputElement.nativeElement.focus()}),s&2&&(Fg(`id`,i.id)(`tabindex`,null)(`aria-label`,null)(`aria-labelledby`,null)(`aria-describedby`,null),tm(`mat-primary`,i.color===`primary`)(`mat-accent`,i.color===`accent`)(`mat-warn`,i.color===`warn`)(`mat-mdc-radio-checked`,i.checked)(`mat-mdc-radio-disabled`,i.disabled)(`mat-mdc-radio-disabled-interactive`,i.disabledInteractive)(`_mat-animation-noopable`,i._noopAnimations))},inputs:{id:`id`,name:`name`,ariaLabel:[0,`aria-label`,`ariaLabel`],ariaLabelledby:[0,`aria-labelledby`,`ariaLabelledby`],ariaDescribedby:[0,`aria-describedby`,`ariaDescribedby`],disableRipple:[2,`disableRipple`,`disableRipple`,Y1],tabIndex:[2,`tabIndex`,`tabIndex`,m=>m==null?0:K1(m)],checked:[2,`checked`,`checked`,Y1],value:`value`,labelPosition:`labelPosition`,disabled:[2,`disabled`,`disabled`,Y1],required:[2,`required`,`required`,Y1],color:`color`,disabledInteractive:[2,`disabledInteractive`,`disabledInteractive`,Y1]},outputs:{change:`change`},exportAs:[`matRadioButton`],ngContentSelectors:[`*`],decls:13,vars:17,consts:[[`formField`,``],[`input`,``],[`mat-internal-form-field`,``,3,`labelPosition`,`for`],[1,`mdc-radio`],[1,`mat-mdc-radio-touch-target`],[`type`,`radio`,`aria-invalid`,`false`,1,`mdc-radio__native-control`,3,`change`,`id`,`checked`,`disabled`,`required`],[`aria-hidden`,`true`,1,`mdc-radio__background`],[1,`mdc-radio__outer-circle`],[1,`mdc-radio__inner-circle`],[`mat-ripple`,``,`aria-hidden`,`true`,1,`mat-radio-ripple`,`mat-focus-indicator`,3,`matRippleTrigger`,`matRippleDisabled`,`matRippleCentered`],[1,`mat-ripple-element`,`mat-radio-persistent-ripple`],[1,`mat-internal-form-field-label`,`mdc-label`]],template:function(s,i){s&1&&(rC(),is(0,`label`,2,0)(2,`span`,3),Vg(3,`span`,4),is(4,`input`,5,1),qg(`change`,function(ge){return i._onInputInteraction(ge)}),Gl(),is(6,`span`,6),Vg(7,`span`,7)(8,`span`,8),Gl(),is(9,`span`,9),Vg(10,`span`,10),Gl()(),is(11,`span`,11),oC(12),Gl()()),s&2&&(jg(`labelPosition`,i.labelPosition)(`for`,i.inputId),oD(2),tm(`mdc-radio--disabled`,i.disabled),oD(2),jg(`id`,i.inputId)(`checked`,i.checked)(`disabled`,i.disabled&&!i.disabledInteractive)(`required`,i.required),Fg(`name`,i.name)(`value`,i.value)(`aria-label`,i.ariaLabel)(`aria-labelledby`,i.ariaLabelledby)(`aria-describedby`,i.ariaDescribedby)(`aria-disabled`,i.disabled&&i.disabledInteractive?`true`:null),oD(5),jg(`matRippleTrigger`,i._rippleTrigger.nativeElement)(`matRippleDisabled`,i._isRippleDisabled())(`matRippleCentered`,!0))},dependencies:[De,g],styles:[`.mat-mdc-radio-button {
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-radio-button .mdc-radio {
  display: inline-block;
  position: relative;
  flex: 0 0 auto;
  box-sizing: content-box;
  width: 20px;
  height: 20px;
  will-change: opacity, transform, border-color, color;
  padding: calc((var(--%NS%mat-radio-state-layer-size, 40px) - 20px) / 2);
  cursor: pointer;
}
.mat-mdc-radio-button .mdc-radio:hover > .mdc-radio__native-control:not([disabled]):not(:focus) ~ .mdc-radio__background::before {
  opacity: 0.04;
  transform: scale(1);
}
.mat-mdc-radio-button .mdc-radio:hover > .mdc-radio__native-control:not([disabled]) ~ .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-unselected-hover-icon-color, var(--%NS%mat-sys-on-surface));
}
.mat-mdc-radio-button .mdc-radio:hover > .mdc-radio__native-control:enabled:checked + .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-selected-hover-icon-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-radio-button .mdc-radio:hover > .mdc-radio__native-control:enabled:checked + .mdc-radio__background > .mdc-radio__inner-circle {
  background-color: var(--%NS%mat-radio-selected-hover-icon-color, var(--%NS%mat-sys-primary, currentColor));
}
.mat-mdc-radio-button .mdc-radio:active > .mdc-radio__native-control:enabled:not(:checked) + .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-unselected-pressed-icon-color, var(--%NS%mat-sys-on-surface));
}
.mat-mdc-radio-button .mdc-radio:active > .mdc-radio__native-control:enabled:checked + .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-selected-pressed-icon-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-radio-button .mdc-radio:active > .mdc-radio__native-control:enabled:checked + .mdc-radio__background > .mdc-radio__inner-circle {
  background-color: var(--%NS%mat-radio-selected-pressed-icon-color, var(--%NS%mat-sys-primary, currentColor));
}
.mat-mdc-radio-button .mdc-radio__background {
  display: inline-block;
  position: relative;
  box-sizing: border-box;
  width: 20px;
  height: 20px;
}
.mat-mdc-radio-button .mdc-radio__background::before {
  position: absolute;
  transform: scale(0, 0);
  border-radius: 50%;
  opacity: 0;
  pointer-events: none;
  content: "";
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
  width: var(--%NS%mat-radio-state-layer-size, 40px);
  height: var(--%NS%mat-radio-state-layer-size, 40px);
  top: calc(-1 * (var(--%NS%mat-radio-state-layer-size, 40px) - 20px) / 2);
  left: calc(-1 * (var(--%NS%mat-radio-state-layer-size, 40px) - 20px) / 2);
}
.mat-mdc-radio-button .mdc-radio__outer-circle {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  border-width: 2px;
  border-style: solid;
  border-radius: 50%;
  transition: border-color 90ms cubic-bezier(0.4, 0, 0.6, 1);
}
.mat-mdc-radio-button .mdc-radio__inner-circle {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  transform: scale(0);
  border-radius: 50%;
  transition: transform 90ms cubic-bezier(0.4, 0, 0.6, 1), background-color 90ms cubic-bezier(0.4, 0, 0.6, 1);
}
@media (forced-colors: active) {
  .mat-mdc-radio-button .mdc-radio__inner-circle {
    background-color: CanvasText !important;
  }
}
.mat-mdc-radio-button .mdc-radio__native-control {
  position: absolute;
  margin: 0;
  padding: 0;
  opacity: 0;
  top: 0;
  right: 0;
  left: 0;
  cursor: inherit;
  z-index: 1;
  width: var(--%NS%mat-radio-state-layer-size, 40px);
  height: var(--%NS%mat-radio-state-layer-size, 40px);
}
.mat-mdc-radio-button .mdc-radio__native-control:checked + .mdc-radio__background, .mat-mdc-radio-button .mdc-radio__native-control:disabled + .mdc-radio__background {
  transition: opacity 90ms cubic-bezier(0, 0, 0.2, 1), transform 90ms cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-radio-button .mdc-radio__native-control:checked + .mdc-radio__background > .mdc-radio__outer-circle, .mat-mdc-radio-button .mdc-radio__native-control:disabled + .mdc-radio__background > .mdc-radio__outer-circle {
  transition: border-color 90ms cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-radio-button .mdc-radio__native-control:checked + .mdc-radio__background > .mdc-radio__inner-circle, .mat-mdc-radio-button .mdc-radio__native-control:disabled + .mdc-radio__background > .mdc-radio__inner-circle {
  transition: transform 90ms cubic-bezier(0, 0, 0.2, 1), background-color 90ms cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-radio-button .mdc-radio__native-control:focus + .mdc-radio__background::before {
  transform: scale(1);
  opacity: 0.12;
  transition: opacity 90ms cubic-bezier(0, 0, 0.2, 1), transform 90ms cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-radio-button .mdc-radio__native-control:disabled:not(:checked) + .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-disabled-unselected-icon-color, var(--%NS%mat-sys-on-surface));
  opacity: var(--%NS%mat-radio-disabled-unselected-icon-opacity, 0.38);
}
.mat-mdc-radio-button .mdc-radio__native-control:disabled + .mdc-radio__background {
  cursor: default;
}
.mat-mdc-radio-button .mdc-radio__native-control:disabled + .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-disabled-selected-icon-color, var(--%NS%mat-sys-on-surface));
  opacity: var(--%NS%mat-radio-disabled-selected-icon-opacity, 0.38);
}
.mat-mdc-radio-button .mdc-radio__native-control:disabled + .mdc-radio__background > .mdc-radio__inner-circle {
  background-color: var(--%NS%mat-radio-disabled-selected-icon-color, var(--%NS%mat-sys-on-surface, currentColor));
  opacity: var(--%NS%mat-radio-disabled-selected-icon-opacity, 0.38);
}
.mat-mdc-radio-button .mdc-radio__native-control:enabled:not(:checked) + .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-unselected-icon-color, var(--%NS%mat-sys-on-surface-variant));
}
.mat-mdc-radio-button .mdc-radio__native-control:enabled:checked + .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-selected-icon-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-radio-button .mdc-radio__native-control:enabled:checked + .mdc-radio__background > .mdc-radio__inner-circle {
  background-color: var(--%NS%mat-radio-selected-icon-color, var(--%NS%mat-sys-primary, currentColor));
}
.mat-mdc-radio-button .mdc-radio__native-control:enabled:focus:checked + .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-selected-focus-icon-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-radio-button .mdc-radio__native-control:enabled:focus:checked + .mdc-radio__background > .mdc-radio__inner-circle {
  background-color: var(--%NS%mat-radio-selected-focus-icon-color, var(--%NS%mat-sys-primary, currentColor));
}
.mat-mdc-radio-button .mdc-radio__native-control:checked + .mdc-radio__background > .mdc-radio__inner-circle {
  transform: scale(0.5);
  transition: transform 90ms cubic-bezier(0, 0, 0.2, 1), background-color 90ms cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-radio-button.mat-mdc-radio-disabled-interactive .mdc-radio--disabled {
  pointer-events: auto;
}
.mat-mdc-radio-button.mat-mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__native-control:not(:checked) + .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-disabled-unselected-icon-color, var(--%NS%mat-sys-on-surface));
  opacity: var(--%NS%mat-radio-disabled-unselected-icon-opacity, 0.38);
}
.mat-mdc-radio-button.mat-mdc-radio-disabled-interactive .mdc-radio--%NS%disabled:hover .mdc-radio__native-control:checked + .mdc-radio__background > .mdc-radio__outer-circle,
.mat-mdc-radio-button.mat-mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__native-control:checked:focus + .mdc-radio__background > .mdc-radio__outer-circle,
.mat-mdc-radio-button.mat-mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__native-control + .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-disabled-selected-icon-color, var(--%NS%mat-sys-on-surface));
  opacity: var(--%NS%mat-radio-disabled-selected-icon-opacity, 0.38);
}
.mat-mdc-radio-button.mat-mdc-radio-disabled-interactive .mdc-radio--%NS%disabled:hover .mdc-radio__native-control:checked + .mdc-radio__background > .mdc-radio__inner-circle,
.mat-mdc-radio-button.mat-mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__native-control:checked:focus + .mdc-radio__background > .mdc-radio__inner-circle,
.mat-mdc-radio-button.mat-mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__native-control + .mdc-radio__background > .mdc-radio__inner-circle {
  background-color: var(--%NS%mat-radio-disabled-selected-icon-color, var(--%NS%mat-sys-on-surface, currentColor));
  opacity: var(--%NS%mat-radio-disabled-selected-icon-opacity, 0.38);
}
.mat-mdc-radio-button._mat-animation-noopable .mdc-radio__background::before,
.mat-mdc-radio-button._mat-animation-noopable .mdc-radio__outer-circle,
.mat-mdc-radio-button._mat-animation-noopable .mdc-radio__inner-circle {
  transition: none !important;
}
.mat-mdc-radio-button .mat-internal-form-field-label:empty {
  display: none;
}
.mat-mdc-radio-button .mdc-radio__background::before {
  background-color: var(--%NS%mat-radio-ripple-color, var(--%NS%mat-sys-on-surface));
}
.mat-mdc-radio-button.mat-mdc-radio-checked .mat-ripple-element,
.mat-mdc-radio-button.mat-mdc-radio-checked .mdc-radio__background::before {
  background-color: var(--%NS%mat-radio-checked-ripple-color, var(--%NS%mat-sys-primary));
}
.mat-mdc-radio-button.mat-mdc-radio-disabled-interactive .mdc-radio--disabled .mat-ripple-element,
.mat-mdc-radio-button.mat-mdc-radio-disabled-interactive .mdc-radio--disabled .mdc-radio__background::before {
  background-color: var(--%NS%mat-radio-ripple-color, var(--%NS%mat-sys-on-surface));
}
.mat-mdc-radio-button .mat-internal-form-field {
  color: var(--%NS%mat-radio-label-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-radio-label-text-font, var(--%NS%mat-sys-body-medium-font));
  line-height: var(--%NS%mat-radio-label-text-line-height, var(--%NS%mat-sys-body-medium-line-height));
  font-size: var(--%NS%mat-radio-label-text-size, var(--%NS%mat-sys-body-medium-size));
  letter-spacing: var(--%NS%mat-radio-label-text-tracking, var(--%NS%mat-sys-body-medium-tracking));
  font-weight: var(--%NS%mat-radio-label-text-weight, var(--%NS%mat-sys-body-medium-weight));
  cursor: pointer;
}
.mat-mdc-radio-button .mdc-radio--disabled + .mat-internal-form-field-label {
  color: var(--%NS%mat-radio-disabled-label-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-radio-button .mat-radio-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
  border-radius: 50%;
}
.mat-mdc-radio-button .mat-radio-ripple > .mat-ripple-element {
  opacity: 0.14;
}
.mat-mdc-radio-button .mat-radio-ripple::before {
  border-radius: 50%;
}
.mat-mdc-radio-button .mdc-radio > .mdc-radio__native-control:focus:enabled:not(:checked) ~ .mdc-radio__background > .mdc-radio__outer-circle {
  border-color: var(--%NS%mat-radio-unselected-focus-icon-color, var(--%NS%mat-sys-on-surface));
}
.mat-mdc-radio-button.cdk-focused .mat-focus-indicator::before {
  content: "";
}

.mat-mdc-radio-disabled {
  cursor: default;
  pointer-events: none;
}
.mat-mdc-radio-disabled.mat-mdc-radio-disabled-interactive {
  pointer-events: auto;
}

.mat-mdc-radio-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--%NS%mat-radio-touch-target-size, 48px);
  width: var(--%NS%mat-radio-touch-target-size, 48px);
  transform: translate(-50%, -50%);
  display: var(--%NS%mat-radio-touch-target-display, block);
}
[dir=rtl] .mat-mdc-radio-touch-target {
  left: auto;
  right: 50%;
  transform: translate(50%, -50%);
}
`],encapsulation:2})})()}return a})();var pe=(()=>{class a{static ɵfac=function(t){return new(t||a)};static ɵmod=Lw({type:a});static ɵinj=vd({imports:[Ne,w,Uf]})}return a})();var _e=(()=>{class a{get vertical(){return this._vertical}set vertical(e){this._vertical=Mf(e)}_vertical=!1;get inset(){return this._inset}set inset(e){this._inset=Mf(e)}_inset=!1;static ɵfac=function(t){return new(t||a)};static ɵcmp=Ow({type:a,selectors:[[`mat-divider`]],hostAttrs:[`role`,`separator`,1,`mat-divider`],hostVars:7,hostBindings:function(t,c){t&2&&(Fg(`aria-orientation`,c.vertical?`vertical`:`horizontal`),tm(`mat-divider-vertical`,c.vertical)(`mat-divider-horizontal`,!c.vertical)(`mat-divider-inset`,c.inset))},inputs:{vertical:`vertical`,inset:`inset`},decls:0,vars:0,template:function(t,c){},styles:[`.mat-divider {
  display: block;
  margin: 0;
  border-top-style: solid;
  border-top-color: var(--%NS%mat-divider-color, var(--%NS%mat-sys-outline-variant));
  border-top-width: var(--%NS%mat-divider-width, 1px);
}
.mat-divider.mat-divider-vertical {
  border-top: 0;
  border-right-style: solid;
  border-right-color: var(--%NS%mat-divider-color, var(--%NS%mat-sys-outline-variant));
  border-right-width: var(--%NS%mat-divider-width, 1px);
}
.mat-divider.mat-divider-inset {
  margin-left: 80px;
}
[dir=rtl] .mat-divider.mat-divider-inset {
  margin-left: auto;
  margin-right: 80px;
}
`],encapsulation:2})}return a})();var he=(()=>{class a{static ɵfac=function(t){return new(t||a)};static ɵmod=Lw({type:a});static ɵinj=vd({imports:[Uf]})}return a})();function Me(a,b){if(a&1&&(is(0,`mat-radio-button`,8)(1,`div`,10)(2,`mat-icon`,11),AC(3),Gl(),is(4,`div`,12)(5,`div`,13),AC(6),Gl(),is(7,`div`,14),AC(8),Gl()()()()),a&2){let e=b.$implicit;jg(`value`,e.value),oD(3),cm(e.icon),oD(3),cm(e.label),oD(2),cm(e.description)}}var ve=class a{themeService=T(f);theme=this.themeService.theme;themeOptions=[{value:`light`,label:`Light`,icon:`light_mode`,description:`Always use the light theme.`},{value:`dark`,label:`Dark`,icon:`dark_mode`,description:`Always use the dark theme.`},{value:`midnight`,label:`Midnight`,icon:`nights_stay`,description:`Always use the midnight blue theme.`},{value:`system`,label:`Follow system`,icon:`settings_suggest`,description:`Automatically follow your OS theme.`}];setTheme(b){this.themeService.setTheme(b)}static ɵfac=function(e){return new(e||a)};static ɵcmp=Ow({type:a,selectors:[[`app-settings`]],hostAttrs:[1,`app-fade-in-host`],decls:31,vars:1,consts:[[1,`settings-wrapper`],[1,`settings-card`],[1,`title`,`mat-headline-small`],[1,`subtitle`,`mat-body-medium`],[1,`section-block`],[1,`section-title`],[1,`section-description`],[1,`theme-radio-group`,3,`change`,`value`],[1,`theme-radio`,3,`value`],[1,`hint-text`],[1,`theme-option`],[1,`theme-icon`],[1,`theme-text`],[1,`theme-label`],[1,`theme-description`]],template:function(e,t){e&1&&(is(0,`section`,0)(1,`mat-card`,1)(2,`h1`,2),AC(3,`Settings`),Gl(),is(4,`p`,3),AC(5,`Customize your mnscloud experience.`),Gl(),is(6,`section`,4)(7,`h2`,5)(8,`mat-icon`),AC(9,`palette`),Gl(),is(10,`span`),AC(11,`Appearance`),Gl()(),is(12,`p`,6),AC(13,`Choose how mnscloud looks on this device.`),Gl(),is(14,`mat-radio-group`,7),qg(`change`,function(m){return t.setTheme(m.value)}),Bb(15,Me,9,4,`mat-radio-button`,8,Hb),Gl()(),Vg(17,`mat-divider`),is(18,`section`,4)(19,`h2`,5)(20,`mat-icon`),AC(21,`person`),Gl(),is(22,`span`),AC(23,`Profile & Account`),Gl()(),is(24,`p`,6),AC(25,` Manage your personal information and security in the “My Profile” page. `),Gl(),is(26,`p`,9),AC(27,` To change your name, phone, or password, use the `),is(28,`strong`),AC(29,`My Profile`),Gl(),AC(30,` option in the top-right menu. `),Gl()()()()),e&2&&(oD(14),jg(`value`,t.theme()),oD(),$b(t.themeOptions))},dependencies:[_,I,pe,G,w,Mt,wt,he,_e],styles:[`@charset "UTF-8";.settings-wrapper[_ngcontent-%COMP%]{display:flex;justify-content:center;padding:2rem 1.5rem;min-height:100vh;background:var(--%NS%mat-sys-color-surface)}.settings-card[_ngcontent-%COMP%]{width:100%;max-width:720px;padding:2rem 2.5rem;border-radius:1.25rem;background:var(--%NS%mat-sys-color-surface-container-high);border:1px solid var(--%NS%mat-sys-color-outline-variant);box-shadow:0 4px 18px #0000001a}.title[_ngcontent-%COMP%]{margin-bottom:.25rem;font-weight:700;color:var(--%NS%mat-sys-color-on-surface)}.subtitle[_ngcontent-%COMP%]{margin-bottom:2rem;color:var(--%NS%mat-sys-color-on-surface-variant)}.section-block[_ngcontent-%COMP%]{margin:2rem 0}.section-title[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.6rem;font-weight:600}.section-title[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:24px!important;width:32px;height:32px;display:flex;align-items:center;justify-content:center;color:var(--%NS%mat-sys-color-primary)}.section-description[_ngcontent-%COMP%]{font-size:.9rem;margin:.35rem 0 1rem;color:var(--%NS%mat-sys-color-on-surface-variant)}.theme-radio-group[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.75rem}.theme-radio[_ngcontent-%COMP%]{width:100%;padding:.25rem .5rem}.theme-option[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:.75rem}.theme-icon[_ngcontent-%COMP%]{font-size:24px!important;width:32px;height:32px;display:flex;align-items:center;justify-content:center;color:var(--%NS%mat-sys-color-primary)}.theme-text[_ngcontent-%COMP%]{display:flex;flex-direction:column}.theme-label[_ngcontent-%COMP%]{font-weight:600}.theme-description[_ngcontent-%COMP%]{font-size:.85rem;color:var(--%NS%mat-sys-color-on-surface-variant)}.hint-text[_ngcontent-%COMP%]{margin-top:.5rem;font-size:.9rem;color:var(--%NS%mat-sys-color-on-surface-variant)}@media(max-width:600px){.settings-card[_ngcontent-%COMP%]{padding:1.5rem 1.75rem}.section-block[_ngcontent-%COMP%]{margin:1.5rem 0}.theme-option[_ngcontent-%COMP%]{gap:.65rem}}`]})};export{ve as SettingsComponent};