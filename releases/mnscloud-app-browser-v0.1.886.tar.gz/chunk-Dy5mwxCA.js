import {T}from'./chunk-BhQFgbi-.js';import'./chunk-BSxj-mGa.js';import {d as de}from'./chunk-khLK0g_T.js';import {c as cn,k as ke,d as dn}from'./chunk-CsS-eljk.js';import'./chunk-ueqq3BvN.js';import {h,d as dt$1,v as ve,bp as $e,T as Te,t as tn,M as MT,c as j,B,F,b as vo,bq as it$1,br as HD,Q,e as Ql,f as ii,g as je$1,k as V,y as yt$1,q as Tt,u as dt$2,n as ae,s as se,L as Lt,R as Rt,W,K as Kt,w as Ws,C as dy,z as vT,x as rT,A as id,D as gC,H as dC,P as oy,I as db,O as ET,N as My,U as mC,X as dd,a0 as rd,_ as fC,aS as Xe,aT as xe,aV as G8,af as ce,b4 as sD,aW as uv,b0 as v,b8 as j8,aY as ge,ba as ii$1,bb as Ne,bc as Zy,aX as pf,be as Re,bf as m$1,bs as Rr,a_ as Fr,bg as AC,E as iy,bh as NC,a5 as FC,a9 as Iy,am as Py,a$ as xe$1,bt as q,bk as Ki,bd as iS,al as uy,aJ as WC,bi as gy,b2 as RC,b3 as OC,a6 as _C,a3 as SC,ac as Ay,bu as Xp,a7 as Bp,a8 as Vp,aL as Ny}from'./main-WUGCDT6U.js';import {p as pi,g as gi}from'./chunk-JU8kDM3s.js';import'./chunk-D6TWjG2B.js';var tt=["switch"],it=["*"];function at(m,t){m&1&&(Ws(0,"span",11),Xp(),Ws(1,"svg",13),iy(2,"path",14),id(),Ws(3,"svg",15),iy(4,"path",16),id()());}var nt=new v("mat-slide-toggle-default-options",{providedIn:"root",factory:()=>({disableToggleValue:false,hideIcon:false,disabledInteractive:false})}),z=class{source;checked;constructor(t,e){this.source=t,this.checked=e;}},X=(()=>{class m{_elementRef=h(ce);_focusMonitor=h(sD);_changeDetectorRef=h(uv);defaults=h(nt);_onChange=e=>{};_onTouched=()=>{};_validatorOnChange=()=>{};_uniqueId;_checked=false;_createChangeEvent(e){return new z(this,e)}_labelId;get buttonId(){return `${this.id||this._uniqueId}-button`}_switchElement;focus(){this._switchElement.nativeElement.focus();}_noopAnimations=j8();_focused=false;name=null;id;labelPosition="after";ariaLabel=null;ariaLabelledby=null;ariaDescribedby;required=false;color;disabled=false;disableRipple=false;tabIndex=0;get checked(){return this._checked}set checked(e){this._checked=e,this._changeDetectorRef.markForCheck();}hideIcon;disabledInteractive;change=new ge;toggleChange=new ge;get inputId(){return `${this.id||this._uniqueId}-input`}constructor(){h(ii$1).load(Ne);let e=h(new Zy("tabindex"),{optional:true}),i=this.defaults;this.tabIndex=e==null?0:parseInt(e)||0,this.color=i.color||"accent",this.id=this._uniqueId=h(pf).getId("mat-mdc-slide-toggle-"),this.hideIcon=i.hideIcon??false,this.disabledInteractive=i.disabledInteractive??false,this._labelId=this._uniqueId+"-label";}ngAfterContentInit(){this._focusMonitor.monitor(this._elementRef,true).subscribe(e=>{e==="keyboard"||e==="program"?(this._focused=true,this._changeDetectorRef.markForCheck()):e||Promise.resolve().then(()=>{this._focused=false,this._onTouched(),this._changeDetectorRef.markForCheck();});});}ngOnChanges(e){e.required&&this._validatorOnChange();}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef);}writeValue(e){this.checked=!!e;}registerOnChange(e){this._onChange=e;}registerOnTouched(e){this._onTouched=e;}validate(e){return this.required&&e.value!==true?{required:true}:null}registerOnValidatorChange(e){this._validatorOnChange=e;}setDisabledState(e){this.disabled=e,this._changeDetectorRef.markForCheck();}toggle(){this.checked=!this.checked,this._onChange(this.checked);}_emitChangeEvent(){this._onChange(this.checked),this.change.emit(this._createChangeEvent(this.checked));}_handleClick(){this.disabled||(this.toggleChange.emit(),this.defaults.disableToggleValue||(this.checked=!this.checked,this._onChange(this.checked),this.change.emit(new z(this,this.checked))));}_getAriaLabelledBy(){return this.ariaLabelledby?this.ariaLabelledby:this.ariaLabel?null:this._labelId}static \u0275fac=function(i){return new(i||m)};static \u0275cmp=Ql({type:m,selectors:[["mat-slide-toggle"]],viewQuery:function(i,a){if(i&1&&gy(tt,5),i&2){let r;RC(r=OC())&&(a._switchElement=r.first);}},hostAttrs:[1,"mat-mdc-slide-toggle"],hostVars:13,hostBindings:function(i,a){i&2&&(uy("id",a.id),rd("tabindex",null)("aria-label",null)("name",null)("aria-labelledby",null),WC(a.color?"mat-"+a.color:""),Iy("mat-mdc-slide-toggle-focused",a._focused)("mat-mdc-slide-toggle-checked",a.checked)("_mat-animation-noopable",a._noopAnimations));},inputs:{name:"name",id:"id",labelPosition:"labelPosition",ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],ariaDescribedby:[0,"aria-describedby","ariaDescribedby"],required:[2,"required","required",Fr],color:"color",disabled:[2,"disabled","disabled",Fr],disableRipple:[2,"disableRipple","disableRipple",Fr],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?0:iS(e)],checked:[2,"checked","checked",Fr],hideIcon:[2,"hideIcon","hideIcon",Fr],disabledInteractive:[2,"disabledInteractive","disabledInteractive",Fr]},outputs:{change:"change",toggleChange:"toggleChange"},exportAs:["matSlideToggle"],features:[Py([{provide:xe$1,useExisting:Ki(()=>m),multi:true},{provide:q,useExisting:m,multi:true}]),Rr],ngContentSelectors:it,decls:14,vars:27,consts:[["switch",""],["mat-internal-form-field","",3,"labelPosition"],["role","switch","type","button",1,"mdc-switch",3,"click","tabIndex","disabled"],[1,"mat-mdc-slide-toggle-touch-target"],[1,"mdc-switch__track"],[1,"mdc-switch__handle-track"],[1,"mdc-switch__handle"],[1,"mdc-switch__shadow"],[1,"mdc-elevation-overlay"],[1,"mdc-switch__ripple"],["mat-ripple","",1,"mat-mdc-slide-toggle-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled","matRippleCentered"],[1,"mdc-switch__icons"],[1,"mdc-label",3,"click","for"],["viewBox","0 0 24 24","aria-hidden","true",1,"mdc-switch__icon","mdc-switch__icon--on"],["d","M19.69,5.23L8.96,15.96l-4.23-4.23L2.96,13.5l6,6L21.46,7L19.69,5.23z"],["viewBox","0 0 24 24","aria-hidden","true",1,"mdc-switch__icon","mdc-switch__icon--off"],["d","M20 13H4v-2h16v2z"]],template:function(i,a){if(i&1&&(AC(),Ws(0,"div",1)(1,"button",2,0),dy("click",function(){return a._handleClick()}),iy(3,"div",3)(4,"span",4),Ws(5,"span",5)(6,"span",6)(7,"span",7),iy(8,"span",8),id(),Ws(9,"span",9),iy(10,"span",10),id(),dC(11,at,5,0,"span",11),id()()(),Ws(12,"label",12),dy("click",function(P){return P.stopPropagation()}),NC(13),id()()),i&2){let r=FC(2);oy("labelPosition",a.labelPosition),db(),Iy("mdc-switch--selected",a.checked)("mdc-switch--unselected",!a.checked)("mdc-switch--checked",a.checked)("mdc-switch--disabled",a.disabled)("mat-mdc-slide-toggle-disabled-interactive",a.disabledInteractive),oy("tabIndex",a.disabled&&!a.disabledInteractive?-1:a.tabIndex)("disabled",a.disabled&&!a.disabledInteractive),rd("id",a.buttonId)("name",a.name)("aria-label",a.ariaLabel)("aria-labelledby",a._getAriaLabelledBy())("aria-describedby",a.ariaDescribedby)("aria-required",a.required||null)("aria-checked",a.checked)("aria-disabled",a.disabled&&a.disabledInteractive?"true":null),db(9),oy("matRippleTrigger",r)("matRippleDisabled",a.disableRipple||a.disabled)("matRippleCentered",true),db(),fC(a.hideIcon?-1:11),db(),oy("for",a.buttonId),rd("id",a._labelId);}},dependencies:[Re,m$1],styles:[`.mdc-switch {
  align-items: center;
  background: none;
  border: none;
  cursor: pointer;
  display: inline-flex;
  flex-shrink: 0;
  margin: 0;
  outline: none;
  overflow: visible;
  padding: 0;
  position: relative;
  width: var(--mat-slide-toggle-track-width, 52px);
}
.mdc-switch.mdc-switch--disabled {
  cursor: default;
  pointer-events: none;
}
.mdc-switch.mat-mdc-slide-toggle-disabled-interactive {
  pointer-events: auto;
}

.mdc-switch__track {
  overflow: hidden;
  position: relative;
  width: 100%;
  height: var(--mat-slide-toggle-track-height, 32px);
  border-radius: var(--mat-slide-toggle-track-shape, var(--mat-sys-corner-full));
}
.mdc-switch--disabled.mdc-switch .mdc-switch__track {
  opacity: var(--mat-slide-toggle-disabled-track-opacity, 0.12);
}
.mdc-switch__track::before, .mdc-switch__track::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  height: 100%;
  left: 0;
  position: absolute;
  width: 100%;
  border-width: var(--mat-slide-toggle-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-track-outline-color, var(--mat-sys-outline));
}
.mdc-switch--selected .mdc-switch__track::before, .mdc-switch--selected .mdc-switch__track::after {
  border-width: var(--mat-slide-toggle-selected-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-selected-track-outline-color, transparent);
}
.mdc-switch--disabled .mdc-switch__track::before, .mdc-switch--disabled .mdc-switch__track::after {
  border-width: var(--mat-slide-toggle-disabled-unselected-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-disabled-unselected-track-outline-color, var(--mat-sys-on-surface));
}
@media (forced-colors: active) {
  .mdc-switch__track {
    border-color: currentColor;
  }
}
.mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0, 0, 0.2, 1);
  transform: translateX(0);
  background: var(--mat-slide-toggle-unselected-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch--selected .mdc-switch__track::before {
  transform: translateX(-100%);
}
.mdc-switch--selected .mdc-switch__track::before {
  opacity: var(--mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::before {
  opacity: var(--mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-hover-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-focus-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch:enabled:active .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-pressed-track-color, var(--mat-sys-surface-variant));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__track::before, .mdc-switch.mdc-switch--disabled .mdc-switch__track::before {
  background: var(--mat-slide-toggle-disabled-unselected-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch__track::after {
  transform: translateX(-100%);
  background: var(--mat-slide-toggle-selected-track-color, var(--mat-sys-primary));
}
[dir=rtl] .mdc-switch__track::after {
  transform: translateX(100%);
}
.mdc-switch--selected .mdc-switch__track::after {
  transform: translateX(0);
}
.mdc-switch--selected .mdc-switch__track::after {
  opacity: var(--mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::after {
  opacity: var(--mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-hover-track-color, var(--mat-sys-primary));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-focus-track-color, var(--mat-sys-primary));
}
.mdc-switch:enabled:active .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-pressed-track-color, var(--mat-sys-primary));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__track::after, .mdc-switch.mdc-switch--disabled .mdc-switch__track::after {
  background: var(--mat-slide-toggle-disabled-selected-track-color, var(--mat-sys-on-surface));
}

.mdc-switch__handle-track {
  height: 100%;
  pointer-events: none;
  position: absolute;
  top: 0;
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  left: 0;
  right: auto;
  transform: translateX(0);
  width: calc(100% - var(--mat-slide-toggle-handle-width));
}
[dir=rtl] .mdc-switch__handle-track {
  left: auto;
  right: 0;
}
.mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(-100%);
}

.mdc-switch__handle {
  display: flex;
  pointer-events: auto;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  left: 0;
  right: auto;
  transition: width 75ms cubic-bezier(0.4, 0, 0.2, 1), height 75ms cubic-bezier(0.4, 0, 0.2, 1), margin 75ms cubic-bezier(0.4, 0, 0.2, 1);
  width: var(--mat-slide-toggle-handle-width);
  height: var(--mat-slide-toggle-handle-height);
  border-radius: var(--mat-slide-toggle-handle-shape, var(--mat-sys-corner-full));
}
[dir=rtl] .mdc-switch__handle {
  left: auto;
  right: 0;
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle {
  width: var(--mat-slide-toggle-unselected-handle-size, 16px);
  height: var(--mat-slide-toggle-unselected-handle-size, 16px);
  margin: var(--mat-slide-toggle-unselected-handle-horizontal-margin, 0 8px);
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--mat-slide-toggle-unselected-with-icon-handle-horizontal-margin, 0 4px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle {
  width: var(--mat-slide-toggle-selected-handle-size, 24px);
  height: var(--mat-slide-toggle-selected-handle-size, 24px);
  margin: var(--mat-slide-toggle-selected-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--mat-slide-toggle-selected-with-icon-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch__handle:has(.mdc-switch__icons) {
  width: var(--mat-slide-toggle-with-icon-handle-size, 24px);
  height: var(--mat-slide-toggle-with-icon-handle-size, 24px);
}
.mat-mdc-slide-toggle .mdc-switch:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  width: var(--mat-slide-toggle-pressed-handle-size, 28px);
  height: var(--mat-slide-toggle-pressed-handle-size, 28px);
}
.mat-mdc-slide-toggle .mdc-switch--selected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--mat-slide-toggle-selected-pressed-handle-horizontal-margin, 0 22px);
}
.mat-mdc-slide-toggle .mdc-switch--unselected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--mat-slide-toggle-unselected-pressed-handle-horizontal-margin, 0 2px);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__handle::after {
  opacity: var(--mat-slide-toggle-disabled-selected-handle-opacity, 1);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__handle::after {
  opacity: var(--mat-slide-toggle-disabled-unselected-handle-opacity, 0.38);
}
.mdc-switch__handle::before, .mdc-switch__handle::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  width: 100%;
  height: 100%;
  left: 0;
  position: absolute;
  top: 0;
  transition: background-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1), border-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  z-index: -1;
}
@media (forced-colors: active) {
  .mdc-switch__handle::before, .mdc-switch__handle::after {
    border-color: currentColor;
  }
}
.mdc-switch--selected:enabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-handle-color, var(--mat-sys-on-primary));
}
.mdc-switch--selected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-hover-handle-color, var(--mat-sys-primary-container));
}
.mdc-switch--selected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-focus-handle-color, var(--mat-sys-primary-container));
}
.mdc-switch--selected:enabled:active .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-pressed-handle-color, var(--mat-sys-primary-container));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:hover:not(:focus):not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:focus:not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:active .mdc-switch__handle::after, .mdc-switch--selected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-disabled-selected-handle-color, var(--mat-sys-surface));
}
.mdc-switch--unselected:enabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-handle-color, var(--mat-sys-outline));
}
.mdc-switch--unselected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-hover-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-focus-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected:enabled:active .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-pressed-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-disabled-unselected-handle-color, var(--mat-sys-on-surface));
}
.mdc-switch__handle::before {
  background: var(--mat-slide-toggle-handle-surface-color);
}

.mdc-switch__shadow {
  border-radius: inherit;
  bottom: 0;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
}
.mdc-switch:enabled .mdc-switch__shadow {
  box-shadow: var(--mat-slide-toggle-handle-elevation-shadow);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__shadow, .mdc-switch.mdc-switch--disabled .mdc-switch__shadow {
  box-shadow: var(--mat-slide-toggle-disabled-handle-elevation-shadow);
}

.mdc-switch__ripple {
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  z-index: -1;
  width: var(--mat-slide-toggle-state-layer-size, 40px);
  height: var(--mat-slide-toggle-state-layer-size, 40px);
}
.mdc-switch__ripple::after {
  content: "";
  opacity: 0;
}
.mdc-switch--disabled .mdc-switch__ripple::after {
  display: none;
}
.mat-mdc-slide-toggle-disabled-interactive .mdc-switch__ripple::after {
  display: block;
}
.mdc-switch:hover .mdc-switch__ripple::after {
  transition: 75ms opacity cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:focus .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:active .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:hover:not(:focus) .mdc-switch__ripple::after, .mdc-switch--unselected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mdc-switch--unselected:enabled:focus .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mdc-switch--unselected:enabled:active .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-pressed-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}
.mdc-switch--selected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-hover-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mdc-switch--selected:enabled:focus .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-focus-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mdc-switch--selected:enabled:active .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-pressed-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}

.mdc-switch__icons {
  position: relative;
  height: 100%;
  width: 100%;
  z-index: 1;
  transform: translateZ(0);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__icons {
  opacity: var(--mat-slide-toggle-disabled-unselected-icon-opacity, 0.38);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__icons {
  opacity: var(--mat-slide-toggle-disabled-selected-icon-opacity, 0.38);
}

.mdc-switch__icon {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  opacity: 0;
  transition: opacity 30ms 0ms cubic-bezier(0.4, 0, 1, 1);
}
.mdc-switch--unselected .mdc-switch__icon {
  width: var(--mat-slide-toggle-unselected-icon-size, 16px);
  height: var(--mat-slide-toggle-unselected-icon-size, 16px);
  fill: var(--mat-slide-toggle-unselected-icon-color, var(--mat-sys-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--mat-slide-toggle-disabled-unselected-icon-color, var(--mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__icon {
  width: var(--mat-slide-toggle-selected-icon-size, 16px);
  height: var(--mat-slide-toggle-selected-icon-size, 16px);
  fill: var(--mat-slide-toggle-selected-icon-color, var(--mat-sys-on-primary-container));
}
.mdc-switch--selected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--mat-slide-toggle-disabled-selected-icon-color, var(--mat-sys-on-surface));
}

.mdc-switch--selected .mdc-switch__icon--on,
.mdc-switch--unselected .mdc-switch__icon--off {
  opacity: 1;
  transition: opacity 45ms 30ms cubic-bezier(0, 0, 0.2, 1);
}

.mat-mdc-slide-toggle {
  -webkit-user-select: none;
  user-select: none;
  display: inline-block;
  -webkit-tap-highlight-color: transparent;
  outline: 0;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple,
.mat-mdc-slide-toggle .mdc-switch__ripple::after {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple:not(:empty),
.mat-mdc-slide-toggle .mdc-switch__ripple::after:not(:empty) {
  transform: translateZ(0);
}
.mat-mdc-slide-toggle.mat-mdc-slide-toggle-focused .mat-focus-indicator::before {
  content: "";
}
.mat-mdc-slide-toggle .mat-internal-form-field {
  color: var(--mat-slide-toggle-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-slide-toggle-label-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-slide-toggle-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-slide-toggle-label-text-size, var(--mat-sys-body-medium-size));
  letter-spacing: var(--mat-slide-toggle-label-text-tracking, var(--mat-sys-body-medium-tracking));
  font-weight: var(--mat-slide-toggle-label-text-weight, var(--mat-sys-body-medium-weight));
}
.mat-mdc-slide-toggle .mat-ripple-element {
  opacity: 0.12;
}
.mat-mdc-slide-toggle .mat-focus-indicator::before {
  border-radius: 50%;
}
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle-track,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__icon,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::after,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::after {
  transition: none;
}
.mat-mdc-slide-toggle .mdc-switch:enabled + .mdc-label {
  cursor: pointer;
}
.mat-mdc-slide-toggle .mdc-switch--disabled + label {
  color: var(--mat-slide-toggle-disabled-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-slide-toggle label:empty {
  display: none;
}

.mat-mdc-slide-toggle-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--mat-slide-toggle-touch-target-size, 48px);
  width: 100%;
  transform: translate(-50%, -50%);
  display: var(--mat-slide-toggle-touch-target-display, block);
}
[dir=rtl] .mat-mdc-slide-toggle-touch-target {
  left: auto;
  right: 50%;
  transform: translate(50%, -50%);
}
`],encapsulation:2})}return m})(),qe=(()=>{class m{static \u0275fac=function(i){return new(i||m)};static \u0275mod=Xe({type:m});static \u0275inj=xe({imports:[X,G8]})}return m})();var rt=(m,t)=>t.code,Ze=(m,t)=>t.HsaUUID,Qe=(m,t)=>t.value;function lt(m,t){if(m&1&&(Ws(0,"mat-option",9),rT(1),vT(2,"transloco"),id()),m&2){let e=t.$implicit;oy("value",e.code),db(),dd(" ",ET(2,2,e.labelKey)," ");}}function st(m,t){if(m&1&&(rT(0),vT(1,"transloco"),vT(2,"transloco")),m&2){let e=SC(2);Ny(" ",ET(1,3,"SIAD Credentials Configured")," \xB7 ",ET(2,5,"Certificate expires"),": ",e.siadItem().credential?.certificateNotAfter," ");}}function dt(m,t){m&1&&(rT(0),vT(1,"transloco")),m&2&&dd(" ",ET(1,1,"SIAD Credentials Pending")," ");}function ct(m,t){if(m&1){let e=_C();Ws(0,"mat-tab",4),vT(1,"transloco"),Ws(2,"mat-tab-group",29)(3,"mat-tab",4),vT(4,"transloco"),Ws(5,"form",5)(6,"mat-form-field",30)(7,"mat-label"),rT(8),vT(9,"transloco"),id(),Ws(10,"mat-select",31),dy("selectionChange",function(a){Bp(e);let r=SC();return Vp(r.updateSiad({environment:a.value}))}),Ws(11,"mat-option",32),rT(12),vT(13,"transloco"),id(),Ws(14,"mat-option",33),rT(15),vT(16,"transloco"),id(),Ws(17,"mat-option",34),rT(18),vT(19,"transloco"),id()()(),Ws(20,"mat-form-field",30)(21,"mat-label"),rT(22),vT(23,"transloco"),id(),Ws(24,"input",35),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateSiad({origin:a.target.value}))}),id()(),Ws(25,"mat-form-field",30)(26,"mat-label"),rT(27),vT(28,"transloco"),id(),Ws(29,"input",35),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateSiad({suborigin:a.target.value}))}),id()(),Ws(30,"mat-form-field",30)(31,"mat-label"),rT(32),vT(33,"transloco"),id(),Ws(34,"input",36),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateSiad({referenciado:a.target.value}))}),id()(),Ws(35,"mat-form-field",6)(36,"mat-label"),rT(37),vT(38,"transloco"),id(),Ws(39,"input",37),vT(40,"transloco"),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateSiadCredentials({clientId:a.target.value}))}),id()(),Ws(41,"mat-form-field",6)(42,"mat-label"),rT(43),vT(44,"transloco"),id(),Ws(45,"input",38),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateSiadCredentials({clientSecret:a.target.value}))}),id(),Ws(46,"button",16),vT(47,"transloco"),dy("click",function(){Bp(e);let a=SC();return Vp(a.showSiadClientSecret.set(!a.showSiadClientSecret()))}),Ws(48,"mat-icon"),rT(49),id()()(),Ws(50,"input",39,0),dy("change",function(a){Bp(e);let r=SC();return Vp(r.selectSiadCertificate(a))}),id(),Ws(52,"input",40,1),dy("change",function(a){Bp(e);let r=SC();return Vp(r.selectSiadPrivateKey(a))}),id(),Ws(54,"mat-form-field",6)(55,"mat-label"),rT(56),vT(57,"transloco"),id(),iy(58,"input",41),vT(59,"transloco"),Ws(60,"button",16),vT(61,"transloco"),dy("click",function(){Bp(e);let a=FC(51);return Vp(a.click())}),Ws(62,"mat-icon"),rT(63,"upload_file"),id()()(),Ws(64,"mat-form-field",6)(65,"mat-label"),rT(66),vT(67,"transloco"),id(),iy(68,"input",41),vT(69,"transloco"),Ws(70,"button",16),vT(71,"transloco"),dy("click",function(){Bp(e);let a=FC(53);return Vp(a.click())}),Ws(72,"mat-icon"),rT(73,"upload_file"),id()()(),Ws(74,"p",42),dC(75,st,3,7)(76,dt,2,3),id(),Ws(77,"div",11)(78,"mat-slide-toggle",12),dy("change",function(a){Bp(e);let r=SC();return Vp(r.updateSiad({isActive:a.checked}))}),rT(79),vT(80,"transloco"),id()()()()()();}if(m&2){let e=SC();oy("label",ET(1,32,"Bradesco")),db(3),oy("label",ET(4,34,"SIAD")),db(5),My(ET(9,36,"SIAD Environment")),db(2),oy("value",e.siadItem().environment),db(2),My(ET(13,38,"Development")),db(3),My(ET(16,40,"Homologation")),db(3),My(ET(19,42,"Production")),db(4),My(ET(23,44,"Origin")),db(2),oy("value",e.siadItem().origin),db(3),My(ET(28,46,"Suborigin")),db(2),oy("value",e.siadItem().suborigin),db(3),My(ET(33,48,"Referenced")),db(2),oy("value",e.siadItem().referenciado),db(3),My(ET(38,50,"Client ID")),db(2),oy("value",e.siadCredentials().clientId)("placeholder",e.siadItem().credentialsConfigured?ET(40,52,"Configured. Enter to replace."):""),db(4),My(ET(44,54,"Client Secret")),db(2),oy("type",e.showSiadClientSecret()?"text":"password")("value",e.siadCredentials().clientSecret),db(),rd("aria-label",ET(47,56,"Toggle credential visibility")),db(3),My(e.showSiadClientSecret()?"visibility_off":"visibility"),db(7),My(ET(57,58,"mTLS Certificate")),db(2),oy("value",e.siadCertificateFile()?.name??e.siadItem().credential?.certificateFilename??"")("placeholder",ET(59,60,"Select certificate file")),db(2),rd("aria-label",ET(61,62,"Select certificate file")),db(6),My(ET(67,64,"mTLS Private Key")),db(2),oy("value",e.siadPrivateKeyFile()?.name??"")("placeholder",ET(69,66,"Select private key file")),db(2),rd("aria-label",ET(71,68,"Select private key file")),db(5),fC(e.siadItem().credentialsConfigured&&e.siadItem().credential?75:76),db(3),oy("checked",e.siadItem().isActive),db(),dd(" ",ET(80,70,"SIAD Integration Active")," ");}}function pt(m,t){if(m&1){let e=_C();Ws(0,"mat-tab",4),vT(1,"transloco"),Ws(2,"form",5)(3,"mat-form-field",14)(4,"mat-label"),rT(5),vT(6,"transloco"),id(),Ws(7,"input",15),vT(8,"transloco"),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateItem({signalWireRepoToken:a.target.value}))}),id(),Ws(9,"button",16),vT(10,"transloco"),dy("click",function(){Bp(e);let a=SC();return Vp(a.showSignalWireRepoToken.set(!a.showSignalWireRepoToken()))}),Ws(11,"mat-icon"),rT(12),id()()(),Ws(13,"div",11)(14,"mat-slide-toggle",12),dy("change",function(a){Bp(e);let r=SC();return Vp(r.updateItem({signalWireRepoTokenIsActive:a.checked}))}),rT(15),vT(16,"transloco"),id()()()();}if(m&2){let e=SC();oy("label",ET(1,9,"SignalWire")),db(5),My(ET(6,11,"SignalWire Repo Token")),db(2),oy("type",e.showSignalWireRepoToken()?"text":"password")("placeholder",ET(8,13,"SignalWire repository token for FreeSWITCH packages"))("value",e.item().signalWireRepoToken),db(2),rd("aria-label",ET(10,15,e.showSignalWireRepoToken()?"Hide SignalWire token":"Show SignalWire token")),db(3),My(e.showSignalWireRepoToken()?"visibility_off":"visibility"),db(2),oy("checked",e.item().signalWireRepoTokenIsActive),db(),dd(" ",ET(16,17,"SignalWire Repo Token Active")," ");}}function mt(m,t){if(m&1){let e=_C();Ws(0,"mat-tab",4),vT(1,"transloco"),Ws(2,"form",5)(3,"mat-form-field",20)(4,"mat-label"),rT(5),vT(6,"transloco"),id(),Ws(7,"input",43),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateItem({billingSignupTrialAmount:a.target.value}))}),id()(),Ws(8,"mat-form-field",20)(9,"mat-label"),rT(10),vT(11,"transloco"),id(),Ws(12,"input",7),vT(13,"transloco"),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateItem({billingSignupTrialCurrency:a.target.value}))}),id()(),Ws(14,"mat-form-field",20)(15,"mat-label"),rT(16),vT(17,"transloco"),id(),Ws(18,"input",44),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateItem({billingSignupTrialExpiresDays:a.target.value}))}),id()(),Ws(19,"mat-form-field",20)(20,"mat-label"),rT(21),vT(22,"transloco"),id(),Ws(23,"input",45),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateItem({signupMaxAccountsPerIpDay:a.target.value}))}),id()(),Ws(24,"mat-form-field",20)(25,"mat-label"),rT(26),vT(27,"transloco"),id(),Ws(28,"input",46),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateItem({authSessionHours:a.target.value}))}),id()(),Ws(29,"mat-form-field",20)(30,"mat-label"),rT(31),vT(32,"transloco"),id(),Ws(33,"input",47),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateItem({authRememberMeHours:a.target.value}))}),id()(),Ws(34,"mat-form-field",20)(35,"mat-label"),rT(36),vT(37,"transloco"),id(),Ws(38,"mat-select",31),dy("selectionChange",function(a){Bp(e);let r=SC();return Vp(r.updateItem({signupCaptchaProvider:a.value}))}),Ws(39,"mat-option",21),rT(40),vT(41,"transloco"),id(),Ws(42,"mat-option",48),rT(43),vT(44,"transloco"),id(),Ws(45,"mat-option",49),rT(46),vT(47,"transloco"),id()()(),Ws(48,"mat-form-field",50)(49,"mat-label"),rT(50),vT(51,"transloco"),id(),Ws(52,"input",10),vT(53,"transloco"),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateItem({signupCaptchaSiteKey:a.target.value}))}),id()(),Ws(54,"mat-form-field",14)(55,"mat-label"),rT(56),vT(57,"transloco"),id(),Ws(58,"input",15),vT(59,"transloco"),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateItem({signupCaptchaSecret:a.target.value}))}),id(),Ws(60,"button",16),vT(61,"transloco"),dy("click",function(){Bp(e);let a=SC();return Vp(a.showSignupCaptchaSecret.set(!a.showSignupCaptchaSecret()))}),Ws(62,"mat-icon"),rT(63),id()()(),Ws(64,"div",11)(65,"mat-slide-toggle",12),dy("change",function(a){Bp(e);let r=SC();return Vp(r.updateItem({billingSignupTrialEnabled:a.checked}))}),rT(66),vT(67,"transloco"),id(),Ws(68,"mat-slide-toggle",12),dy("change",function(a){Bp(e);let r=SC();return Vp(r.updateItem({billingSignupTrialRequireEmailVerified:a.checked}))}),rT(69),vT(70,"transloco"),id(),Ws(71,"mat-slide-toggle",12),dy("change",function(a){Bp(e);let r=SC();return Vp(r.updateItem({signupCaptchaEnabled:a.checked}))}),rT(72),vT(73,"transloco"),id(),Ws(74,"mat-slide-toggle",12),dy("change",function(a){Bp(e);let r=SC();return Vp(r.updateItem({loginCaptchaEnabled:a.checked}))}),rT(75),vT(76,"transloco"),id(),Ws(77,"mat-slide-toggle",12),dy("change",function(a){Bp(e);let r=SC();return Vp(r.updateItem({authRememberMeEnabled:a.checked}))}),rT(78),vT(79,"transloco"),id()()()();}if(m&2){let e=SC();oy("label",ET(1,38,"Access")),db(5),My(ET(6,40,"Trial Credit Amount")),db(2),oy("value",e.item().billingSignupTrialAmount),db(3),My(ET(11,42,"Trial Credit Currency")),db(2),oy("placeholder",ET(13,44,"BRL"))("value",e.item().billingSignupTrialCurrency),db(4),My(ET(17,46,"Trial Expires Days")),db(2),oy("value",e.item().billingSignupTrialExpiresDays),db(3),My(ET(22,48,"Max Accounts per IP/Day")),db(2),oy("value",e.item().signupMaxAccountsPerIpDay),db(3),My(ET(27,50,"Session Hours")),db(2),oy("value",e.item().authSessionHours),db(3),My(ET(32,52,"Remember Me Hours")),db(2),oy("value",e.item().authRememberMeHours),db(3),My(ET(37,54,"Captcha Provider")),db(2),oy("value",e.item().signupCaptchaProvider),db(2),My(ET(41,56,"None")),db(3),My(ET(44,58,"Cloudflare Turnstile")),db(3),My(ET(47,60,"hCaptcha")),db(4),My(ET(51,62,"Captcha Site Key")),db(2),oy("placeholder",ET(53,64,"Public site key"))("value",e.item().signupCaptchaSiteKey),db(4),My(ET(57,66,"Captcha Secret")),db(2),oy("type",e.showSignupCaptchaSecret()?"text":"password")("placeholder",ET(59,68,"Private validation secret"))("value",e.item().signupCaptchaSecret),db(2),rd("aria-label",ET(61,70,e.showSignupCaptchaSecret()?"Hide captcha secret":"Show captcha secret")),db(3),My(e.showSignupCaptchaSecret()?"visibility_off":"visibility"),db(2),oy("checked",e.item().billingSignupTrialEnabled),db(),dd(" ",ET(67,72,"Trial Credit Active")," "),db(2),oy("checked",e.item().billingSignupTrialRequireEmailVerified),db(),dd(" ",ET(70,74,"Require Verified Email")," "),db(2),oy("checked",e.item().signupCaptchaEnabled),db(),dd(" ",ET(73,76,"Signup Captcha Active")," "),db(2),oy("checked",e.item().loginCaptchaEnabled),db(),dd(" ",ET(76,78,"Login Captcha Active")," "),db(2),oy("checked",e.item().authRememberMeEnabled),db(),dd(" ",ET(79,80,"Remember Me Active")," ");}}function ut(m,t){if(m&1&&(Ws(0,"mat-option",9),rT(1),id()),m&2){let e=t.$implicit;oy("value",e.HsaUUID),db(),Ay(" ",e.HsaName," \xB7 ",e.HspProvider||e.HspName," ");}}function gt(m,t){if(m&1&&(Ws(0,"mat-option",9),rT(1),id()),m&2){let e=t.$implicit;oy("value",e.HsaUUID),db(),Ay(" ",e.HsaName," \xB7 ",e.HspProvider||e.HspName," ");}}function bt(m,t){if(m&1&&(Ws(0,"mat-option",9),rT(1),vT(2,"transloco"),id()),m&2){let e=t.$implicit;oy("value",e.value),db(),My(ET(2,2,e.label));}}function ht(m,t){if(m&1){let e=_C();Ws(0,"mat-form-field",6)(1,"mat-label"),rT(2),vT(3,"transloco"),id(),Ws(4,"mat-select",31),dy("selectionChange",function(a){Bp(e);let r=SC();return Vp(r.updateItem({voipPabxRealmSource:a.value}))}),gC(5,bt,3,4,"mat-option",9,Qe),id()();}if(m&2){let e=SC();db(2),My(ET(3,2,"Configuration source")),db(2),oy("value",e.item().voipPabxRealmSource),db(),mC(e.realmSources);}}function vt(m,t){if(m&1&&(Ws(0,"mat-option",9),rT(1),vT(2,"transloco"),id()),m&2){let e=t.$implicit;oy("value",e.value),db(),My(ET(2,2,e.label));}}function _t(m,t){if(m&1&&(Ws(0,"p",54),rT(1),vT(2,"transloco"),id()),m&2){let e=SC(3);db(),dd(" ",ET(2,1,e.selectedPolicyError())," ");}}function ft(m,t){if(m&1){let e=_C();Ws(0,"mns-search-select-field",53),vT(1,"transloco"),vT(2,"transloco"),dy("searchChange",function(a){Bp(e);let r=SC(2);return Vp(r.searchDnsPolicies(a))})("pageChange",function(a){Bp(e);let r=SC(2);return Vp(r.pageDnsPolicies(a))})("openedChange",function(a){Bp(e);let r=SC(2);return Vp(a&&r.refreshDnsPolicies())})("valueChange",function(a){Bp(e);let r=SC(2);return Vp(r.selectDnsPolicy(a))}),id(),dC(3,_t,3,3,"p",54);}if(m&2){let e=SC(2);oy("label",ET(1,10,"Domain for Realm SIP publication"))("options",e.dnsPolicyOptions())("remoteSearch",true)("loading",e.dnsLoading())("loadError",e.dnsLoadError())("hasPrevious",e.dnsOffset()>0)("hasNext",e.dnsOffset()+50<e.dnsTotal())("value",e.item().voipPabxDnsPolicyUUID)("help",ET(2,12,"Managed DNS publishes A and optional AAAA in an authorized zone. Existing SIP realms are not changed.")),db(3),fC(e.selectedPolicyInvalid()?3:-1);}}function yt(m,t){if(m&1){let e=_C();Ws(0,"mat-form-field",14)(1,"mat-label"),rT(2),vT(3,"transloco"),id(),Ws(4,"input",10),dy("input",function(a){Bp(e);let r=SC(2);return Vp(r.updateItem({voipPabxAutoDomainBase:a.target.value}))}),id()();}if(m&2){let e=SC(2);db(2),My(ET(3,3,"PABX SIP realm base")),db(2),oy("placeholder",e.voipPabxAutoDomainBasePlaceholder())("value",e.item().voipPabxAutoDomainBase);}}function St(m,t){if(m&1){let e=_C();Ws(0,"mat-form-field",6)(1,"mat-label"),rT(2),vT(3,"transloco"),id(),Ws(4,"mat-select",31),dy("selectionChange",function(a){Bp(e);let r=SC();return Vp(r.updateItem({voipPabxAutoDomainDnsMode:a.value}))}),gC(5,vt,3,4,"mat-option",9,Qe),id()(),dC(7,ft,4,14)(8,yt,5,5,"mat-form-field",14),Ws(9,"mat-form-field",6)(10,"mat-label"),rT(11),vT(12,"transloco"),id(),Ws(13,"mat-select",31),dy("selectionChange",function(a){Bp(e);let r=SC();return Vp(r.updateItem({voipPabxAutoDomainLabelMode:a.value}))}),Ws(14,"mat-option",51),rT(15),vT(16,"transloco"),id()()(),Ws(17,"mat-form-field",6)(18,"mat-label"),rT(19),vT(20,"transloco"),id(),Ws(21,"input",52),dy("input",function(a){Bp(e);let r=SC();return Vp(r.updateItem({voipPabxAutoDomainUuidLength:a.target.value}))}),id()(),Ws(22,"div",11)(23,"mat-slide-toggle",12),dy("change",function(a){Bp(e);let r=SC();return Vp(r.updateItem({voipPabxAutoDomainEnabled:a.checked}))}),rT(24),vT(25,"transloco"),id(),Ws(26,"mat-slide-toggle",12),dy("change",function(a){Bp(e);let r=SC();return Vp(r.updateItem({voipPabxAutoDomainSetDefault:a.checked}))}),rT(27),vT(28,"transloco"),id(),Ws(29,"mat-slide-toggle",12),dy("change",function(a){Bp(e);let r=SC();return Vp(r.updateItem({voipPabxAutoDomainIsActive:a.checked}))}),rT(30),vT(31,"transloco"),id()();}if(m&2){let e=SC();db(2),My(ET(3,14,"PABX SIP realm DNS mode")),db(2),oy("value",e.item().voipPabxAutoDomainDnsMode),db(),mC(e.realmDnsModes),db(2),fC(e.item().voipPabxAutoDomainDnsMode==="managed_dns"?7:8),db(4),My(ET(12,16,"PABX SIP realm label")),db(2),oy("value",e.item().voipPabxAutoDomainLabelMode),db(2),My(ET(16,18,"Short UUID")),db(4),My(ET(20,20,"PABX SIP realm UUID length")),db(2),oy("value",e.item().voipPabxAutoDomainUuidLength),db(2),oy("checked",e.item().voipPabxAutoDomainEnabled),db(),dd(" ",ET(25,22,"Create PABX SIP realm automatically")," "),db(2),oy("checked",e.item().voipPabxAutoDomainSetDefault),db(),dd(" ",ET(28,24,"Set generated PABX SIP realm as default")," "),db(2),oy("checked",e.item().voipPabxAutoDomainIsActive),db(),dd(" ",ET(31,26,"PABX SIP realm automation active")," ");}}function Pt(m,t){if(m&1&&(Ws(0,"p",54),rT(1),vT(2,"transloco"),id()),m&2){let e=SC(2);db(),dd(" ",ET(2,1,e.inheritedPolicyError())," ");}}function xt(m,t){if(m&1&&(Ws(0,"mat-form-field",6)(1,"mat-label"),rT(2),vT(3,"transloco"),id(),iy(4,"input",55),vT(5,"transloco"),id(),Ws(6,"mat-form-field",6)(7,"mat-label"),rT(8),vT(9,"transloco"),id(),iy(10,"input",55),id(),dC(11,Pt,3,3,"p",54),Ws(12,"p",56),rT(13),vT(14,"transloco"),id()),m&2){let e=SC();db(2),My(ET(3,6,"Inherited publication mode")),db(2),oy("value",ET(5,8,e.inheritedModeLabel())),db(4),My(ET(9,10,"Inherited SIP Realm domain")),db(2),oy("value",e.inheritedDomainLabel()),db(),fC(e.inheritedPolicyInvalid()?11:-1),db(2),dd(" ",ET(14,12,"New PABX accounts inherit the complete platform Realm SIP configuration.")," ");}}var G={environment:"dsv",origin:"",suborigin:"",referenciado:"",isActive:false,credentialsConfigured:false,credentialsUpdatedAt:null,credential:null},O={clientId:"",clientSecret:""},M={sprUUID:null,googleMapsEmbedApiKey:"",googleMapsEmbedApiKeyIsActive:true,mapboxToken:"",mapboxTokenIsActive:true,signalWireRepoToken:"",signalWireRepoTokenIsActive:true,defaultCurrency:"BRL",defaultCurrencyIsActive:true,defaultLanguage:"pt-BR",defaultLanguageIsActive:true,defaultTimezone:"",defaultTimezoneIsActive:true,voipPabxRecordingStorageMode:"",voipPabxRecordingStorageAccountUUID:"",voipPabxRecordingStorageIsActive:true,voipPabxMediaStorageMode:"",voipPabxMediaStorageAccountUUID:"",voipPabxMediaStorageIsActive:true,voipPabxMediaDeliveryMode:"",voipPabxMediaDeliveryModeIsActive:true,voipPabxRemoteCommandExecutor:"",voipPabxRemoteCommandExecutorIsActive:true,voipPabxAutoDomainEnabled:true,voipPabxAutoDomainBase:"pabx.publichost.cloud",voipPabxAutoDomainLabelMode:"uuid_short",voipPabxAutoDomainUuidLength:12,voipPabxAutoDomainSetDefault:true,voipPabxAutoDomainDnsMode:"identity_only",voipPabxRealmSource:"inherit",voipPabxDnsPolicyUUID:"",voipPabxDnsPolicyBase:null,voipPabxDnsPolicyZoneName:null,voipPabxDnsPolicyEligible:null,voipPabxDnsPolicyError:null,voipPabxEffectiveSource:"platform",voipPabxEffectiveDnsMode:"identity_only",voipPabxEffectiveBase:"pabx.publichost.cloud",voipPabxEffectiveZoneName:null,voipPabxEffectivePolicyUUID:null,voipPabxEffectivePolicyEligible:true,voipPabxEffectivePolicyError:null,voipPabxInheritedDnsMode:"identity_only",voipPabxInheritedBase:"pabx.publichost.cloud",voipPabxInheritedZoneName:null,voipPabxInheritedPolicyUUID:null,voipPabxAutoDomainIsActive:true,billingSignupTrialEnabled:false,billingSignupTrialAmount:0,billingSignupTrialCurrency:"BRL",billingSignupTrialExpiresDays:15,billingSignupTrialRequireEmailVerified:true,signupCaptchaEnabled:false,signupCaptchaProvider:"",signupCaptchaSiteKey:"",signupCaptchaSecret:"",signupMaxAccountsPerIpDay:3,loginCaptchaEnabled:false,authRememberMeEnabled:true,authSessionHours:12,authRememberMeHours:720},je=class m{api=h(dt$1);dnsPolicies=ve([]);translation=h($e);destroyRef=h(Te);dnsOffset=ve(0);dnsSearch=ve("");dnsTimer;dnsTotal=tn(()=>this.dnsResource.value()?.total??0);dnsLoading=tn(()=>this.dnsResource.isLoading());dnsLoadError=tn(()=>!!this.dnsResource.error());dnsResource=MT({params:()=>({endpoint:this.baseEndpoint(),search:this.dnsSearch(),offset:this.dnsOffset()}),defaultValue:{items:[],total:0},loader:async({params:t})=>{let e=new URLSearchParams({search:t.search,limit:"50",offset:String(t.offset)}),i=await this.api.get(`${t.endpoint}/pabx-dns-policies?${e}`);return {items:i?.data?.items??[],total:Number(i?.data?.total??0)}}});searchDnsPolicies(t){clearTimeout(this.dnsTimer),this.dnsTimer=setTimeout(()=>{this.dnsOffset.set(0),this.dnsSearch.set(t);},250);}pageDnsPolicies(t){this.dnsOffset.update(e=>Math.max(0,e+t*50));}refreshDnsPolicies(){this.dnsResource.reload();}dnsPolicyOptions=tn(()=>{this.i18n.language();let t=this.dnsPolicies(),e=this.item().voipPabxDnsPolicyUUID,i=t.filter(a=>a.status&&a.eligible!==false).map(a=>({value:a.policyUUID,label:`${a.zoneName||a.base} \u2014 ${this.translation.translate("SIP realm base")}: ${a.base}`,searchText:`${a.zoneName??""} ${a.base}`}));if(e&&!i.some(a=>a.value===e)){let a=t.find(Je=>Je.policyUUID===e),r=a?.zoneName||this.item().voipPabxDnsPolicyZoneName||"",P=a?.base||this.item().voipPabxDnsPolicyBase||"",N=this.item().voipPabxDnsPolicyEligible!==true?` (${this.translation.translate("Unavailable")})`:"",Ye=r||P?`${r||P} \u2014 ${this.translation.translate("SIP realm base")}: ${P}${N}`:`${e}${N}`;i.unshift({value:e,label:Ye,searchText:e});}return i});realmSources=[{value:"inherit",label:"Inherit platform configuration"},{value:"own",label:"Use own configuration"}];realmDnsModes=[{value:"identity_only",label:"SIP identity without DNS publication"},{value:"managed_dns",label:"Managed DNS publication"}];selectDnsPolicy(t){let e=String(t??""),i=this.dnsPolicies().find(a=>a.policyUUID===e);this.updateItem(j({voipPabxDnsPolicyUUID:e},i?{voipPabxAutoDomainBase:i.base,voipPabxDnsPolicyBase:i.base,voipPabxDnsPolicyZoneName:i.zoneName,voipPabxDnsPolicyEligible:i.eligible!==false,voipPabxDnsPolicyError:null}:{}));}effectiveBase=tn(()=>{let t=this.item();return !this.isMaster()&&t.voipPabxRealmSource==="inherit"?t.voipPabxInheritedBase||t.voipPabxEffectiveBase||"pabx.publichost.cloud":t.voipPabxAutoDomainDnsMode==="managed_dns"?this.dnsPolicies().find(i=>i.policyUUID===t.voipPabxDnsPolicyUUID)?.base||t.voipPabxDnsPolicyBase||t.voipPabxAutoDomainBase||"pabx.publichost.cloud":t.voipPabxAutoDomainBase||"pabx.publichost.cloud"});inheritedDomainLabel=tn(()=>{let t=this.item(),e=t.voipPabxInheritedDnsMode||t.voipPabxEffectiveDnsMode,i=this.effectiveBase(),a=t.voipPabxInheritedZoneName||t.voipPabxEffectiveZoneName;return e==="managed_dns"&&(a||i)&&a?`${a} \u2014 Base SIP: ${i}`:i});inheritedModeLabel=tn(()=>(this.item().voipPabxInheritedDnsMode||this.item().voipPabxEffectiveDnsMode)==="managed_dns"?"Managed DNS publication":"SIP identity without DNS publication");selectedPolicyInvalid=tn(()=>{let t=this.item();if(t.voipPabxAutoDomainDnsMode!=="managed_dns"||t.voipPabxRealmSource==="inherit"&&!this.isMaster()||!t.voipPabxDnsPolicyUUID)return  false;if(t.voipPabxDnsPolicyEligible===false)return  true;let e=this.dnsPolicies().find(i=>i.policyUUID===t.voipPabxDnsPolicyUUID);return e?e.eligible===false||!e.status:t.voipPabxDnsPolicyEligible!==true});selectedPolicyError=tn(()=>{let t=this.item();if(t.voipPabxDnsPolicyError)return t.voipPabxDnsPolicyError;let e=this.dnsPolicies().find(i=>i.policyUUID===t.voipPabxDnsPolicyUUID);return e?e.status?e.eligible===false?"The selected DNS domain is not fully provisioned or its provider is inactive.":"The selected DNS policy is invalid.":"The selected DNS domain policy is disabled.":"The selected DNS domain policy is unavailable or has been deleted. Please select an active domain."});inheritedPolicyInvalid=tn(()=>{let t=this.item();return this.isMaster()||t.voipPabxRealmSource!=="inherit"||(t.voipPabxInheritedDnsMode||t.voipPabxEffectiveDnsMode)!=="managed_dns"?false:t.voipPabxEffectivePolicyEligible===false});inheritedPolicyError=tn(()=>this.item().voipPabxEffectivePolicyError||"The inherited platform DNS policy is currently unavailable.");route=h(B);i18n=h(F);scope=ve(this.route.snapshot.data?.scope??"tenant");isMaster=tn(()=>this.scope()==="master");pageTitle=tn(()=>this.isMaster()?"System Parameters":"Parameters");pageSubtitle=tn(()=>this.isMaster()?"Single master record with global default values.":"Single tenant record. Empty tenant values fallback to master defaults.");defaultTimezonePlaceholder=tn(()=>this.isMaster()?"UTC":"Master timezone");voipPabxRecordingStoragePlaceholder=tn(()=>this.isMaster()?"Filesystem":"Master recording storage");voipPabxMediaStoragePlaceholder=tn(()=>this.isMaster()?"Filesystem":"Master media file storage");voipPabxMediaDeliveryPlaceholder=tn(()=>this.isMaster()?"Offline":"Master media file delivery");voipPabxRemoteCommandExecutorPlaceholder=tn(()=>this.isMaster()?"Agent":"Master remote command executor");voipPabxAutoDomainBasePlaceholder=tn(()=>this.isMaster()?"pabx.publichost.cloud":"Master PABX SIP realm base");baseEndpoint=tn(()=>this.isMaster()?"system/parameters":"settings/parameters");languageOptions=this.i18n.availableLanguages;parametersResource=MT({params:()=>({endpoint:this.baseEndpoint(),isMaster:this.isMaster()}),defaultValue:{item:j({},M),storageAccounts:[],dnsPolicies:[]},loader:({params:t})=>this.loadParametersSnapshot(t.endpoint,t.isMaster)});siadResource=MT({params:()=>this.isMaster()?void 0:true,defaultValue:j({},G),loader:()=>this.loadSiad()});loading=tn(()=>this.parametersResource.isLoading()||!this.isMaster()&&this.siadResource.isLoading());saving=ve(false);feedback=ve(null);success=ve(null);showGoogleMapsEmbedApiKey=ve(false);showMapboxToken=ve(false);showSignalWireRepoToken=ve(false);showSignupCaptchaSecret=ve(false);item=ve(j({},M));baselineItem=ve(j({},M));storageAccounts=ve([]);baselineSignature=ve("");siadItem=ve(j({},G));baselineSiad=ve(j({},G));siadCredentials=ve(j({},O));siadCertificateFile=ve(null);siadPrivateKeyFile=ve(null);baselineSiadSignature=ve("");showSiadClientSecret=ve(false);showSiadPrivateKey=ve(false);hasChanges=tn(()=>this.buildSignature(this.item())!==this.baselineSignature()||!this.isMaster()&&this.buildSiadSignature(this.siadItem())!==this.baselineSiadSignature()||!this.isMaster()&&Object.values(this.siadCredentials()).some(t=>t.trim()!==""));constructor(){vo(()=>{this.dnsResource.hasValue()&&this.dnsPolicies.set(this.dnsResource.value().items);}),this.destroyRef.onDestroy(()=>{clearTimeout(this.dnsTimer);}),vo(()=>{let t=this.parametersResource.hasValue()?this.parametersResource.value():void 0;t&&(this.storageAccounts.set(t.storageAccounts),this.dnsPolicies.set(t.dnsPolicies),this.item.set(t.item),this.baselineItem.set(j({},t.item)),this.baselineSignature.set(this.buildSignature(t.item)));}),vo(()=>{if(this.isMaster()||!this.siadResource.hasValue())return;let t=this.siadResource.value();this.siadItem.set(t),this.baselineSiad.set(j({},t)),this.baselineSiadSignature.set(this.buildSiadSignature(t)),this.siadCredentials.set(j({},O));}),vo(()=>{let t=this.parametersResource.error();t&&(this.feedback.set(this.friendlyError(t,"Failed to load parameters.")),this.item.set(j({},M)),this.baselineItem.set(j({},M)),this.storageAccounts.set([]),this.baselineSignature.set(this.buildSignature(M)));}),vo(()=>{if(this.isMaster())return;let t=this.siadResource.error();t&&this.feedback.set(this.friendlyError(t,"Failed to load SIAD integration."));});}refreshItems(){this.hasChanges()||this.saving()||(this.feedback.set(null),this.success.set(null),this.parametersResource.reload(),this.isMaster()||this.siadResource.reload());}updateItem(t){this.item.set(j(j({},this.item()),t));}updateSiad(t){this.siadItem.set(j(j({},this.siadItem()),t));}updateSiadCredentials(t){this.siadCredentials.set(j(j({},this.siadCredentials()),t));}selectSiadCertificate(t){let e=t.target,i=e.files?.[0]??null;this.siadCertificateFile.set(i),e.value="";}selectSiadPrivateKey(t){let e=t.target,i=e.files?.[0]??null;this.siadPrivateKeyFile.set(i),e.value="";}cancelChanges(){this.item.set(j({},this.baselineItem())),this.siadItem.set(j({},this.baselineSiad())),this.siadCredentials.set(j({},O)),this.siadCertificateFile.set(null),this.siadPrivateKeyFile.set(null),this.feedback.set(null),this.success.set(null);}async saveAll(){if(!(!this.hasChanges()||this.saving()||this.loading())){this.saving.set(true),this.feedback.set(null),this.success.set(null);try{if(this.buildSignature(this.item())!==this.baselineSignature()){let e=this.normalizeForSave(this.item()),i=await this.api.put(this.baseEndpoint(),{item:e}),a=this.readItem(i);this.item.set(a),this.baselineItem.set(j({},a)),this.baselineSignature.set(this.buildSignature(a)),a.defaultLanguageIsActive&&it$1(a.defaultLanguage)&&this.i18n.applyResolvedSystemLanguage(a.defaultLanguage,!0);}if(!this.isMaster()){let e=this.buildSiadSignature(this.siadItem())!==this.baselineSiadSignature(),i=this.siadItem();if(e){let w=await this.api.put("settings/integrations/bradesco/siad",this.siadItem());i=this.readSiad(w);}let a=this.siadCertificateFile(),r=this.siadPrivateKeyFile();if(Object.values(this.siadCredentials()).some(w=>w.trim()!=="")||a||r){if(!a||!r)throw new Error("Select both the SIAD certificate and private key.");let w=new FormData;w.set("clientId",this.siadCredentials().clientId),w.set("clientSecret",this.siadCredentials().clientSecret),w.set("certificate",a,a.name),w.set("privateKey",r,r.name);let N=await HD(this.api.postFormWithProgress("settings/integrations/bradesco/siad/credentials",w));i=this.readSiad(N.response);}this.siadItem.set(i),this.baselineSiad.set(j({},i)),this.baselineSiadSignature.set(this.buildSiadSignature(i)),this.siadCredentials.set(j({},O)),this.siadCertificateFile.set(null),this.siadPrivateKeyFile.set(null);}this.success.set("Parameters saved successfully.");}catch(t){this.feedback.set(this.friendlyError(t,"Failed to save parameters."));}finally{this.saving.set(false);}}}readItem(t){let e=t?.data?.item;if(e&&typeof e=="object")return this.normalizeIncoming(e);let i=Array.isArray(t?.data?.items)?t.data.items:[];return this.fromLegacyItems(i)}fromLegacyItems(t){let e=j({},M);for(let i of t){let a=String(i?.SprKey??"").toUpperCase(),r=i?.SprValue===null||i?.SprValue===void 0?"":String(i.SprValue),P=Number(i?.SprIsActive??1)===1;a==="GOOGLE_MAPS_EMBED_API_KEY"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.googleMapsEmbedApiKey=r,e.googleMapsEmbedApiKeyIsActive=P):a==="MAPBOX_TOKEN"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.mapboxToken=r,e.mapboxTokenIsActive=P):a==="SIGNALWIRE_REPO_TOKEN"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.signalWireRepoToken=r,e.signalWireRepoTokenIsActive=P):a==="DEFAULT_CURRENCY"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.defaultCurrency=r||"BRL",e.defaultCurrencyIsActive=P):a==="DEFAULT_LANGUAGE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.defaultLanguage=r||"pt-BR",e.defaultLanguageIsActive=P):a==="DEFAULT_TIMEZONE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.defaultTimezone=r,e.defaultTimezoneIsActive=P):a==="VOIP_PABX_RECORDING_STORAGE_MODE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxRecordingStorageMode=this.normalizeStorageMode(r),e.voipPabxRecordingStorageIsActive=P):a==="VOIP_PABX_RECORDING_STORAGE_ACCOUNT"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxRecordingStorageAccountUUID=r):a==="VOIP_PABX_MEDIA_STORAGE_MODE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxMediaStorageMode=this.normalizeStorageMode(r),e.voipPabxMediaStorageIsActive=P):a==="VOIP_PABX_MEDIA_STORAGE_ACCOUNT"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxMediaStorageAccountUUID=r):a==="VOIP_PABX_MEDIA_DELIVERY_MODE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxMediaDeliveryMode=this.normalizeDeliveryMode(r),e.voipPabxMediaDeliveryModeIsActive=P):a==="VOIP_PABX_REMOTE_COMMAND_EXECUTOR"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxRemoteCommandExecutor=this.normalizeRemoteCommandExecutor(r),e.voipPabxRemoteCommandExecutorIsActive=P):a==="VOIP_PABX_AUTO_DOMAIN_ENABLED"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainEnabled=r===""?true:Number(r)!==0):a==="VOIP_PABX_AUTO_DOMAIN_BASE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainBase=r||M.voipPabxAutoDomainBase):a==="VOIP_PABX_AUTO_DOMAIN_LABEL_MODE"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainLabelMode=this.normalizePabxAutoDomainLabelMode(r)):a==="VOIP_PABX_AUTO_DOMAIN_UUID_LENGTH"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainUuidLength=this.clampInteger(r||12,8,32)):a==="VOIP_PABX_AUTO_DOMAIN_SET_DEFAULT"?(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainSetDefault=r===""?true:Number(r)!==0):a==="VOIP_PABX_AUTO_DOMAIN_DNS_MODE"&&(e.sprUUID=e.sprUUID||String(i?.SprUUID??""),e.voipPabxAutoDomainDnsMode=this.normalizePabxAutoDomainDnsMode(r),e.voipPabxAutoDomainIsActive=P);}return e}normalizeIncoming(t){return {sprUUID:typeof t?.sprUUID=="string"&&t.sprUUID.trim()?t.sprUUID:null,googleMapsEmbedApiKey:String(t?.googleMapsEmbedApiKey??""),googleMapsEmbedApiKeyIsActive:t?.googleMapsEmbedApiKeyIsActive!==false,mapboxToken:String(t?.mapboxToken??""),mapboxTokenIsActive:t?.mapboxTokenIsActive!==false,signalWireRepoToken:String(t?.signalWireRepoToken??""),signalWireRepoTokenIsActive:t?.signalWireRepoTokenIsActive!==false,defaultCurrency:String(t?.defaultCurrency??"BRL")||"BRL",defaultCurrencyIsActive:t?.defaultCurrencyIsActive!==false,defaultLanguage:String(t?.defaultLanguage??"pt-BR")||"pt-BR",defaultLanguageIsActive:t?.defaultLanguageIsActive!==false,defaultTimezone:String(t?.defaultTimezone??""),defaultTimezoneIsActive:t?.defaultTimezoneIsActive!==false,voipPabxRecordingStorageMode:this.normalizeStorageMode(t?.voipPabxRecordingStorageMode),voipPabxRecordingStorageAccountUUID:String(t?.voipPabxRecordingStorageAccountUUID??""),voipPabxRecordingStorageIsActive:t?.voipPabxRecordingStorageIsActive!==false,voipPabxMediaStorageMode:this.normalizeStorageMode(t?.voipPabxMediaStorageMode),voipPabxMediaStorageAccountUUID:String(t?.voipPabxMediaStorageAccountUUID??""),voipPabxMediaStorageIsActive:t?.voipPabxMediaStorageIsActive!==false,voipPabxMediaDeliveryMode:this.normalizeDeliveryMode(t?.voipPabxMediaDeliveryMode),voipPabxMediaDeliveryModeIsActive:t?.voipPabxMediaDeliveryModeIsActive!==false,voipPabxRemoteCommandExecutor:this.normalizeRemoteCommandExecutor(t?.voipPabxRemoteCommandExecutor),voipPabxRemoteCommandExecutorIsActive:t?.voipPabxRemoteCommandExecutorIsActive!==false,voipPabxRealmSource:t?.voipPabxRealmSource==="own"||this.isMaster()?"own":"inherit",voipPabxDnsPolicyUUID:String(t?.voipPabxDnsPolicyUUID??""),voipPabxDnsPolicyBase:t?.voipPabxDnsPolicyBase??null,voipPabxDnsPolicyZoneName:t?.voipPabxDnsPolicyZoneName??null,voipPabxDnsPolicyEligible:t?.voipPabxDnsPolicyEligible!=null?!!t.voipPabxDnsPolicyEligible:null,voipPabxDnsPolicyError:t?.voipPabxDnsPolicyError??null,voipPabxEffectiveSource:t?.voipPabxEffectiveSource??(this.isMaster()?"platform":"tenant"),voipPabxEffectiveDnsMode:t?.voipPabxEffectiveDnsMode??"identity_only",voipPabxEffectiveBase:t?.voipPabxEffectiveBase??"pabx.publichost.cloud",voipPabxEffectiveZoneName:t?.voipPabxEffectiveZoneName??null,voipPabxEffectivePolicyUUID:t?.voipPabxEffectivePolicyUUID??null,voipPabxEffectivePolicyEligible:t?.voipPabxEffectivePolicyEligible!==false,voipPabxEffectivePolicyError:t?.voipPabxEffectivePolicyError??null,voipPabxInheritedDnsMode:t?.voipPabxInheritedDnsMode??"identity_only",voipPabxInheritedBase:t?.voipPabxInheritedBase??"pabx.publichost.cloud",voipPabxInheritedZoneName:t?.voipPabxInheritedZoneName??null,voipPabxInheritedPolicyUUID:t?.voipPabxInheritedPolicyUUID??null,voipPabxAutoDomainEnabled:t?.voipPabxAutoDomainEnabled!==false,voipPabxAutoDomainBase:String(t?.voipPabxAutoDomainBase??M.voipPabxAutoDomainBase).trim()||M.voipPabxAutoDomainBase,voipPabxAutoDomainLabelMode:this.normalizePabxAutoDomainLabelMode(t?.voipPabxAutoDomainLabelMode),voipPabxAutoDomainUuidLength:this.clampInteger(t?.voipPabxAutoDomainUuidLength??12,8,32),voipPabxAutoDomainSetDefault:t?.voipPabxAutoDomainSetDefault!==false,voipPabxAutoDomainDnsMode:this.normalizePabxAutoDomainDnsMode(t?.voipPabxAutoDomainDnsMode),voipPabxAutoDomainIsActive:t?.voipPabxAutoDomainIsActive!==false,billingSignupTrialEnabled:t?.billingSignupTrialEnabled===true,billingSignupTrialAmount:this.normalizeNumber(t?.billingSignupTrialAmount,0),billingSignupTrialCurrency:String(t?.billingSignupTrialCurrency??"BRL")||"BRL",billingSignupTrialExpiresDays:this.normalizeInteger(t?.billingSignupTrialExpiresDays,15),billingSignupTrialRequireEmailVerified:t?.billingSignupTrialRequireEmailVerified!==false,signupCaptchaEnabled:t?.signupCaptchaEnabled===true,signupCaptchaProvider:this.normalizeCaptchaProvider(t?.signupCaptchaProvider),signupCaptchaSiteKey:String(t?.signupCaptchaSiteKey??""),signupCaptchaSecret:String(t?.signupCaptchaSecret??""),signupMaxAccountsPerIpDay:this.normalizeInteger(t?.signupMaxAccountsPerIpDay,3),loginCaptchaEnabled:t?.loginCaptchaEnabled===true,authRememberMeEnabled:t?.authRememberMeEnabled!==false,authSessionHours:this.normalizeInteger(t?.authSessionHours,12),authRememberMeHours:this.normalizeInteger(t?.authRememberMeHours,720)}}normalizeForSave(t){return Q(j({},t),{googleMapsEmbedApiKey:t.googleMapsEmbedApiKey.trim(),mapboxToken:t.mapboxToken.trim(),signalWireRepoToken:this.isMaster()?t.signalWireRepoToken.trim():"",defaultCurrency:(t.defaultCurrency.trim()||"BRL").toUpperCase(),defaultLanguage:it$1(t.defaultLanguage)?t.defaultLanguage:"pt-BR",defaultTimezone:t.defaultTimezone.trim(),voipPabxRecordingStorageMode:t.voipPabxRecordingStorageMode,voipPabxRecordingStorageAccountUUID:t.voipPabxRecordingStorageMode==="storage"?t.voipPabxRecordingStorageAccountUUID:"",voipPabxMediaStorageMode:t.voipPabxMediaStorageMode,voipPabxMediaStorageAccountUUID:t.voipPabxMediaStorageMode==="storage"?t.voipPabxMediaStorageAccountUUID:"",voipPabxMediaDeliveryMode:t.voipPabxMediaDeliveryMode,voipPabxRemoteCommandExecutor:t.voipPabxRemoteCommandExecutor,voipPabxAutoDomainBase:t.voipPabxAutoDomainBase.trim().toLowerCase().replace(/^\.+|\.+$/g,"")||M.voipPabxAutoDomainBase,voipPabxAutoDomainLabelMode:this.normalizePabxAutoDomainLabelMode(t.voipPabxAutoDomainLabelMode),voipPabxAutoDomainUuidLength:this.clampInteger(t.voipPabxAutoDomainUuidLength,8,32),voipPabxAutoDomainDnsMode:this.normalizePabxAutoDomainDnsMode(t.voipPabxAutoDomainDnsMode),voipPabxRealmSource:t.voipPabxRealmSource,voipPabxDnsPolicyUUID:t.voipPabxAutoDomainDnsMode==="managed_dns"&&t.voipPabxRealmSource==="own"?t.voipPabxDnsPolicyUUID:"",billingSignupTrialAmount:Math.max(Number(t.billingSignupTrialAmount||0),0),billingSignupTrialCurrency:(t.billingSignupTrialCurrency.trim()||"BRL").toUpperCase(),billingSignupTrialExpiresDays:this.clampInteger(t.billingSignupTrialExpiresDays,1,365),signupCaptchaProvider:t.signupCaptchaProvider,signupCaptchaSiteKey:t.signupCaptchaSiteKey.trim(),signupCaptchaSecret:t.signupCaptchaSecret.trim(),signupMaxAccountsPerIpDay:this.clampInteger(t.signupMaxAccountsPerIpDay,1,100),authSessionHours:this.clampInteger(t.authSessionHours,1,168),authRememberMeHours:this.clampInteger(t.authRememberMeHours,1,2160)})}buildSignature(t){return JSON.stringify({googleMapsEmbedApiKey:t.googleMapsEmbedApiKey,googleMapsEmbedApiKeyIsActive:t.googleMapsEmbedApiKeyIsActive,mapboxToken:t.mapboxToken,mapboxTokenIsActive:t.mapboxTokenIsActive,signalWireRepoToken:t.signalWireRepoToken,signalWireRepoTokenIsActive:t.signalWireRepoTokenIsActive,defaultCurrency:t.defaultCurrency,defaultCurrencyIsActive:t.defaultCurrencyIsActive,defaultLanguage:t.defaultLanguage,defaultLanguageIsActive:t.defaultLanguageIsActive,defaultTimezone:t.defaultTimezone,defaultTimezoneIsActive:t.defaultTimezoneIsActive,voipPabxRecordingStorageMode:t.voipPabxRecordingStorageMode,voipPabxRecordingStorageAccountUUID:t.voipPabxRecordingStorageAccountUUID,voipPabxRecordingStorageIsActive:t.voipPabxRecordingStorageIsActive,voipPabxMediaStorageMode:t.voipPabxMediaStorageMode,voipPabxMediaStorageAccountUUID:t.voipPabxMediaStorageAccountUUID,voipPabxMediaStorageIsActive:t.voipPabxMediaStorageIsActive,voipPabxMediaDeliveryMode:t.voipPabxMediaDeliveryMode,voipPabxMediaDeliveryModeIsActive:t.voipPabxMediaDeliveryModeIsActive,voipPabxRemoteCommandExecutor:t.voipPabxRemoteCommandExecutor,voipPabxRemoteCommandExecutorIsActive:t.voipPabxRemoteCommandExecutorIsActive,voipPabxAutoDomainEnabled:t.voipPabxAutoDomainEnabled,voipPabxAutoDomainBase:t.voipPabxAutoDomainBase,voipPabxAutoDomainLabelMode:t.voipPabxAutoDomainLabelMode,voipPabxAutoDomainUuidLength:t.voipPabxAutoDomainUuidLength,voipPabxAutoDomainSetDefault:t.voipPabxAutoDomainSetDefault,voipPabxAutoDomainDnsMode:t.voipPabxAutoDomainDnsMode,voipPabxRealmSource:t.voipPabxRealmSource,voipPabxDnsPolicyUUID:t.voipPabxAutoDomainDnsMode==="managed_dns"&&t.voipPabxRealmSource==="own"?t.voipPabxDnsPolicyUUID:"",voipPabxAutoDomainIsActive:t.voipPabxAutoDomainIsActive,billingSignupTrialEnabled:t.billingSignupTrialEnabled,billingSignupTrialAmount:t.billingSignupTrialAmount,billingSignupTrialCurrency:t.billingSignupTrialCurrency,billingSignupTrialExpiresDays:t.billingSignupTrialExpiresDays,billingSignupTrialRequireEmailVerified:t.billingSignupTrialRequireEmailVerified,signupCaptchaEnabled:t.signupCaptchaEnabled,signupCaptchaProvider:t.signupCaptchaProvider,signupCaptchaSiteKey:t.signupCaptchaSiteKey,signupCaptchaSecret:t.signupCaptchaSecret,signupMaxAccountsPerIpDay:t.signupMaxAccountsPerIpDay,loginCaptchaEnabled:t.loginCaptchaEnabled,authRememberMeEnabled:t.authRememberMeEnabled,authSessionHours:t.authSessionHours,authRememberMeHours:t.authRememberMeHours})}buildSiadSignature(t){return JSON.stringify({environment:t.environment,origin:t.origin,suborigin:t.suborigin,referenciado:t.referenciado,isActive:t.isActive})}async loadSiad(){return this.readSiad(await this.api.get("settings/integrations/bradesco/siad"))}readSiad(t){let e=t?.data?.item??t?.item??t??{},i=String(e?.environment??"dsv").toLowerCase();return {environment:i==="hml"||i==="prd"?i:"dsv",origin:String(e?.origin??""),suborigin:String(e?.suborigin??""),referenciado:String(e?.referenciado??""),isActive:e?.isActive===true,credentialsConfigured:e?.credentialsConfigured===true,credentialsUpdatedAt:e?.credentialsUpdatedAt?String(e.credentialsUpdatedAt):null,credential:e?.credential&&typeof e.credential=="object"?{certificateFilename:String(e.credential.certificateFilename??""),certificateFingerprintSha256:String(e.credential.certificateFingerprintSha256??""),certificateNotAfter:String(e.credential.certificateNotAfter??"")}:null}}async loadParametersSnapshot(t,e){let[i,a,r]=await Promise.all([this.api.get(t),this.fetchStorageAccounts(e),this.api.get(`${t}/pabx-dns-policies`)]);return this.dnsOffset.set(0),{item:this.readItem(i),storageAccounts:a,dnsPolicies:r?.data?.items??[]}}async fetchStorageAccounts(t){let e=t?"system/hosting/storage/accounts":"hosting/storage/accounts";try{return (await this.api.get(e))?.data?.items??[]}catch{return []}}normalizeStorageMode(t){let e=String(t??"").trim().toLowerCase();return e==="filesystem"||e==="storage"?e:""}normalizeDeliveryMode(t){let e=String(t??"").trim().toLowerCase();return e==="online"||e==="offline"?e:""}normalizeRemoteCommandExecutor(t){let e=String(t??"").trim().toLowerCase();return e==="agent"||e==="esl_ami"?e:""}normalizePabxAutoDomainLabelMode(t){return "uuid_short"}normalizePabxAutoDomainDnsMode(t){return t==="managed_dns"?"managed_dns":"identity_only"}normalizeCaptchaProvider(t){let e=String(t??"").trim().toLowerCase();return e==="turnstile"||e==="hcaptcha"?e:""}normalizeNumber(t,e){let i=Number(t);return Number.isFinite(i)?i:e}normalizeInteger(t,e){let i=Math.trunc(Number(t));return Number.isFinite(i)?i:e}clampInteger(t,e,i){let a=this.normalizeInteger(t,e);return Math.min(Math.max(a,e),i)}friendlyError(t,e){let i=t?.error?.error;if(typeof i=="string"&&i.trim())return i;let a=t?.message;return typeof a=="string"&&a.trim()?a:e}static \u0275fac=function(e){return new(e||m)};static \u0275cmp=Ql({type:m,selectors:[["app-settings-parameters"]],hostAttrs:[1,"app-fade-in-host"],decls:196,vars:204,consts:[["siadCertificateInput",""],["siadPrivateKeyInput",""],[3,"refresh","cancel","save","title","description","loading","saving","dirty","error","success"],[1,"form-tabs"],[3,"label"],[1,"tab-content","form-grid"],["appearance","outline",1,"span-2"],["matInput","","maxlength","3",3,"input","placeholder","value"],[3,"selectionChange","placeholder","value"],[3,"value"],["matInput","",3,"input","placeholder","value"],[1,"toggle-grid","span-4"],[3,"change","checked"],[1,"nested-tabs","integration-tabs"],["appearance","outline",1,"span-4"],["matInput","",3,"input","type","placeholder","value"],["mat-icon-button","","matSuffix","","type","button",3,"click"],[1,"nested-tabs"],[1,"tab-content","empty-tab"],[1,"nested-tabs","pabx-parameter-tabs"],["appearance","outline"],["value",""],["value","filesystem"],["value","storage"],[3,"selectionChange","disabled","value"],["value","online"],["value","offline"],["value","agent"],["value","esl_ami"],[1,"nested-tabs","siad-tabs"],["appearance","outline",1,"span-1"],[3,"selectionChange","value"],["value","dsv"],["value","hml"],["value","prd"],["matInput","","maxlength","20",3,"input","value"],["matInput","","maxlength","10",3,"input","value"],["matInput","",3,"input","value","placeholder"],["matInput","",3,"input","type","value"],["type","file","hidden","","accept",".pem,.crt,.cer,application/x-pem-file",3,"change"],["type","file","hidden","","accept",".pem,.key,application/x-pem-file",3,"change"],["matInput","","readonly","",3,"value","placeholder"],[1,"integration-secret-state","span-4"],["matInput","","type","number","min","0","step","0.01",3,"input","value"],["matInput","","type","number","min","1","max","365",3,"input","value"],["matInput","","type","number","min","1","max","100",3,"input","value"],["matInput","","type","number","min","1","max","168",3,"input","value"],["matInput","","type","number","min","1","max","2160",3,"input","value"],["value","turnstile"],["value","hcaptcha"],["appearance","outline",1,"span-3"],["value","uuid_short"],["matInput","","type","number","min","8","max","32",3,"input","value"],["data-quick-create-exempt","DNS policies require explicit authorization in the owning DNS domain.","fieldClass","span-4",3,"searchChange","pageChange","openedChange","valueChange","label","options","remoteSearch","loading","loadError","hasPrevious","hasNext","value","help"],["role","alert",1,"span-4","settings-page-feedback"],["matInput","","readonly","",3,"value"],[1,"span-4","empty-tab"]],template:function(e,i){e&1&&(Ws(0,"mns-settings-page",2),dy("refresh",function(){return i.refreshItems()})("cancel",function(){return i.cancelChanges()})("save",function(){return i.saveAll()}),Ws(1,"mat-tab-group",3)(2,"mat-tab",4),vT(3,"transloco"),Ws(4,"form",5)(5,"mat-form-field",6)(6,"mat-label"),rT(7),vT(8,"transloco"),id(),Ws(9,"input",7),vT(10,"transloco"),dy("input",function(r){return i.updateItem({defaultCurrency:r.target.value})}),id()(),Ws(11,"mat-form-field",6)(12,"mat-label"),rT(13),vT(14,"transloco"),id(),Ws(15,"mat-select",8),vT(16,"transloco"),dy("selectionChange",function(r){return i.updateItem({defaultLanguage:r.value})}),gC(17,lt,3,4,"mat-option",9,rt),id()(),Ws(19,"mat-form-field",6)(20,"mat-label"),rT(21),vT(22,"transloco"),id(),Ws(23,"input",10),dy("input",function(r){return i.updateItem({defaultTimezone:r.target.value})}),id()(),Ws(24,"div",11)(25,"mat-slide-toggle",12),dy("change",function(r){return i.updateItem({defaultCurrencyIsActive:r.checked})}),rT(26),vT(27,"transloco"),id(),Ws(28,"mat-slide-toggle",12),dy("change",function(r){return i.updateItem({defaultLanguageIsActive:r.checked})}),rT(29),vT(30,"transloco"),id(),Ws(31,"mat-slide-toggle",12),dy("change",function(r){return i.updateItem({defaultTimezoneIsActive:r.checked})}),rT(32),vT(33,"transloco"),id()()()(),Ws(34,"mat-tab",4),vT(35,"transloco"),Ws(36,"mat-tab-group",13)(37,"mat-tab",4),vT(38,"transloco"),Ws(39,"form",5)(40,"mat-form-field",14)(41,"mat-label"),rT(42),vT(43,"transloco"),id(),Ws(44,"input",15),vT(45,"transloco"),dy("input",function(r){return i.updateItem({googleMapsEmbedApiKey:r.target.value})}),id(),Ws(46,"button",16),vT(47,"transloco"),dy("click",function(){return i.showGoogleMapsEmbedApiKey.set(!i.showGoogleMapsEmbedApiKey())}),Ws(48,"mat-icon"),rT(49),id()()(),Ws(50,"div",11)(51,"mat-slide-toggle",12),dy("change",function(r){return i.updateItem({googleMapsEmbedApiKeyIsActive:r.checked})}),rT(52),vT(53,"transloco"),id()()()(),Ws(54,"mat-tab",4),vT(55,"transloco"),Ws(56,"form",5)(57,"mat-form-field",14)(58,"mat-label"),rT(59),vT(60,"transloco"),id(),Ws(61,"input",15),vT(62,"transloco"),dy("input",function(r){return i.updateItem({mapboxToken:r.target.value})}),id(),Ws(63,"button",16),vT(64,"transloco"),dy("click",function(){return i.showMapboxToken.set(!i.showMapboxToken())}),Ws(65,"mat-icon"),rT(66),id()()(),Ws(67,"div",11)(68,"mat-slide-toggle",12),dy("change",function(r){return i.updateItem({mapboxTokenIsActive:r.checked})}),rT(69),vT(70,"transloco"),id()()()(),dC(71,ct,81,72,"mat-tab",4)(72,pt,17,19,"mat-tab",4),id()(),dC(73,mt,80,82,"mat-tab",4),Ws(74,"mat-tab",4),vT(75,"transloco"),Ws(76,"mat-tab-group",17)(77,"mat-tab",4),vT(78,"transloco"),Ws(79,"div",18),rT(80),vT(81,"transloco"),id()(),Ws(82,"mat-tab",4),vT(83,"transloco"),Ws(84,"div",18),rT(85),vT(86,"transloco"),id()(),Ws(87,"mat-tab",4),vT(88,"transloco"),Ws(89,"mat-tab-group",19)(90,"mat-tab",4),vT(91,"transloco"),Ws(92,"form",5)(93,"mat-form-field",20)(94,"mat-label"),rT(95),vT(96,"transloco"),id(),Ws(97,"mat-select",8),dy("selectionChange",function(r){return i.updateItem({voipPabxRecordingStorageMode:r.value})}),Ws(98,"mat-option",21),rT(99),vT(100,"transloco"),id(),Ws(101,"mat-option",22),rT(102),vT(103,"transloco"),id(),Ws(104,"mat-option",23),rT(105),vT(106,"transloco"),id()()(),Ws(107,"mat-form-field",6)(108,"mat-label"),rT(109),vT(110,"transloco"),id(),Ws(111,"mat-select",24),dy("selectionChange",function(r){return i.updateItem({voipPabxRecordingStorageAccountUUID:r.value})}),Ws(112,"mat-option",21),rT(113),vT(114,"transloco"),id(),gC(115,ut,2,3,"mat-option",9,Ze),id()(),Ws(117,"mat-form-field",20)(118,"mat-label"),rT(119),vT(120,"transloco"),id(),Ws(121,"mat-select",8),dy("selectionChange",function(r){return i.updateItem({voipPabxMediaStorageMode:r.value})}),Ws(122,"mat-option",21),rT(123),vT(124,"transloco"),id(),Ws(125,"mat-option",22),rT(126),vT(127,"transloco"),id(),Ws(128,"mat-option",23),rT(129),vT(130,"transloco"),id()()(),Ws(131,"mat-form-field",6)(132,"mat-label"),rT(133),vT(134,"transloco"),id(),Ws(135,"mat-select",24),dy("selectionChange",function(r){return i.updateItem({voipPabxMediaStorageAccountUUID:r.value})}),Ws(136,"mat-option",21),rT(137),vT(138,"transloco"),id(),gC(139,gt,2,3,"mat-option",9,Ze),id()(),Ws(141,"div",11)(142,"mat-slide-toggle",12),dy("change",function(r){return i.updateItem({voipPabxRecordingStorageIsActive:r.checked})}),rT(143),vT(144,"transloco"),id(),Ws(145,"mat-slide-toggle",12),dy("change",function(r){return i.updateItem({voipPabxMediaStorageIsActive:r.checked})}),rT(146),vT(147,"transloco"),id()()()(),Ws(148,"mat-tab",4),vT(149,"transloco"),Ws(150,"form",5)(151,"mat-form-field",20)(152,"mat-label"),rT(153),vT(154,"transloco"),id(),Ws(155,"mat-select",8),dy("selectionChange",function(r){return i.updateItem({voipPabxMediaDeliveryMode:r.value})}),Ws(156,"mat-option",21),rT(157),vT(158,"transloco"),id(),Ws(159,"mat-option",25),rT(160),vT(161,"transloco"),id(),Ws(162,"mat-option",26),rT(163),vT(164,"transloco"),id()()(),Ws(165,"div",11)(166,"mat-slide-toggle",12),dy("change",function(r){return i.updateItem({voipPabxMediaDeliveryModeIsActive:r.checked})}),rT(167),vT(168,"transloco"),id()()()(),Ws(169,"mat-tab",4),vT(170,"transloco"),Ws(171,"form",5)(172,"mat-form-field",20)(173,"mat-label"),rT(174),vT(175,"transloco"),id(),Ws(176,"mat-select",8),dy("selectionChange",function(r){return i.updateItem({voipPabxRemoteCommandExecutor:r.value})}),Ws(177,"mat-option",21),rT(178),vT(179,"transloco"),id(),Ws(180,"mat-option",27),rT(181),vT(182,"transloco"),id(),Ws(183,"mat-option",28),rT(184),vT(185,"transloco"),id()()(),Ws(186,"div",11)(187,"mat-slide-toggle",12),dy("change",function(r){return i.updateItem({voipPabxRemoteCommandExecutorIsActive:r.checked})}),rT(188),vT(189,"transloco"),id()()()(),Ws(190,"mat-tab",4),vT(191,"transloco"),Ws(192,"form",5),dC(193,ht,7,4,"mat-form-field",6),dC(194,St,32,28)(195,xt,15,14),id()()()()()()()()),e&2&&(oy("title",i.pageTitle())("description",i.pageSubtitle())("loading",i.loading())("saving",i.saving())("dirty",i.hasChanges())("error",i.feedback())("success",i.success()),db(2),oy("label",ET(3,96,"Record")),db(5),My(ET(8,98,"Default Currency")),db(2),oy("placeholder",ET(10,100,"BRL"))("value",i.item().defaultCurrency),db(4),My(ET(14,102,"Default Language")),db(2),oy("placeholder",ET(16,104,"pt-BR"))("value",i.item().defaultLanguage),db(2),mC(i.languageOptions),db(4),My(ET(22,106,"Default Timezone")),db(2),oy("placeholder",i.defaultTimezonePlaceholder())("value",i.item().defaultTimezone),db(2),oy("checked",i.item().defaultCurrencyIsActive),db(),dd(" ",ET(27,108,"Default Currency Active")," "),db(2),oy("checked",i.item().defaultLanguageIsActive),db(),dd(" ",ET(30,110,"Default Language Active")," "),db(2),oy("checked",i.item().defaultTimezoneIsActive),db(),dd(" ",ET(33,112,"Default Timezone Active")," "),db(2),oy("label",ET(35,114,"Integrations")),db(3),oy("label",ET(38,116,"Google")),db(5),My(ET(43,118,"Google Maps Embed API Key")),db(2),oy("type",i.showGoogleMapsEmbedApiKey()?"text":"password")("placeholder",ET(45,120,"Google Maps Street View embed API key"))("value",i.item().googleMapsEmbedApiKey),db(2),rd("aria-label",ET(47,122,i.showGoogleMapsEmbedApiKey()?"Hide Google Maps key":"Show Google Maps key")),db(3),My(i.showGoogleMapsEmbedApiKey()?"visibility_off":"visibility"),db(2),oy("checked",i.item().googleMapsEmbedApiKeyIsActive),db(),dd(" ",ET(53,124,"Google Maps Key Active")," "),db(2),oy("label",ET(55,126,"Mapbox")),db(5),My(ET(60,128,"Mapbox Token")),db(2),oy("type",i.showMapboxToken()?"text":"password")("placeholder",ET(62,130,"Mapbox public token"))("value",i.item().mapboxToken),db(2),rd("aria-label",ET(64,132,i.showMapboxToken()?"Hide Mapbox token":"Show Mapbox token")),db(3),My(i.showMapboxToken()?"visibility_off":"visibility"),db(2),oy("checked",i.item().mapboxTokenIsActive),db(),dd(" ",ET(70,134,"Mapbox Token Active")," "),db(2),fC(i.isMaster()?72:71),db(2),fC(i.isMaster()?73:-1),db(),oy("label",ET(75,136,"VoIP")),db(3),oy("label",ET(78,138,"SBC")),db(3),My(ET(81,140,"No SBC defaults configured yet.")),db(2),oy("label",ET(83,142,"Softswitch")),db(3),My(ET(86,144,"No softswitch defaults configured yet.")),db(2),oy("label",ET(88,146,"PABX")),db(3),oy("label",ET(91,148,"Storage")),db(5),My(ET(96,150,"Storage - Recording")),db(2),oy("placeholder",i.voipPabxRecordingStoragePlaceholder())("value",i.item().voipPabxRecordingStorageMode),db(2),My(ET(100,152,"Default")),db(3),My(ET(103,154,"Filesystem")),db(3),My(ET(106,156,"Storage")),db(4),My(ET(110,158,"Recording storage account")),db(2),oy("disabled",i.item().voipPabxRecordingStorageMode!=="storage")("value",i.item().voipPabxRecordingStorageAccountUUID),db(2),My(ET(114,160,"Default storage account")),db(2),mC(i.storageAccounts()),db(4),My(ET(120,162,"Storage - Media File")),db(2),oy("placeholder",i.voipPabxMediaStoragePlaceholder())("value",i.item().voipPabxMediaStorageMode),db(2),My(ET(124,164,"Default")),db(3),My(ET(127,166,"Filesystem")),db(3),My(ET(130,168,"Storage")),db(4),My(ET(134,170,"Media file storage account")),db(2),oy("disabled",i.item().voipPabxMediaStorageMode!=="storage")("value",i.item().voipPabxMediaStorageAccountUUID),db(2),My(ET(138,172,"Default storage account")),db(2),mC(i.storageAccounts()),db(3),oy("checked",i.item().voipPabxRecordingStorageIsActive),db(),dd(" ",ET(144,174,"Recording Storage Active")," "),db(2),oy("checked",i.item().voipPabxMediaStorageIsActive),db(),dd(" ",ET(147,176,"Media Storage Active")," "),db(2),oy("label",ET(149,178,"Media")),db(5),My(ET(154,180,"Media File - Delivery Mode")),db(2),oy("placeholder",i.voipPabxMediaDeliveryPlaceholder())("value",i.item().voipPabxMediaDeliveryMode),db(2),My(ET(158,182,"Default")),db(3),My(ET(161,184,"Online")),db(3),My(ET(164,186,"Offline")),db(3),oy("checked",i.item().voipPabxMediaDeliveryModeIsActive),db(),dd(" ",ET(168,188,"Media Delivery Active")," "),db(2),oy("label",ET(170,190,"Execution")),db(5),My(ET(175,192,"Remote Command Executor")),db(2),oy("placeholder",i.voipPabxRemoteCommandExecutorPlaceholder())("value",i.item().voipPabxRemoteCommandExecutor),db(2),My(ET(179,194,"Default")),db(3),My(ET(182,196,"Agent")),db(3),My(ET(185,198,"ESL/AMI")),db(3),oy("checked",i.item().voipPabxRemoteCommandExecutorIsActive),db(),dd(" ",ET(189,200,"Remote Command Active")," "),db(2),oy("label",ET(191,202,"SIP Realm")),db(3),fC(i.isMaster()?-1:193),db(),fC(i.isMaster()||i.item().voipPabxRealmSource==="own"?194:195));},dependencies:[T,de,ii,je$1,V,yt$1,pi,gi,Tt,dt$2,ae,se,qe,X,cn,ke,dn,Lt,Rt,W,Kt],styles:[`.integration-secret-state,.parameter-hint,.empty-tab{color:var(--mat-sys-color-on-surface-variant);font-size:.875rem;line-height:1.45}
`],encapsulation:2})};export{je as SettingsParametersPage};