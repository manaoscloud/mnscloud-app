import{A as Fw,Er as lD,Et as QC,G as Id,Gt as Vg,It as T$1,Jt as Vw,Nn as cC,V as Hg,Wn as ee,Z as Jl,_n as Zg,an as Xg,ct as LC,gi as x,hn as Z1,hr as is,in as Xe,kt as Ql,li as uC,lr as iC,ni as so,nt as K1,p as Bg,pn as Yl,pr as im,qr as qe,qt as Vr,r as $b,vn as Zl,wn as aC,xi as zg,z as Hb,zn as dC}from"./chunk-CuHkM8TI.js";import{M as mo,r as Cc,u as Ju}from"./chunk-ER9u7iI5.js";import{c as Se,x as je,y as ie$1}from"./chunk-CUSo99SM.js";import{n as Ie,r as Ne,t as De}from"./chunk-D_aO-_Sb.js";import{t as m}from"./chunk-cdGU_-0s.js";import{c as Oo}from"./chunk-C-C4xboh.js";var at=new x(`MAT_OPTION_PARENT_COMPONENT`);var rt=new x(`MatOptgroup`);var Nt=(()=>{class e{label;disabled=!1;_labelId=T$1(ie$1).getId(`mat-optgroup-label-`);_inert;constructor(){let t=T$1(at,{optional:!0});this._inert=t?.inertGroups??!1}static ɵfac=function(i){return new(i||e)};static ɵcmp=(function(){let t=[`*`,[[`mat-option`],[`ng-container`]]];return Fw({type:e,selectors:[[`mat-optgroup`]],hostAttrs:[1,`mat-mdc-optgroup`],hostVars:3,hostBindings:function(l,o){l&2&&Vg(`role`,o._inert?null:`group`)(`aria-disabled`,o._inert?null:o.disabled.toString())(`aria-labelledby`,o._inert?null:o._labelId)},inputs:{label:`label`,disabled:[2,`disabled`,`disabled`,K1]},exportAs:[`matOptgroup`],features:[QC([{provide:rt,useExisting:e}])],ngContentSelectors:[`*`,`mat-option, ng-container`],decls:5,vars:4,consts:[[`role`,`presentation`,1,`mat-mdc-optgroup-label`,3,`id`],[1,`mdc-list-item__primary-text`]],template:function(l,o){l&1&&(aC(t),Zl(0,`span`,0)(1,`span`,1),LC(2),cC(3),Yl()(),cC(4,1)),l&2&&(im(`mdc-list-item--disabled`,o.disabled),zg(`id`,o._labelId),lD(2),Jl(``,o.label,` `))},styles:[`.mat-mdc-optgroup {
  color: var(--%NS%mat-optgroup-label-text-color, var(--%NS%mat-sys-on-surface-variant));
  font-family: var(--%NS%mat-optgroup-label-text-font, var(--%NS%mat-sys-title-small-font));
  line-height: var(--%NS%mat-optgroup-label-text-line-height, var(--%NS%mat-sys-title-small-line-height));
  font-size: var(--%NS%mat-optgroup-label-text-size, var(--%NS%mat-sys-title-small-size));
  letter-spacing: var(--%NS%mat-optgroup-label-text-tracking, var(--%NS%mat-sys-title-small-tracking));
  font-weight: var(--%NS%mat-optgroup-label-text-weight, var(--%NS%mat-sys-title-small-weight));
}

.mat-mdc-optgroup-label {
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  min-height: 48px;
  padding: 0 16px;
  outline: none;
}
.mat-mdc-optgroup-label.mdc-list-item--disabled {
  opacity: 0.38;
}
.mat-mdc-optgroup-label .mdc-list-item__primary-text {
  font-size: inherit;
  font-weight: inherit;
  letter-spacing: inherit;
  line-height: inherit;
  font-family: inherit;
  text-decoration: inherit;
  text-transform: inherit;
  white-space: normal;
  color: inherit;
}
`],encapsulation:2})})()}return e})();var T=class{source;isUserInput;constructor(c,t=!1){this.source=c,this.isUserInput=t}};var lt=(()=>{class e{_element=T$1(so);_changeDetectorRef=T$1(Z1);_parent=T$1(at,{optional:!0});group=T$1(rt,{optional:!0});_signalDisableRipple=!1;_selected=!1;_active=!1;_mostRecentViewValue=``;get multiple(){return this._parent&&this._parent.multiple}get selected(){return this._selected}value;id=T$1(ie$1).getId(`mat-option-`);get disabled(){return this.group&&this.group.disabled||this._disabled()}set disabled(t){this._disabled.set(t)}_disabled=qe(!1);get disableRipple(){return this._signalDisableRipple?this._parent.disableRipple():!!this._parent?.disableRipple}get hideSingleSelectionIndicator(){return!!(this._parent&&this._parent.hideSingleSelectionIndicator)}onSelectionChange=new Xe;_text;_stateChanges=new ee;constructor(){let t=T$1(mo);t.load(Ie),t.load(Ju),this._signalDisableRipple=!!this._parent&&Vr(this._parent.disableRipple)}get active(){return this._active}get viewValue(){return(this._text?.nativeElement.textContent||``).trim()}select(t=!0){this._selected||(this._selected=!0,this._changeDetectorRef.markForCheck(),t&&this._emitSelectionChangeEvent())}deselect(t=!0){this._selected&&(this._selected=!1,this._changeDetectorRef.markForCheck(),t&&this._emitSelectionChangeEvent())}focus(t,i){let m=this._getHostElement();typeof m.focus==`function`&&m.focus(i)}setActiveStyles(){this._active||(this._active=!0,this._changeDetectorRef.markForCheck())}setInactiveStyles(){this._active&&(this._active=!1,this._changeDetectorRef.markForCheck())}getLabel(){return this.viewValue}_handleKeydown(t){(t.keyCode===13||t.keyCode===32)&&!je(t)&&(this._selectViaInteraction(),t.preventDefault())}_selectViaInteraction(){this.disabled||(this._selected=this.multiple?!this._selected:!0,this._changeDetectorRef.markForCheck(),this._emitSelectionChangeEvent(!0))}_getTabIndex(){return this.disabled?`-1`:`0`}_getHostElement(){return this._element.nativeElement}ngAfterViewChecked(){if(this._selected){let t=this.viewValue;t!==this._mostRecentViewValue&&(this._mostRecentViewValue&&this._stateChanges.next(),this._mostRecentViewValue=t)}}ngOnDestroy(){this._stateChanges.complete()}_emitSelectionChangeEvent(t=!1){this.onSelectionChange.emit(new T(this,t))}static ɵfac=function(i){return new(i||e)};static ɵcmp=(function(){let t=[`text`],i=[[[`mat-icon`]],`*`],m$1=[`mat-icon`,`*`];function l(a,r){if(a&1&&Bg(0,`mat-pseudo-checkbox`,1),a&2){let n=iC();Hg(`disabled`,n.disabled)(`state`,n.selected?`checked`:`unchecked`)}}function o(a,r){if(a&1&&Bg(0,`mat-pseudo-checkbox`,3),a&2){let n=iC();Hg(`disabled`,n.disabled)}}function mt(a,r){if(a&1&&(is(0,`span`,4),LC(1),Ql()),a&2){let n=iC();lD(),Jl(`(`,n.group.label,`)`)}}return Fw({type:e,selectors:[[`mat-option`]],viewQuery:function(r,n){if(r&1&&Xg(t,7),r&2){let f;uC(f=dC())&&(n._text=f.first)}},hostAttrs:[`role`,`option`,1,`mat-mdc-option`,`mdc-list-item`],hostVars:11,hostBindings:function(r,n){r&1&&Zg(`click`,function(){return n._selectViaInteraction()})(`keydown`,function(ct){return n._handleKeydown(ct)}),r&2&&(zg(`id`,n.id),Vg(`aria-selected`,n.selected)(`aria-disabled`,n.disabled.toString()),im(`mdc-list-item--selected`,n.selected)(`mat-mdc-option-multiple`,n.multiple)(`mat-mdc-option-active`,n.active)(`mdc-list-item--disabled`,n.disabled))},inputs:{value:`value`,id:`id`,disabled:[2,`disabled`,`disabled`,K1]},outputs:{onSelectionChange:`onSelectionChange`},exportAs:[`matOption`],ngContentSelectors:m$1,decls:8,vars:5,consts:[[`text`,``],[`aria-hidden`,`true`,1,`mat-mdc-option-pseudo-checkbox`,3,`disabled`,`state`],[1,`mdc-list-item__primary-text`],[`state`,`checked`,`aria-hidden`,`true`,`appearance`,`minimal`,1,`mat-mdc-option-pseudo-checkbox`,3,`disabled`],[1,`cdk-visually-hidden`],[`aria-hidden`,`true`,`mat-ripple`,``,1,`mat-mdc-option-ripple`,`mat-focus-indicator`,3,`matRippleTrigger`,`matRippleDisabled`]],template:function(r,n){r&1&&(aC(i),Hb(0,l,1,2,`mat-pseudo-checkbox`,1),cC(1),is(2,`span`,2,0),cC(4,1),Ql(),Hb(5,o,1,1,`mat-pseudo-checkbox`,3),Hb(6,mt,2,1,`span`,4),Bg(7,`div`,5)),r&2&&($b(n.multiple?0:-1),lD(5),$b(!n.multiple&&n.selected&&!n.hideSingleSelectionIndicator?5:-1),lD(),$b(n.group&&n.group._inert?6:-1),lD(),Hg(`matRippleTrigger`,n._getHostElement())(`matRippleDisabled`,n.disabled||n.disableRipple))},dependencies:[m,De],styles:[`.mat-mdc-option {
  -webkit-user-select: none;
  user-select: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  min-height: 48px;
  padding: 0 16px;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  color: var(--%NS%mat-option-label-text-color, var(--%NS%mat-sys-on-surface));
  font-family: var(--%NS%mat-option-label-text-font, var(--%NS%mat-sys-label-large-font));
  line-height: var(--%NS%mat-option-label-text-line-height, var(--%NS%mat-sys-label-large-line-height));
  font-size: var(--%NS%mat-option-label-text-size, var(--%NS%mat-sys-body-large-size));
  letter-spacing: var(--%NS%mat-option-label-text-tracking, var(--%NS%mat-sys-label-large-tracking));
  font-weight: var(--%NS%mat-option-label-text-weight, var(--%NS%mat-sys-body-large-weight));
}
.mat-mdc-option:hover:not(.mdc-list-item--disabled) {
  background-color: var(--%NS%mat-option-hover-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-option:focus.mdc-list-item, .mat-mdc-option.mat-mdc-option-active.mdc-list-item {
  background-color: var(--%NS%mat-option-focus-state-layer-color, color-mix(in srgb, var(--%NS%mat-sys-on-surface) calc(var(--%NS%mat-sys-focus-state-layer-opacity) * 100%), transparent));
  outline: 0;
}
.mat-mdc-option.mdc-list-item--%NS%selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) {
  background-color: var(--%NS%mat-option-selected-state-layer-color, var(--%NS%mat-sys-secondary-container));
}
.mat-mdc-option.mdc-list-item--%NS%selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) .mdc-list-item__primary-text {
  color: var(--%NS%mat-option-selected-state-label-text-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-mdc-option .mat-pseudo-checkbox {
  --%NS%mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--%NS%mat-option-selected-state-label-text-color, var(--%NS%mat-sys-on-secondary-container));
}
.mat-mdc-option.mdc-list-item {
  align-items: center;
  background: transparent;
}
.mat-mdc-option.mdc-list-item--disabled {
  cursor: default;
  pointer-events: none;
}
.mat-mdc-option.mdc-list-item--disabled .mat-mdc-option-pseudo-checkbox, .mat-mdc-option.mdc-list-item--disabled .mdc-list-item__primary-text, .mat-mdc-option.mdc-list-item--disabled > mat-icon {
  opacity: 0.38;
}
.mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 32px;
}
[dir=rtl] .mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 16px;
  padding-right: 32px;
}
.mat-mdc-option .mat-icon,
.mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-icon,
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 0;
  margin-left: 16px;
}
.mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-left: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-right: 16px;
  margin-left: 0;
}
.mat-mdc-option .mat-mdc-option-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
.mat-mdc-option .mdc-list-item__primary-text {
  white-space: normal;
  font-size: inherit;
  font-weight: inherit;
  letter-spacing: inherit;
  line-height: inherit;
  font-family: inherit;
  text-decoration: inherit;
  text-transform: inherit;
  margin-right: auto;
}
[dir=rtl] .mat-mdc-option .mdc-list-item__primary-text {
  margin-right: 0;
  margin-left: auto;
}
@media (forced-colors: active) {
  .mat-mdc-option.mdc-list-item--%NS%selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    content: "";
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 10px;
    height: 0;
    border-bottom: solid 10px;
    border-radius: 10px;
  }
  [dir=rtl] .mat-mdc-option.mdc-list-item--%NS%selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    right: auto;
    left: 16px;
  }
}

.mat-mdc-option-multiple {
  --%NS%mat-list-list-item-selected-container-color: var(--%NS%mat-list-list-item-container-color, transparent);
}

.mat-mdc-option-active .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2})})()}return e})();function Ct(e,c,t){if(t.length){let i=c.toArray(),m=t.toArray(),l=0;for(let o=0;o<e+1;o++)i[o].group&&i[o].group===m[l]&&l++;return l}return 0}function Ot(e,c,t,i){return e<t?e:e+c>t+i?Math.max(0,e-i+c):t}var Xt=(()=>{class e{static ɵfac=function(i){return new(i||e)};static ɵmod=Vw({type:e});static ɵinj=Id({imports:[Se,Oo,Cc]})}return e})();var st=(()=>{class e{static ɵfac=function(i){return new(i||e)};static ɵmod=Vw({type:e});static ɵinj=Id({imports:[Cc]})}return e})();var ie=(()=>{class e{static ɵfac=function(i){return new(i||e)};static ɵmod=Vw({type:e});static ɵinj=Id({imports:[Ne,st,lt,Cc]})}return e})();export{Xt as a,lt as c,T as i,rt as l,Nt as n,at as o,Ot as r,ie as s,Ct as t};