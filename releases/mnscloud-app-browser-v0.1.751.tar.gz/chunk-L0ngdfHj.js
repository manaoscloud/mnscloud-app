import {U as U$1}from'./chunk-Bv3tHgDr.js';import {av as Lt,aw as ht,ay as Xv,db as $r,bz as Ee,aB as qe,b9 as ye,aF as E,aC as kr,bp as dl,aD as Ad,g,az as Yy,aK as mt,aJ as nt,dc as us,aN as it,c as Ve,aP as dM,aQ as js,bF as kD,z as zo,aV as sd,bm as td,aW as ad,bo as nd,w as z_,a1 as la,I as Wo,$ as $w,G as G_,t as ny,bq as Up,bn as Km}from'./main-HDH3547G.js';var V=["*",[["","matSortHeaderIcon",""]]],q=["*","[matSortHeaderIcon]"];function K(e,c){e&1&&(Up(),td(0,"svg",3),Km(1,"path",4),nd());}function U(e,c){e&1&&(td(0,"div",2),ad(1,1,null,K,2,0),nd());}var L=new E("MAT_SORT_DEFAULT_OPTIONS"),W=(()=>{class e{_defaultOptions;_initializedStream=new $r(1);sortables=new Map;_stateChanges=new Ee;active;start="asc";get direction(){return this._direction}set direction(t){this._direction=t;}_direction="";disableClear;disabled=false;sortChange=new qe;initialized=this._initializedStream;constructor(t){this._defaultOptions=t;}register(t){this.sortables.set(t.id,t);}deregister(t){this.sortables.delete(t.id);}sort(t){this.active!=t.id?(this.active=t.id,this.direction=t.start?t.start:this.start):this.direction=this.getNextSortDirection(t),this.sortChange.emit({active:this.active,direction:this.direction});}getNextSortDirection(t){if(!t)return "";let i=t?.disableClear??this.disableClear??!!this._defaultOptions?.disableClear,r=Z(t.start||this.start,i),n=r.indexOf(this.direction)+1;return n>=r.length&&(n=0),r[n]}ngOnInit(){this._initializedStream.next();}ngOnChanges(){this._stateChanges.next();}ngOnDestroy(){this._stateChanges.complete(),this._initializedStream.complete();}static \u0275fac=function(i){return new(i||e)(ye(L,8))};static \u0275dir=kr({type:e,selectors:[["","matSort",""]],hostAttrs:[1,"mat-sort"],inputs:{active:[0,"matSortActive","active"],start:[0,"matSortStart","start"],direction:[0,"matSortDirection","direction"],disableClear:[2,"matSortDisableClear","disableClear",Ad],disabled:[2,"matSortDisabled","disabled",Ad]},outputs:{sortChange:"matSortChange"},exportAs:["matSort"],features:[dl]})}return e})();function Z(e,c){let t=["asc","desc"];return e=="desc"&&t.reverse(),c||t.push(""),t}var pt=(()=>{class e{_sort=g(W,{optional:true});_columnDef=g(U$1,{optional:true});_changeDetectorRef=g(Yy);_focusMonitor=g(mt);_elementRef=g(nt);_ariaDescriber=g(us,{optional:true});_renderChanges;_animationsDisabled=it();_recentlyCleared=Ve(null);_sortButton;id;arrowPosition="after";start;disabled=false;get sortActionDescription(){return this._sortActionDescription}set sortActionDescription(t){this._updateSortActionDescription(t);}_sortActionDescription="Sort";disableClear;constructor(){g(dM).load(js);let t=g(L,{optional:true});this._sort,t?.arrowPosition&&(this.arrowPosition=t?.arrowPosition);}ngOnInit(){!this.id&&this._columnDef&&(this.id=this._columnDef.name),this._sort.register(this),this._renderChanges=kD(this._sort._stateChanges,this._sort.sortChange).subscribe(()=>this._changeDetectorRef.markForCheck()),this._sortButton=this._elementRef.nativeElement.querySelector(".mat-sort-header-container"),this._updateSortActionDescription(this._sortActionDescription);}ngAfterViewInit(){this._focusMonitor.monitor(this._elementRef,true).subscribe(()=>{Promise.resolve().then(()=>this._recentlyCleared.set(null));});}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef),this._sort.deregister(this),this._renderChanges?.unsubscribe(),this._sortButton&&this._ariaDescriber?.removeDescription(this._sortButton,this._sortActionDescription);}_toggleOnInteraction(){if(!this._isDisabled()){let t=this._isSorted(),i=this._sort.direction;this._sort.sort(this),this._recentlyCleared.set(t&&!this._isSorted()?i:null);}}_handleKeydown(t){(t.keyCode===32||t.keyCode===13)&&(t.preventDefault(),this._toggleOnInteraction());}_isSorted(){return this._sort.active==this.id&&(this._sort.direction==="asc"||this._sort.direction==="desc")}_isDisabled(){return this._sort.disabled||this.disabled}_getAriaSortAttribute(){return this._isSorted()?this._sort.direction=="asc"?"ascending":"descending":"none"}_renderArrow(){return !this._isDisabled()||this._isSorted()}_updateSortActionDescription(t){this._sortButton&&(this._ariaDescriber?.removeDescription(this._sortButton,this._sortActionDescription),this._ariaDescriber?.describe(this._sortButton,t)),this._sortActionDescription=t;}static \u0275fac=function(i){return new(i||e)};static \u0275cmp=zo({type:e,selectors:[["","mat-sort-header",""]],hostAttrs:[1,"mat-sort-header"],hostVars:3,hostBindings:function(i,r){i&1&&ny("click",function(){return r._toggleOnInteraction()})("keydown",function(Y){return r._handleKeydown(Y)})("mouseleave",function(){return r._recentlyCleared.set(null)}),i&2&&(Wo("aria-sort",r._getAriaSortAttribute()),la("mat-sort-header-disabled",r._isDisabled()));},inputs:{id:[0,"mat-sort-header","id"],arrowPosition:"arrowPosition",start:"start",disabled:[2,"disabled","disabled",Ad],sortActionDescription:"sortActionDescription",disableClear:[2,"disableClear","disableClear",Ad]},exportAs:["matSortHeader"],ngContentSelectors:q,decls:4,vars:17,consts:[[1,"mat-sort-header-container","mat-focus-indicator"],[1,"mat-sort-header-content"],[1,"mat-sort-header-arrow"],["viewBox","0 -960 960 960","focusable","false","aria-hidden","true"],["d","M440-240v-368L296-464l-56-56 240-240 240 240-56 56-144-144v368h-80Z"]],template:function(i,r){i&1&&(sd(V),td(0,"div",0)(1,"div",1),ad(2),nd(),z_(3,U,3,0,"div",2),nd()),i&2&&(la("mat-sort-header-sorted",r._isSorted())("mat-sort-header-position-before",r.arrowPosition==="before")("mat-sort-header-descending",r._sort.direction==="desc")("mat-sort-header-ascending",r._sort.direction==="asc")("mat-sort-header-recently-cleared-ascending",r._recentlyCleared()==="asc")("mat-sort-header-recently-cleared-descending",r._recentlyCleared()==="desc")("mat-sort-header-animations-disabled",r._animationsDisabled),Wo("tabindex",r._isDisabled()?null:0)("role",r._isDisabled()?null:"button"),$w(3),G_(r._renderArrow()?3:-1));},styles:[`.mat-sort-header {
  cursor: pointer;
}

.mat-sort-header-disabled {
  cursor: default;
}

.mat-sort-header-container {
  display: flex;
  align-items: center;
  letter-spacing: normal;
  outline: 0;
}
[mat-sort-header].cdk-keyboard-focused .mat-sort-header-container, [mat-sort-header].cdk-program-focused .mat-sort-header-container {
  border-bottom: solid 1px currentColor;
}
.mat-sort-header-container::before {
  margin: calc(calc(var(--mat-focus-indicator-border-width, 3px) + 2px) * -1);
}

.mat-sort-header-content {
  display: flex;
  align-items: center;
}

.mat-sort-header-position-before {
  flex-direction: row-reverse;
}

@keyframes _mat-sort-header-recently-cleared-ascending {
  from {
    transform: translateY(0);
    opacity: 1;
  }
  to {
    transform: translateY(-25%);
    opacity: 0;
  }
}
@keyframes _mat-sort-header-recently-cleared-descending {
  from {
    transform: translateY(0) rotate(180deg);
    opacity: 1;
  }
  to {
    transform: translateY(25%) rotate(180deg);
    opacity: 0;
  }
}
.mat-sort-header-arrow {
  height: 12px;
  width: 12px;
  position: relative;
  transition: transform 225ms cubic-bezier(0.4, 0, 0.2, 1), opacity 225ms cubic-bezier(0.4, 0, 0.2, 1);
  opacity: 0;
  overflow: visible;
  color: var(--mat-sort-arrow-color, var(--mat-sys-on-surface));
}
.mat-sort-header.cdk-keyboard-focused .mat-sort-header-arrow, .mat-sort-header.cdk-program-focused .mat-sort-header-arrow, .mat-sort-header:hover .mat-sort-header-arrow {
  opacity: 0.54;
}
.mat-sort-header .mat-sort-header-sorted .mat-sort-header-arrow {
  opacity: 1;
}
.mat-sort-header-descending .mat-sort-header-arrow {
  transform: rotate(180deg);
}
.mat-sort-header-recently-cleared-ascending .mat-sort-header-arrow {
  transform: translateY(-25%);
}
.mat-sort-header-recently-cleared-ascending .mat-sort-header-arrow {
  transition: none;
  animation: _mat-sort-header-recently-cleared-ascending 225ms cubic-bezier(0.4, 0, 0.2, 1) forwards;
}
.mat-sort-header-recently-cleared-descending .mat-sort-header-arrow {
  transition: none;
  animation: _mat-sort-header-recently-cleared-descending 225ms cubic-bezier(0.4, 0, 0.2, 1) forwards;
}
.mat-sort-header-animations-disabled .mat-sort-header-arrow {
  transition-duration: 0ms;
  animation-duration: 0ms;
}
.mat-sort-header-arrow > svg, .mat-sort-header-arrow [matSortHeaderIcon] {
  width: 24px;
  height: 24px;
  fill: currentColor;
  position: absolute;
  top: 50%;
  left: 50%;
  margin: -12px 0 0 -12px;
  transform: translateZ(0);
}
.mat-sort-header-arrow, [dir=rtl] .mat-sort-header-position-before .mat-sort-header-arrow {
  margin: 0 0 0 6px;
}
.mat-sort-header-position-before .mat-sort-header-arrow, [dir=rtl] .mat-sort-header-arrow {
  margin: 0 6px 0 0;
}
`],encapsulation:2})}return e})(),gt=(()=>{class e{static \u0275fac=function(i){return new(i||e)};static \u0275mod=Lt({type:e});static \u0275inj=ht({imports:[Xv]})}return e})();export{W,gt as g,pt as p};