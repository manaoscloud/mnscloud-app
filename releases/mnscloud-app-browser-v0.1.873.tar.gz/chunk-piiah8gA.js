import {aS as Xe,aT as xe,aV as G8,da as zr,ae as G,aY as ge$1,bz as Ie,b0 as v,aZ as Me,br as Rr,a_ as Fr,h,aW as uv,b4 as sD,af as ce,db as NG,b8 as j8,v as ve$1,ba as ii,bb as Ne,cj as sE,e as Ql,bg as AC,ai as sd,bh as NC,ak as ad,H as dC,a9 as Iy,a0 as rd,I as db,_ as fC,C as dy,b$ as dg,aF as Qm,am as Py,aK as cy,b1 as hy,b2 as RC,b3 as OC,dc as Jt,dd as cv,cu as wM,c1 as et$1,cZ as tt,b9 as te,de as sn,bZ as F,df as ln,bc as Zy,d0 as ir,dg as d,dh as g,di as D,dj as o,dk as YD,ci as nr,dl as rc,dm as aE,dn as qD,dp as WD,ct as Wn,cU as Ar,J as Js,w as Ws,A as id,bt as Xp,cO as sy}from'./main-FTRNTF3I.js';var mt=[[["caption"]],[["colgroup"],["col"]],"*"],_t=["caption","colgroup, col","*"];function pt(i,s){i&1&&NC(0,2);}function yt(i,s){i&1&&(Ws(0,"thead",0),cy(1,1),id(),Ws(2,"tbody",0),cy(3,2)(4,3),id(),Ws(5,"tfoot",0),cy(6,4),id());}function gt(i,s){i&1&&cy(0,1)(1,2)(2,3)(3,4);}var b=new v("CDK_TABLE");var ne=(()=>{class i{template=h(Ar);static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["","cdkCellDef",""]]})}return i})(),re=(()=>{class i{template=h(Ar);static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["","cdkHeaderCellDef",""]]})}return i})(),it=(()=>{class i{template=h(Ar);static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["","cdkFooterCellDef",""]]})}return i})(),A=(()=>{class i{_table=h(b,{optional:true});_hasStickyChanged=false;get name(){return this._name}set name(e){this._setNameInput(e);}_name;get sticky(){return this._sticky}set sticky(e){e!==this._sticky&&(this._sticky=e,this._hasStickyChanged=true);}_sticky=false;get stickyEnd(){return this._stickyEnd}set stickyEnd(e){e!==this._stickyEnd&&(this._stickyEnd=e,this._hasStickyChanged=true);}_stickyEnd=false;cell;headerCell;footerCell;cssClassFriendlyName;_columnCssClassName;hasStickyChanged(){let e=this._hasStickyChanged;return this.resetStickyChanged(),e}resetStickyChanged(){this._hasStickyChanged=false;}_updateColumnCssClassName(){this._columnCssClassName=[`cdk-column-${this.cssClassFriendlyName}`];}_setNameInput(e){e&&(this._name=e,this.cssClassFriendlyName=e.replace(/[^a-z0-9_-]/gi,"-"),this._updateColumnCssClassName());}static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["","cdkColumnDef",""]],contentQueries:function(t,o,n){if(t&1&&hy(n,ne,5)(n,re,5)(n,it,5),t&2){let r;RC(r=OC())&&(o.cell=r.first),RC(r=OC())&&(o.headerCell=r.first),RC(r=OC())&&(o.footerCell=r.first);}},inputs:{name:[0,"cdkColumnDef","name"],sticky:[2,"sticky","sticky",Fr],stickyEnd:[2,"stickyEnd","stickyEnd",Fr]}})}return i})(),oe=class{constructor(s,e){e.nativeElement.classList.add(...s._columnCssClassName);}},ot=(()=>{class i extends oe{constructor(){super(h(A),h(ce));}static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["cdk-header-cell"],["th","cdk-header-cell",""]],hostAttrs:["role","columnheader",1,"cdk-header-cell"],features:[Qm]})}return i})();var nt=(()=>{class i extends oe{constructor(){let e=h(A),t=h(ce);super(e,t);let o=e._table?._getCellRole();o&&t.nativeElement.setAttribute("role",o);}static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["cdk-cell"],["td","cdk-cell",""]],hostAttrs:[1,"cdk-cell"],features:[Qm]})}return i})();var fe=(()=>{class i{template=h(Ar);_differs=h(cv);columns;_columnsDiffer;ngOnChanges(e){if(!this._columnsDiffer){let t=e.columns&&e.columns.currentValue||[];this._columnsDiffer=this._differs.find(t).create(),this._columnsDiffer.diff(t);}}getColumnsDiff(){return this._columnsDiffer.diff(this.columns)}extractCellTemplate(e){return this instanceof Y?e.headerCell.template:this instanceof me?e.footerCell.template:e.cell.template}static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,features:[Rr]})}return i})(),Y=(()=>{class i extends fe{_table=h(b,{optional:true});_hasStickyChanged=false;get sticky(){return this._sticky}set sticky(e){e!==this._sticky&&(this._sticky=e,this._hasStickyChanged=true);}_sticky=false;ngOnChanges(e){super.ngOnChanges(e);}hasStickyChanged(){let e=this._hasStickyChanged;return this.resetStickyChanged(),e}resetStickyChanged(){this._hasStickyChanged=false;}static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275dir=Me({type:i,selectors:[["","cdkHeaderRowDef",""]],inputs:{columns:[0,"cdkHeaderRowDef","columns"],sticky:[2,"cdkHeaderRowDefSticky","sticky",Fr]},features:[Qm,Rr]})}return i})(),me=(()=>{class i extends fe{_table=h(b,{optional:true});_hasStickyChanged=false;get sticky(){return this._sticky}set sticky(e){e!==this._sticky&&(this._sticky=e,this._hasStickyChanged=true);}_sticky=false;ngOnChanges(e){super.ngOnChanges(e);}hasStickyChanged(){let e=this._hasStickyChanged;return this.resetStickyChanged(),e}resetStickyChanged(){this._hasStickyChanged=false;}static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275dir=Me({type:i,selectors:[["","cdkFooterRowDef",""]],inputs:{columns:[0,"cdkFooterRowDef","columns"],sticky:[2,"cdkFooterRowDefSticky","sticky",Fr]},features:[Qm,Rr]})}return i})(),se=(()=>{class i extends fe{_table=h(b,{optional:true});when;static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275dir=Me({type:i,selectors:[["","cdkRowDef",""]],inputs:{columns:[0,"cdkRowDefColumns","columns"],when:[0,"cdkRowDefWhen","when"]},features:[Qm]})}return i})(),B=(()=>{class i{_viewContainer=h(Wn);cells;context;static mostRecentCellOutlet=null;constructor(){i.mostRecentCellOutlet=this;}ngOnDestroy(){i.mostRecentCellOutlet===this&&(i.mostRecentCellOutlet=null);}static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["","cdkCellOutlet",""]]})}return i})(),_e=(()=>{class i{static \u0275fac=function(t){return new(t||i)};static \u0275cmp=Ql({type:i,selectors:[["cdk-header-row"],["tr","cdk-header-row",""]],hostAttrs:["role","row",1,"cdk-header-row"],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,o){t&1&&cy(0,0);},dependencies:[B],encapsulation:2,changeDetection:1})}return i})();var pe=(()=>{class i{static \u0275fac=function(t){return new(t||i)};static \u0275cmp=Ql({type:i,selectors:[["cdk-row"],["tr","cdk-row",""]],hostAttrs:["role","row",1,"cdk-row"],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,o){t&1&&cy(0,0);},dependencies:[B],encapsulation:2,changeDetection:1})}return i})(),ae=(()=>{class i{templateRef=h(Ar);_contentClassNames=["cdk-no-data-row","cdk-row"];_cellClassNames=["cdk-cell","cdk-no-data-cell"];_cellSelector="td, cdk-cell, [cdk-cell], .cdk-cell";static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["ng-template","cdkNoDataRow",""]]})}return i})(),Je=["top","bottom","left","right"],he=class{_isNativeHtmlTable;_stickCellCss;_isBrowser;_needsPositionStickyOnElement;direction;_positionListener;_tableInjector;_elemSizeCache=new WeakMap;_resizeObserver=globalThis?.ResizeObserver?new globalThis.ResizeObserver(s=>this._updateCachedSizes(s)):null;_updatedStickyColumnsParamsToReplay=[];_stickyColumnsReplayTimeout=null;_cachedCellWidths=[];_borderCellCss;_destroyed=false;constructor(s,e,t=true,o=true,n,r,l){this._isNativeHtmlTable=s,this._stickCellCss=e,this._isBrowser=t,this._needsPositionStickyOnElement=o,this.direction=n,this._positionListener=r,this._tableInjector=l,this._borderCellCss={top:`${e}-border-elem-top`,bottom:`${e}-border-elem-bottom`,left:`${e}-border-elem-left`,right:`${e}-border-elem-right`};}clearStickyPositioning(s,e){(e.includes("left")||e.includes("right"))&&this._removeFromStickyColumnReplayQueue(s);let t=[];for(let o of s)o.nodeType===o.ELEMENT_NODE&&t.push(o,...Array.from(o.children));Js({write:()=>{for(let o of t)this._removeStickyStyle(o,e);}},{injector:this._tableInjector});}updateStickyColumns(s,e,t,o=true,n=true){if(!s.length||!this._isBrowser||!(e.some(v=>v)||t.some(v=>v))){this._positionListener?.stickyColumnsUpdated({sizes:[]}),this._positionListener?.stickyEndColumnsUpdated({sizes:[]});return}let r=s[0],l=r.children.length,c=this.direction==="rtl",u=c?"right":"left",h=c?"left":"right",D=e.lastIndexOf(true),m=t.indexOf(true),_,ve,Re;n&&this._updateStickyColumnReplayQueue({rows:[...s],stickyStartStates:[...e],stickyEndStates:[...t]}),Js({earlyRead:()=>{_=this._getCellWidths(r,o),ve=this._getStickyStartColumnPositions(_,e),Re=this._getStickyEndColumnPositions(_,t);},write:()=>{for(let v of s)for(let w=0;w<l;w++){let be=v.children[w];e[w]&&this._addStickyStyle(be,u,ve[w],w===D),t[w]&&this._addStickyStyle(be,h,Re[w],w===m);}this._positionListener&&_.some(v=>!!v)&&(this._positionListener.stickyColumnsUpdated({sizes:D===-1?[]:_.slice(0,D+1).map((v,w)=>e[w]?v:null)}),this._positionListener.stickyEndColumnsUpdated({sizes:m===-1?[]:_.slice(m).map((v,w)=>t[w+m]?v:null).reverse()}));}},{injector:this._tableInjector});}stickRows(s,e,t){if(!this._isBrowser)return;let o=t==="bottom"?s.slice().reverse():s,n=t==="bottom"?e.slice().reverse():e,r=[],l=[],c=[];Js({earlyRead:()=>{for(let u=0,h=0;u<o.length;u++){if(!n[u])continue;r[u]=h;let D=o[u];c[u]=this._isNativeHtmlTable?Array.from(D.children):[D];let m=this._retrieveElementSize(D).height;h+=m,l[u]=m;}},write:()=>{let u=n.lastIndexOf(true);for(let h=0;h<o.length;h++){if(!n[h])continue;let D=r[h],m=h===u;for(let _ of c[h])this._addStickyStyle(_,t,D,m);}t==="top"?this._positionListener?.stickyHeaderRowsUpdated({sizes:l,offsets:r,elements:c}):this._positionListener?.stickyFooterRowsUpdated({sizes:l,offsets:r,elements:c});}},{injector:this._tableInjector});}updateStickyFooterContainer(s,e){this._isNativeHtmlTable&&Js({write:()=>{let t=s.querySelector("tfoot");t&&(e.some(o=>!o)?this._removeStickyStyle(t,["bottom"]):this._addStickyStyle(t,"bottom",0,false));}},{injector:this._tableInjector});}destroy(){this._stickyColumnsReplayTimeout&&clearTimeout(this._stickyColumnsReplayTimeout),this._resizeObserver?.disconnect(),this._destroyed=true;}_removeStickyStyle(s,e){if(!s.classList.contains(this._stickCellCss))return;for(let o of e)s.style[o]="",s.classList.remove(this._borderCellCss[o]);Je.some(o=>e.indexOf(o)===-1&&s.style[o])?s.style.zIndex=this._getCalculatedZIndex(s):(s.style.zIndex="",this._needsPositionStickyOnElement&&(s.style.position=""),s.classList.remove(this._stickCellCss));}_addStickyStyle(s,e,t,o){s.classList.add(this._stickCellCss),o&&s.classList.add(this._borderCellCss[e]),s.style[e]=`${t}px`,s.style.zIndex=this._getCalculatedZIndex(s),this._needsPositionStickyOnElement&&(s.style.cssText+="position: -webkit-sticky; position: sticky; ");}_getCalculatedZIndex(s){let e={top:100,bottom:10,left:1,right:1},t=0;for(let o of Je)s.style[o]&&(t+=e[o]);return t?`${t}`:""}_getCellWidths(s,e=true){if(!e&&this._cachedCellWidths.length)return this._cachedCellWidths;let t=[],o=s.children;for(let n=0;n<o.length;n++){let r=o[n];t.push(this._retrieveElementSize(r).width);}return this._cachedCellWidths=t,t}_getStickyStartColumnPositions(s,e){let t=[],o=0;for(let n=0;n<s.length;n++)e[n]&&(t[n]=o,o+=s[n]);return t}_getStickyEndColumnPositions(s,e){let t=[],o=0;for(let n=s.length;n>0;n--)e[n]&&(t[n]=o,o+=s[n]);return t}_retrieveElementSize(s){let e=this._elemSizeCache.get(s);if(e)return e;let t=s.getBoundingClientRect(),o={width:t.width,height:t.height};return this._resizeObserver&&(this._elemSizeCache.set(s,o),this._resizeObserver.observe(s,{box:"border-box"})),o}_updateStickyColumnReplayQueue(s){this._removeFromStickyColumnReplayQueue(s.rows),this._stickyColumnsReplayTimeout||this._updatedStickyColumnsParamsToReplay.push(s);}_removeFromStickyColumnReplayQueue(s){let e=new Set(s);for(let t of this._updatedStickyColumnsParamsToReplay)t.rows=t.rows.filter(o=>!e.has(o));this._updatedStickyColumnsParamsToReplay=this._updatedStickyColumnsParamsToReplay.filter(t=>!!t.rows.length);}_updateCachedSizes(s){let e=false;for(let t of s){let o=t.borderBoxSize?.length?{width:t.borderBoxSize[0].inlineSize,height:t.borderBoxSize[0].blockSize}:{width:t.contentRect.width,height:t.contentRect.height};o.width!==this._elemSizeCache.get(t.target)?.width&&wt(t.target)&&(e=true),this._elemSizeCache.set(t.target,o);}e&&this._updatedStickyColumnsParamsToReplay.length&&(this._stickyColumnsReplayTimeout&&clearTimeout(this._stickyColumnsReplayTimeout),this._stickyColumnsReplayTimeout=setTimeout(()=>{if(!this._destroyed){for(let t of this._updatedStickyColumnsParamsToReplay)this.updateStickyColumns(t.rows,t.stickyStartStates,t.stickyEndStates,true,false);this._updatedStickyColumnsParamsToReplay=[],this._stickyColumnsReplayTimeout=null;}},0));}};function wt(i){return ["cdk-cell","cdk-header-cell","cdk-footer-cell"].some(s=>i.classList.contains(s))}var K=new v("STICKY_POSITIONING_LISTENER");var ye=(()=>{class i{viewContainer=h(Wn);elementRef=h(ce);constructor(){let e=h(b);e._rowOutlet=this,e._outletAssigned();}static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["","rowOutlet",""]]})}return i})(),ge=(()=>{class i{viewContainer=h(Wn);elementRef=h(ce);constructor(){let e=h(b);e._headerRowOutlet=this,e._outletAssigned();}static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["","headerRowOutlet",""]]})}return i})(),we=(()=>{class i{viewContainer=h(Wn);elementRef=h(ce);constructor(){let e=h(b);e._footerRowOutlet=this,e._outletAssigned();}static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["","footerRowOutlet",""]]})}return i})(),De=(()=>{class i{viewContainer=h(Wn);elementRef=h(ce);constructor(){let e=h(b);e._noDataRowOutlet=this,e._outletAssigned();}static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["","noDataRowOutlet",""]]})}return i})(),Ce=(()=>{class i{_differs=h(cv);_changeDetectorRef=h(uv);_elementRef=h(ce);_dir=h(wM,{optional:true});_platform=h(et$1);_viewRepeater;_viewportRuler=h(tt);_injector=h(te);_virtualScrollViewport=h(sn,{optional:true,host:true});_positionListener=h(K,{optional:true})||h(K,{optional:true,skipSelf:true});_document=h(F);_data;_renderedRange;_onDestroy=new G;_renderRows;_renderChangeSubscription=null;_columnDefsByName=new Map;_rowDefs;_headerRowDefs;_footerRowDefs;_dataDiffer;_defaultRowDef=null;_customColumnDefs=new Set;_customRowDefs=new Set;_customHeaderRowDefs=new Set;_customFooterRowDefs=new Set;_customNoDataRow=null;_headerRowDefChanged=true;_footerRowDefChanged=true;_stickyColumnStylesNeedReset=true;_forceRecalculateCellWidths=true;_cachedRenderRowsMap=new Map;_isNativeHtmlTable;_stickyStyler;stickyCssClass="cdk-table-sticky";needsPositionStickyOnElement=true;_isServer;_isShowingNoDataRow=false;_hasAllOutlets=false;_hasInitialized=false;_headerRowStickyUpdates=new G;_footerRowStickyUpdates=new G;_disableVirtualScrolling=false;_getCellRole(){if(this._cellRoleInternal===void 0){let e=this._elementRef.nativeElement.getAttribute("role");return e==="grid"||e==="treegrid"?"gridcell":"cell"}return this._cellRoleInternal}_cellRoleInternal=void 0;get trackBy(){return this._trackByFn}set trackBy(e){this._trackByFn=e;}_trackByFn;get dataSource(){return this._dataSource}set dataSource(e){this._dataSource!==e&&(this._switchDataSource(e),this._changeDetectorRef.markForCheck());}_dataSource;_dataSourceChanges=new G;_dataStream=new G;get multiTemplateDataRows(){return this._multiTemplateDataRows}set multiTemplateDataRows(e){this._multiTemplateDataRows=e,this._rowOutlet&&this._rowOutlet.viewContainer.length&&(this._forceRenderDataRows(),this.updateStickyColumnStyles());}_multiTemplateDataRows=false;get fixedLayout(){return this._virtualScrollEnabled()?true:this._fixedLayout}set fixedLayout(e){this._fixedLayout=e,this._forceRecalculateCellWidths=true,this._stickyColumnStylesNeedReset=true;}_fixedLayout=false;recycleRows=false;contentChanged=new ge$1;viewChange=new ln({start:0,end:Number.MAX_VALUE});_rowOutlet;_headerRowOutlet;_footerRowOutlet;_noDataRowOutlet;_contentColumnDefs;_contentRowDefs;_contentHeaderRowDefs;_contentFooterRowDefs;_noDataRow;get renderedRows(){return this._renderRows}constructor(){h(new Zy("role"),{optional:true})||this._elementRef.nativeElement.setAttribute("role","table"),this._isServer=!this._platform.isBrowser,this._isNativeHtmlTable=this._elementRef.nativeElement.nodeName==="TABLE",this._dataDiffer=this._differs.find([]).create((t,o)=>this.trackBy?this.trackBy(o.dataIndex,o.data):o);}ngOnInit(){this._setupStickyStyler(),this._viewportRuler.change().pipe(ir(this._onDestroy)).subscribe(()=>{this._forceRecalculateCellWidths=true;});}ngAfterContentInit(){this._viewRepeater=this.recycleRows||this._virtualScrollEnabled()?new d:new g,this._virtualScrollEnabled()&&this._setupVirtualScrolling(this._virtualScrollViewport),this._hasInitialized=true;}ngAfterContentChecked(){this._canRender()&&this._render();}ngOnDestroy(){this._stickyStyler?.destroy(),[this._rowOutlet?.viewContainer,this._headerRowOutlet?.viewContainer,this._footerRowOutlet?.viewContainer,this._cachedRenderRowsMap,this._customColumnDefs,this._customRowDefs,this._customHeaderRowDefs,this._customFooterRowDefs,this._columnDefsByName].forEach(e=>{e?.clear();}),this._headerRowDefs=[],this._footerRowDefs=[],this._defaultRowDef=null,this._headerRowStickyUpdates.complete(),this._footerRowStickyUpdates.complete(),this._onDestroy.next(),this._onDestroy.complete(),D(this.dataSource)&&this.dataSource.disconnect(this);}renderRows(){this._renderRows=this._getAllRenderRows();let e=this._dataDiffer.diff(this._renderRows);if(!e){this._updateNoDataRow(),this.contentChanged.next();return}let t=this._rowOutlet.viewContainer;this._viewRepeater.applyChanges(e,t,(o,n,r)=>this._getEmbeddedViewArgs(o.item,r),o=>o.item.data,o$1=>{o$1.operation===o.INSERTED&&o$1.context&&this._renderCellTemplateForItem(o$1.record.item.rowDef,o$1.context);}),this._updateRowIndexContext(),e.forEachIdentityChange(o=>{let n=t.get(o.currentIndex);n.context.$implicit=o.item.data;}),this._updateNoDataRow(),this.contentChanged.next(),this.updateStickyColumnStyles();}addColumnDef(e){this._customColumnDefs.add(e);}removeColumnDef(e){this._customColumnDefs.delete(e);}addRowDef(e){this._customRowDefs.add(e);}removeRowDef(e){this._customRowDefs.delete(e);}addHeaderRowDef(e){this._customHeaderRowDefs.add(e),this._headerRowDefChanged=true;}removeHeaderRowDef(e){this._customHeaderRowDefs.delete(e),this._headerRowDefChanged=true;}addFooterRowDef(e){this._customFooterRowDefs.add(e),this._footerRowDefChanged=true;}removeFooterRowDef(e){this._customFooterRowDefs.delete(e),this._footerRowDefChanged=true;}setNoDataRow(e){this._customNoDataRow=e;}updateStickyHeaderRowStyles(){let e=this._getRenderedRows(this._headerRowOutlet);if(this._isNativeHtmlTable){let o=et(this._headerRowOutlet,"thead");o&&(o.style.display=e.length?"":"none");}let t=this._headerRowDefs.map(o=>o.sticky);this._stickyStyler.clearStickyPositioning(e,["top"]),this._stickyStyler.stickRows(e,t,"top"),this._headerRowDefs.forEach(o=>o.resetStickyChanged());}updateStickyFooterRowStyles(){let e=this._getRenderedRows(this._footerRowOutlet);if(this._isNativeHtmlTable){let o=et(this._footerRowOutlet,"tfoot");o&&(o.style.display=e.length?"":"none");}let t=this._footerRowDefs.map(o=>o.sticky);this._stickyStyler.clearStickyPositioning(e,["bottom"]),this._stickyStyler.stickRows(e,t,"bottom"),this._stickyStyler.updateStickyFooterContainer(this._elementRef.nativeElement,t),this._footerRowDefs.forEach(o=>o.resetStickyChanged());}updateStickyColumnStyles(){let e=this._getRenderedRows(this._headerRowOutlet),t=this._getRenderedRows(this._rowOutlet),o=this._getRenderedRows(this._footerRowOutlet);(this._isNativeHtmlTable&&!this.fixedLayout||this._stickyColumnStylesNeedReset)&&(this._stickyStyler.clearStickyPositioning([...e,...t,...o],["left","right"]),this._stickyColumnStylesNeedReset=false),e.forEach((n,r)=>{this._addStickyColumnStyles([n],this._headerRowDefs[r]);}),this._rowDefs.forEach(n=>{let r=[];for(let l=0;l<t.length;l++)this._renderRows[l].rowDef===n&&r.push(t[l]);this._addStickyColumnStyles(r,n);}),o.forEach((n,r)=>{this._addStickyColumnStyles([n],this._footerRowDefs[r]);}),Array.from(this._columnDefsByName.values()).forEach(n=>n.resetStickyChanged());}stickyColumnsUpdated(e){this._positionListener?.stickyColumnsUpdated(e);}stickyEndColumnsUpdated(e){this._positionListener?.stickyEndColumnsUpdated(e);}stickyHeaderRowsUpdated(e){this._headerRowStickyUpdates.next(e),this._positionListener?.stickyHeaderRowsUpdated(e);}stickyFooterRowsUpdated(e){this._footerRowStickyUpdates.next(e),this._positionListener?.stickyFooterRowsUpdated(e);}_outletAssigned(){!this._hasAllOutlets&&this._rowOutlet&&this._headerRowOutlet&&this._footerRowOutlet&&this._noDataRowOutlet&&(this._hasAllOutlets=true,this._canRender()&&this._render());}_canRender(){return this._hasAllOutlets&&this._hasInitialized}_render(){this._cacheRowDefs(),this._cacheColumnDefs(),!this._headerRowDefs.length&&!this._footerRowDefs.length&&this._rowDefs.length;let t=this._renderUpdatedColumns()||this._headerRowDefChanged||this._footerRowDefChanged;this._stickyColumnStylesNeedReset=this._stickyColumnStylesNeedReset||t,this._forceRecalculateCellWidths=t,this._headerRowDefChanged&&(this._forceRenderHeaderRows(),this._headerRowDefChanged=false),this._footerRowDefChanged&&(this._forceRenderFooterRows(),this._footerRowDefChanged=false),this.dataSource&&this._rowDefs.length>0&&!this._renderChangeSubscription?this._observeRenderChanges():this._stickyColumnStylesNeedReset&&this.updateStickyColumnStyles(),this._checkStickyStates();}_getAllRenderRows(){if(!Array.isArray(this._data)||!this._renderedRange)return [];let e=[],t=Math.min(this._data.length,this._renderedRange.end),o=this._cachedRenderRowsMap;this._cachedRenderRowsMap=new Map;for(let n=this._renderedRange.start;n<t;n++){let r=this._data[n],l=this._getRenderRowsForData(r,n,o.get(r));this._cachedRenderRowsMap.has(r)||this._cachedRenderRowsMap.set(r,new WeakMap);for(let c=0;c<l.length;c++){let u=l[c],h=this._cachedRenderRowsMap.get(u.data);h.has(u.rowDef)?h.get(u.rowDef).push(u):h.set(u.rowDef,[u]),e.push(u);}}return e}_getRenderRowsForData(e,t,o){return this._getRowDefs(e,t).map(r=>{let l=o&&o.has(r)?o.get(r):[];if(l.length){let c=l.shift();return c.dataIndex=t,c}else return {data:e,rowDef:r,dataIndex:t}})}_cacheColumnDefs(){this._columnDefsByName.clear(),ie(this._getOwnDefs(this._contentColumnDefs),this._customColumnDefs).forEach(t=>{this._columnDefsByName.has(t.name),this._columnDefsByName.set(t.name,t);});}_cacheRowDefs(){this._headerRowDefs=ie(this._getOwnDefs(this._contentHeaderRowDefs),this._customHeaderRowDefs),this._footerRowDefs=ie(this._getOwnDefs(this._contentFooterRowDefs),this._customFooterRowDefs),this._rowDefs=ie(this._getOwnDefs(this._contentRowDefs),this._customRowDefs);let e=this._rowDefs.filter(t=>!t.when);this._defaultRowDef=e[0];}_renderUpdatedColumns(){let e=(r,l)=>{let c=!!l.getColumnsDiff();return r||c},t=this._rowDefs.reduce(e,false);t&&this._forceRenderDataRows();let o=this._headerRowDefs.reduce(e,false);o&&this._forceRenderHeaderRows();let n=this._footerRowDefs.reduce(e,false);return n&&this._forceRenderFooterRows(),t||o||n}_switchDataSource(e){this._data=[],D(this.dataSource)&&this.dataSource.disconnect(this),this._renderChangeSubscription&&(this._renderChangeSubscription.unsubscribe(),this._renderChangeSubscription=null),e||(this._dataDiffer&&this._dataDiffer.diff([]),this._rowOutlet&&this._rowOutlet.viewContainer.clear()),this._dataSource=e;}_observeRenderChanges(){if(!this.dataSource)return;let e;D(this.dataSource)?e=this.dataSource.connect(this):YD(this.dataSource)?e=this.dataSource:Array.isArray(this.dataSource)&&(e=nr(this.dataSource)),this._renderChangeSubscription=rc([e,this.viewChange]).pipe(ir(this._onDestroy)).subscribe(([t,o])=>{this._data=t||[],this._renderedRange=o,this._dataStream.next(t),this.renderRows();});}_forceRenderHeaderRows(){this._headerRowOutlet.viewContainer.length>0&&this._headerRowOutlet.viewContainer.clear(),this._headerRowDefs.forEach((e,t)=>this._renderRow(this._headerRowOutlet,e,t)),this.updateStickyHeaderRowStyles();}_forceRenderFooterRows(){this._footerRowOutlet.viewContainer.length>0&&this._footerRowOutlet.viewContainer.clear(),this._footerRowDefs.forEach((e,t)=>this._renderRow(this._footerRowOutlet,e,t)),this.updateStickyFooterRowStyles();}_addStickyColumnStyles(e,t){let o=Array.from(t?.columns||[]).map(l=>{let c=this._columnDefsByName.get(l);return c}),n=o.map(l=>l.sticky),r=o.map(l=>l.stickyEnd);this._stickyStyler.updateStickyColumns(e,n,r,!this.fixedLayout||this._forceRecalculateCellWidths);}_getRenderedRows(e){let t=[];for(let o=0;o<e.viewContainer.length;o++){let n=e.viewContainer.get(o);t.push(n.rootNodes[0]);}return t}_getRowDefs(e,t){if(this._rowDefs.length===1)return [this._rowDefs[0]];let o=[];if(this.multiTemplateDataRows)o=this._rowDefs.filter(n=>!n.when||n.when(t,e));else {let n=this._rowDefs.find(r=>r.when&&r.when(t,e))||this._defaultRowDef;n&&o.push(n);}return o.length,o}_getEmbeddedViewArgs(e,t){let o=e.rowDef,n={$implicit:e.data};return {templateRef:o.template,context:n,index:t}}_renderRow(e,t,o,n={}){let r=e.viewContainer.createEmbeddedView(t.template,n,o);return this._renderCellTemplateForItem(t,n),r}_renderCellTemplateForItem(e,t){for(let o of this._getCellTemplates(e))B.mostRecentCellOutlet&&B.mostRecentCellOutlet._viewContainer.createEmbeddedView(o,t);this._changeDetectorRef.markForCheck();}_updateRowIndexContext(){let e=this._rowOutlet.viewContainer;for(let t=0,o=e.length;t<o;t++){let r=e.get(t).context;r.count=o,r.first=t===0,r.last=t===o-1,r.even=t%2===0,r.odd=!r.even,this.multiTemplateDataRows?(r.dataIndex=this._renderRows[t].dataIndex,r.renderIndex=t):r.index=this._renderRows[t].dataIndex;}}_getCellTemplates(e){return !e||!e.columns?[]:Array.from(e.columns,t=>{let o=this._columnDefsByName.get(t);return e.extractCellTemplate(o)})}_forceRenderDataRows(){this._dataDiffer.diff([]),this._rowOutlet.viewContainer.clear(),this.renderRows();}_checkStickyStates(){let e=(t,o)=>t||o.hasStickyChanged();this._headerRowDefs.reduce(e,false)&&this.updateStickyHeaderRowStyles(),this._footerRowDefs.reduce(e,false)&&this.updateStickyFooterRowStyles(),Array.from(this._columnDefsByName.values()).reduce(e,false)&&(this._stickyColumnStylesNeedReset=true,this.updateStickyColumnStyles());}_setupStickyStyler(){let e=this._dir?this._dir.value:"ltr",t=this._injector;this._stickyStyler=new he(this._isNativeHtmlTable,this.stickyCssClass,this._platform.isBrowser,this.needsPositionStickyOnElement,e,this,t),(this._dir?this._dir.change:nr()).pipe(ir(this._onDestroy)).subscribe(o=>{this._stickyStyler.direction=o,this.updateStickyColumnStyles();});}_setupVirtualScrolling(e){let t=typeof requestAnimationFrame<"u"?qD:WD;this.viewChange.next({start:0,end:0}),e.renderedRangeStream.pipe(aE(0,t),ir(this._onDestroy)).subscribe(this.viewChange),e.attach({dataStream:this._dataStream,measureRangeSize:(o,n)=>this._measureRangeSize(o,n)}),rc([e.renderedContentOffset,this._headerRowStickyUpdates]).pipe(ir(this._onDestroy)).subscribe(([o,n])=>{if(!(!n.sizes||!n.offsets||!n.elements))for(let r=0;r<n.elements.length;r++){let l=n.elements[r];if(l){let c=n.offsets[r],u=o!==0?Math.max(o-c,c):-c;for(let h of l)h.style.top=`${-u}px`;}}}),rc([e.renderedContentOffset,this._footerRowStickyUpdates]).pipe(ir(this._onDestroy)).subscribe(([o,n])=>{if(!(!n.sizes||!n.offsets||!n.elements))for(let r=0;r<n.elements.length;r++){let l=n.elements[r];if(l)for(let c of l)c.style.bottom=`${o+n.offsets[r]}px`;}});}_getOwnDefs(e){return e.filter(t=>!t._table||t._table===this)}_updateNoDataRow(){let e=this._customNoDataRow||this._noDataRow;if(!e)return;let t=this._rowOutlet.viewContainer.length===0;if(t===this._isShowingNoDataRow)return;let o=this._noDataRowOutlet.viewContainer;if(t){let n=o.createEmbeddedView(e.templateRef),r=n.rootNodes[0];if(n.rootNodes.length===1&&r?.nodeType===this._document.ELEMENT_NODE){r.setAttribute("role","row"),r.classList.add(...e._contentClassNames);let l=r.querySelectorAll(e._cellSelector);for(let c=0;c<l.length;c++)l[c].classList.add(...e._cellClassNames);}}else o.clear();this._isShowingNoDataRow=t,this._changeDetectorRef.markForCheck();}_measureRangeSize(e,t){if(e.start>=e.end||t!=="vertical")return 0;let o=this.viewChange.value,n=this._rowOutlet.viewContainer;e.start<o.start||e.end>o.end;let r=e.start-o.start,l=e.end-e.start,c,u;for(let m=0;m<l;m++){let _=n.get(m+r);if(_&&_.rootNodes.length){c=u=_.rootNodes[0];break}}for(let m=l-1;m>-1;m--){let _=n.get(m+r);if(_&&_.rootNodes.length){u=_.rootNodes[_.rootNodes.length-1];break}}let h=c?.getBoundingClientRect?.(),D=u?.getBoundingClientRect?.();return h&&D?D.bottom-h.top:0}_virtualScrollEnabled(){return !this._disableVirtualScrolling&&this._virtualScrollViewport!=null}static \u0275fac=function(t){return new(t||i)};static \u0275cmp=Ql({type:i,selectors:[["cdk-table"],["table","cdk-table",""]],contentQueries:function(t,o,n){if(t&1&&hy(n,ae,5)(n,A,5)(n,se,5)(n,Y,5)(n,me,5),t&2){let r;RC(r=OC())&&(o._noDataRow=r.first),RC(r=OC())&&(o._contentColumnDefs=r),RC(r=OC())&&(o._contentRowDefs=r),RC(r=OC())&&(o._contentHeaderRowDefs=r),RC(r=OC())&&(o._contentFooterRowDefs=r);}},hostAttrs:[1,"cdk-table"],hostVars:2,hostBindings:function(t,o){t&2&&Iy("cdk-table-fixed-layout",o.fixedLayout);},inputs:{trackBy:"trackBy",dataSource:"dataSource",multiTemplateDataRows:[2,"multiTemplateDataRows","multiTemplateDataRows",Fr],fixedLayout:[2,"fixedLayout","fixedLayout",Fr],recycleRows:[2,"recycleRows","recycleRows",Fr]},outputs:{contentChanged:"contentChanged"},exportAs:["cdkTable"],features:[Py([{provide:b,useExisting:i},{provide:K,useValue:null}])],ngContentSelectors:_t,decls:5,vars:2,consts:[["role","rowgroup"],["headerRowOutlet",""],["rowOutlet",""],["noDataRowOutlet",""],["footerRowOutlet",""]],template:function(t,o){t&1&&(AC(mt),NC(0),NC(1,1),dC(2,pt,1,0),dC(3,yt,7,0)(4,gt,4,0)),t&2&&(db(2),fC(o._isServer?2:-1),db(),fC(o._isNativeHtmlTable?3:4));},dependencies:[ge,ye,De,we],styles:[`.cdk-table-fixed-layout {
  table-layout: fixed;
}
`],encapsulation:2,changeDetection:1})}return i})();function ie(i,s){return i.concat(Array.from(s))}function et(i,s){let e=s.toUpperCase(),t=i.viewContainer.element.nativeElement;for(;t;){let o=t.nodeType===1?t.nodeName:null;if(o===e)return t;if(o==="TABLE")break;t=t.parentNode;}return null}var rt=(()=>{class i{static \u0275fac=function(t){return new(t||i)};static \u0275mod=Xe({type:i});static \u0275inj=xe({imports:[Jt]})}return i})();var Dt=["*",[["","matSortHeaderIcon",""]]],Ct=["*","[matSortHeaderIcon]"];function vt(i,s){i&1&&(Xp(),sd(0,"svg",3),sy(1,"path",4),ad());}function Rt(i,s){i&1&&(sd(0,"div",2),NC(1,1,null,vt,2,0),ad());}var st=new v("MAT_SORT_DEFAULT_OPTIONS"),bt=(()=>{class i{_defaultOptions;_initializedStream=new zr(1);sortables=new Map;_stateChanges=new G;active;start="asc";get direction(){return this._direction}set direction(e){this._direction=e;}_direction="";disableClear;disabled=false;sortChange=new ge$1;initialized=this._initializedStream;constructor(e){this._defaultOptions=e;}register(e){this.sortables.set(e.id,e);}deregister(e){this.sortables.delete(e.id);}sort(e){this.active!=e.id?(this.active=e.id,this.direction=e.start?e.start:this.start):this.direction=this.getNextSortDirection(e),this.sortChange.emit({active:this.active,direction:this.direction});}getNextSortDirection(e){if(!e)return "";let t=e?.disableClear??this.disableClear??!!this._defaultOptions?.disableClear,o=kt(e.start||this.start,t),n=o.indexOf(this.direction)+1;return n>=o.length&&(n=0),o[n]}ngOnInit(){this._initializedStream.next();}ngOnChanges(){this._stateChanges.next();}ngOnDestroy(){this._stateChanges.complete(),this._initializedStream.complete();}static \u0275fac=function(t){return new(t||i)(Ie(st,8))};static \u0275dir=Me({type:i,selectors:[["","matSort",""]],hostAttrs:[1,"mat-sort"],inputs:{active:[0,"matSortActive","active"],start:[0,"matSortStart","start"],direction:[0,"matSortDirection","direction"],disableClear:[2,"matSortDisableClear","disableClear",Fr],disabled:[2,"matSortDisabled","disabled",Fr]},outputs:{sortChange:"matSortChange"},exportAs:["matSort"],features:[Rr]})}return i})();function kt(i,s){let e=["asc","desc"];return i=="desc"&&e.reverse(),s||e.push(""),e}var gi=(()=>{class i{_sort=h(bt,{optional:true});_columnDef=h(A,{optional:true});_changeDetectorRef=h(uv);_focusMonitor=h(sD);_elementRef=h(ce);_ariaDescriber=h(NG,{optional:true});_renderChanges;_animationsDisabled=j8();_recentlyCleared=ve$1(null);_sortButton;id;arrowPosition="after";start;disabled=false;get sortActionDescription(){return this._sortActionDescription}set sortActionDescription(e){this._updateSortActionDescription(e);}_sortActionDescription="Sort";disableClear;constructor(){h(ii).load(Ne);let e=h(st,{optional:true});this._sort,e?.arrowPosition&&(this.arrowPosition=e?.arrowPosition);}ngOnInit(){!this.id&&this._columnDef&&(this.id=this._columnDef.name),this._sort.register(this),this._renderChanges=sE(this._sort._stateChanges,this._sort.sortChange).subscribe(()=>this._changeDetectorRef.markForCheck()),this._sortButton=this._elementRef.nativeElement.querySelector(".mat-sort-header-container"),this._updateSortActionDescription(this._sortActionDescription);}ngAfterViewInit(){this._focusMonitor.monitor(this._elementRef,true).subscribe(()=>{Promise.resolve().then(()=>this._recentlyCleared.set(null));});}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef),this._sort.deregister(this),this._renderChanges?.unsubscribe(),this._sortButton&&this._ariaDescriber?.removeDescription(this._sortButton,this._sortActionDescription);}_toggleOnInteraction(){if(!this._isDisabled()){let e=this._isSorted(),t=this._sort.direction;this._sort.sort(this),this._recentlyCleared.set(e&&!this._isSorted()?t:null);}}_handleKeydown(e){(e.keyCode===32||e.keyCode===13)&&(e.preventDefault(),this._toggleOnInteraction());}_isSorted(){return this._sort.active==this.id&&(this._sort.direction==="asc"||this._sort.direction==="desc")}_isDisabled(){return this._sort.disabled||this.disabled}_getAriaSortAttribute(){return this._isSorted()?this._sort.direction=="asc"?"ascending":"descending":"none"}_renderArrow(){return !this._isDisabled()||this._isSorted()}_updateSortActionDescription(e){this._sortButton&&(this._ariaDescriber?.removeDescription(this._sortButton,this._sortActionDescription),this._ariaDescriber?.describe(this._sortButton,e)),this._sortActionDescription=e;}static \u0275fac=function(t){return new(t||i)};static \u0275cmp=Ql({type:i,selectors:[["","mat-sort-header",""]],hostAttrs:[1,"mat-sort-header"],hostVars:3,hostBindings:function(t,o){t&1&&dy("click",function(){return o._toggleOnInteraction()})("keydown",function(r){return o._handleKeydown(r)})("mouseleave",function(){return o._recentlyCleared.set(null)}),t&2&&(rd("aria-sort",o._getAriaSortAttribute()),Iy("mat-sort-header-disabled",o._isDisabled()));},inputs:{id:[0,"mat-sort-header","id"],arrowPosition:"arrowPosition",start:"start",disabled:[2,"disabled","disabled",Fr],sortActionDescription:"sortActionDescription",disableClear:[2,"disableClear","disableClear",Fr]},exportAs:["matSortHeader"],ngContentSelectors:Ct,decls:4,vars:17,consts:[[1,"mat-sort-header-container","mat-focus-indicator"],[1,"mat-sort-header-content"],[1,"mat-sort-header-arrow"],["viewBox","0 -960 960 960","focusable","false","aria-hidden","true"],["d","M440-240v-368L296-464l-56-56 240-240 240 240-56 56-144-144v368h-80Z"]],template:function(t,o){t&1&&(AC(Dt),sd(0,"div",0)(1,"div",1),NC(2),ad(),dC(3,Rt,3,0,"div",2),ad()),t&2&&(Iy("mat-sort-header-sorted",o._isSorted())("mat-sort-header-position-before",o.arrowPosition==="before")("mat-sort-header-descending",o._sort.direction==="desc")("mat-sort-header-ascending",o._sort.direction==="asc")("mat-sort-header-recently-cleared-ascending",o._recentlyCleared()==="asc")("mat-sort-header-recently-cleared-descending",o._recentlyCleared()==="desc")("mat-sort-header-animations-disabled",o._animationsDisabled),rd("tabindex",o._isDisabled()?null:0)("role",o._isDisabled()?null:"button"),db(3),fC(o._renderArrow()?3:-1));},styles:[`.mat-sort-header {
  cursor: pointer;
}

.mat-sort-header-disabled {
  cursor: default;
}

.mat-sort-header-container {
  display: flex;
  align-items: center;
  letter-spacing: normal;
  outline: 0;
}
[mat-sort-header].cdk-keyboard-focused .mat-sort-header-container, [mat-sort-header].cdk-program-focused .mat-sort-header-container {
  border-bottom: solid 1px currentColor;
}
.mat-sort-header-container::before {
  margin: calc(calc(var(--mat-focus-indicator-border-width, 3px) + 2px) * -1);
}

.mat-sort-header-content {
  display: flex;
  align-items: center;
}

.mat-sort-header-position-before {
  flex-direction: row-reverse;
}

@keyframes _mat-sort-header-recently-cleared-ascending {
  from {
    transform: translateY(0);
    opacity: 1;
  }
  to {
    transform: translateY(-25%);
    opacity: 0;
  }
}
@keyframes _mat-sort-header-recently-cleared-descending {
  from {
    transform: translateY(0) rotate(180deg);
    opacity: 1;
  }
  to {
    transform: translateY(25%) rotate(180deg);
    opacity: 0;
  }
}
.mat-sort-header-arrow {
  height: 12px;
  width: 12px;
  position: relative;
  transition: transform 225ms cubic-bezier(0.4, 0, 0.2, 1), opacity 225ms cubic-bezier(0.4, 0, 0.2, 1);
  opacity: 0;
  overflow: visible;
  color: var(--mat-sort-arrow-color, var(--mat-sys-on-surface));
}
.mat-sort-header.cdk-keyboard-focused .mat-sort-header-arrow, .mat-sort-header.cdk-program-focused .mat-sort-header-arrow, .mat-sort-header:hover .mat-sort-header-arrow {
  opacity: 0.54;
}
.mat-sort-header .mat-sort-header-sorted .mat-sort-header-arrow {
  opacity: 1;
}
.mat-sort-header-descending .mat-sort-header-arrow {
  transform: rotate(180deg);
}
.mat-sort-header-recently-cleared-ascending .mat-sort-header-arrow {
  transform: translateY(-25%);
}
.mat-sort-header-recently-cleared-ascending .mat-sort-header-arrow {
  transition: none;
  animation: _mat-sort-header-recently-cleared-ascending 225ms cubic-bezier(0.4, 0, 0.2, 1) forwards;
}
.mat-sort-header-recently-cleared-descending .mat-sort-header-arrow {
  transition: none;
  animation: _mat-sort-header-recently-cleared-descending 225ms cubic-bezier(0.4, 0, 0.2, 1) forwards;
}
.mat-sort-header-animations-disabled .mat-sort-header-arrow {
  transition-duration: 0ms;
  animation-duration: 0ms;
}
.mat-sort-header-arrow > svg, .mat-sort-header-arrow [matSortHeaderIcon] {
  width: 24px;
  height: 24px;
  fill: currentColor;
  position: absolute;
  top: 50%;
  left: 50%;
  margin: -12px 0 0 -12px;
  transform: translateZ(0);
}
.mat-sort-header-arrow, [dir=rtl] .mat-sort-header-position-before .mat-sort-header-arrow {
  margin: 0 0 0 6px;
}
.mat-sort-header-position-before .mat-sort-header-arrow, [dir=rtl] .mat-sort-header-arrow {
  margin: 0 6px 0 0;
}
`],encapsulation:2})}return i})(),wi=(()=>{class i{static \u0275fac=function(t){return new(t||i)};static \u0275mod=Xe({type:i});static \u0275inj=xe({imports:[G8]})}return i})();var St=[[["caption"]],[["colgroup"],["col"]],"*"],xt=["caption","colgroup, col","*"];function Mt(i,s){i&1&&NC(0,2);}function Tt(i,s){i&1&&(Ws(0,"thead",0),cy(1,1),id(),Ws(2,"tbody",2),cy(3,3)(4,4),id(),Ws(5,"tfoot",0),cy(6,5),id());}function Ft(i,s){i&1&&cy(0,1)(1,3)(2,4)(3,5);}var Ii=(()=>{class i extends Ce{stickyCssClass="mat-mdc-table-sticky";needsPositionStickyOnElement=false;static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275cmp=Ql({type:i,selectors:[["mat-table"],["table","mat-table",""]],hostAttrs:[1,"mat-mdc-table","mdc-data-table__table"],hostVars:2,hostBindings:function(t,o){t&2&&Iy("mat-table-fixed-layout",o.fixedLayout);},exportAs:["matTable"],features:[Py([{provide:Ce,useExisting:i},{provide:b,useExisting:i},{provide:K,useValue:null}]),Qm],ngContentSelectors:xt,decls:5,vars:2,consts:[["role","rowgroup"],["headerRowOutlet",""],["role","rowgroup",1,"mdc-data-table__content"],["rowOutlet",""],["noDataRowOutlet",""],["footerRowOutlet",""]],template:function(t,o){t&1&&(AC(St),NC(0),NC(1,1),dC(2,Mt,1,0),dC(3,Tt,7,0)(4,Ft,4,0)),t&2&&(db(2),fC(o._isServer?2:-1),db(),fC(o._isNativeHtmlTable?3:4));},dependencies:[ge,ye,De,we],styles:[`.mat-mdc-table-sticky {
  position: sticky !important;
}

mat-table {
  display: block;
}

mat-header-row {
  min-height: var(--mat-table-header-container-height, 56px);
}

mat-row {
  min-height: var(--mat-table-row-item-container-height, 52px);
}

mat-footer-row {
  min-height: var(--mat-table-footer-container-height, 52px);
}

mat-row, mat-header-row, mat-footer-row {
  display: flex;
  border-width: 0;
  border-bottom-width: 1px;
  border-style: solid;
  align-items: center;
  box-sizing: border-box;
}

mat-cell:first-of-type, mat-header-cell:first-of-type, mat-footer-cell:first-of-type {
  padding-left: 24px;
}
[dir=rtl] mat-cell:first-of-type:not(:only-of-type), [dir=rtl] mat-header-cell:first-of-type:not(:only-of-type), [dir=rtl] mat-footer-cell:first-of-type:not(:only-of-type) {
  padding-left: 0;
  padding-right: 24px;
}
mat-cell:last-of-type, mat-header-cell:last-of-type, mat-footer-cell:last-of-type {
  padding-right: 24px;
}
[dir=rtl] mat-cell:last-of-type:not(:only-of-type), [dir=rtl] mat-header-cell:last-of-type:not(:only-of-type), [dir=rtl] mat-footer-cell:last-of-type:not(:only-of-type) {
  padding-right: 0;
  padding-left: 24px;
}

mat-cell, mat-header-cell, mat-footer-cell {
  flex: 1;
  display: flex;
  align-items: center;
  overflow: hidden;
  word-wrap: break-word;
  min-height: inherit;
}

.mat-mdc-table {
  min-width: 100%;
  border: 0;
  border-spacing: 0;
  table-layout: auto;
  white-space: normal;
  background-color: var(--mat-table-background-color, var(--mat-sys-surface));
}

.mat-table-fixed-layout {
  table-layout: fixed;
}

.mdc-data-table__cell {
  box-sizing: border-box;
  overflow: hidden;
  text-align: start;
  text-overflow: ellipsis;
}

.mdc-data-table__cell,
.mdc-data-table__header-cell {
  padding: 0 16px;
}

.mat-mdc-header-row {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  height: var(--mat-table-header-container-height, 56px);
  color: var(--mat-table-header-headline-color, var(--mat-sys-on-surface, rgba(0, 0, 0, 0.87)));
  font-family: var(--mat-table-header-headline-font, var(--mat-sys-title-small-font, Roboto, sans-serif));
  line-height: var(--mat-table-header-headline-line-height, var(--mat-sys-title-small-line-height));
  font-size: var(--mat-table-header-headline-size, var(--mat-sys-title-small-size, 14px));
  font-weight: var(--mat-table-header-headline-weight, var(--mat-sys-title-small-weight, 500));
}

.mat-mdc-row {
  height: var(--mat-table-row-item-container-height, 52px);
  color: var(--mat-table-row-item-label-text-color, var(--mat-sys-on-surface, rgba(0, 0, 0, 0.87)));
}

.mat-mdc-row,
.mdc-data-table__content {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  font-family: var(--mat-table-row-item-label-text-font, var(--mat-sys-body-medium-font, Roboto, sans-serif));
  line-height: var(--mat-table-row-item-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-table-row-item-label-text-size, var(--mat-sys-body-medium-size, 14px));
  font-weight: var(--mat-table-row-item-label-text-weight, var(--mat-sys-body-medium-weight));
}

.mat-mdc-footer-row {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  height: var(--mat-table-footer-container-height, 52px);
  color: var(--mat-table-row-item-label-text-color, var(--mat-sys-on-surface, rgba(0, 0, 0, 0.87)));
  font-family: var(--mat-table-footer-supporting-text-font, var(--mat-sys-body-medium-font, Roboto, sans-serif));
  line-height: var(--mat-table-footer-supporting-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-table-footer-supporting-text-size, var(--mat-sys-body-medium-size, 14px));
  font-weight: var(--mat-table-footer-supporting-text-weight, var(--mat-sys-body-medium-weight));
  letter-spacing: var(--mat-table-footer-supporting-text-tracking, var(--mat-sys-body-medium-tracking));
}

.mat-mdc-header-cell {
  border-bottom-color: var(--mat-table-row-item-outline-color, var(--mat-sys-outline, rgba(0, 0, 0, 0.12)));
  border-bottom-width: var(--mat-table-row-item-outline-width, 1px);
  border-bottom-style: solid;
  letter-spacing: var(--mat-table-header-headline-tracking, var(--mat-sys-title-small-tracking));
  font-weight: inherit;
  line-height: inherit;
  box-sizing: border-box;
  text-overflow: ellipsis;
  overflow: hidden;
  outline: none;
  text-align: start;
}
.mdc-data-table__row:last-child > .mat-mdc-header-cell {
  border-bottom: none;
}

.mat-mdc-cell {
  border-bottom-color: var(--mat-table-row-item-outline-color, var(--mat-sys-outline, rgba(0, 0, 0, 0.12)));
  border-bottom-width: var(--mat-table-row-item-outline-width, 1px);
  border-bottom-style: solid;
  letter-spacing: var(--mat-table-row-item-label-text-tracking, var(--mat-sys-body-medium-tracking));
  line-height: inherit;
}
.mdc-data-table__row:last-child > .mat-mdc-cell {
  border-bottom: none;
}

.mat-mdc-footer-cell {
  letter-spacing: var(--mat-table-row-item-label-text-tracking, var(--mat-sys-body-medium-tracking));
}

mat-row.mat-mdc-row,
mat-header-row.mat-mdc-header-row,
mat-footer-row.mat-mdc-footer-row {
  border-bottom: none;
}

.mat-mdc-table tbody,
.mat-mdc-table tfoot,
.mat-mdc-table thead,
.mat-mdc-cell,
.mat-mdc-footer-cell,
.mat-mdc-header-row,
.mat-mdc-row,
.mat-mdc-footer-row,
.mat-mdc-table .mat-mdc-header-cell {
  background: inherit;
}

.mat-mdc-table mat-header-row.mat-mdc-header-row,
.mat-mdc-table mat-row.mat-mdc-row,
.mat-mdc-table mat-footer-row.mat-mdc-footer-cell {
  height: unset;
}

mat-header-cell.mat-mdc-header-cell,
mat-cell.mat-mdc-cell,
mat-footer-cell.mat-mdc-footer-cell {
  align-self: stretch;
}
`],encapsulation:2,changeDetection:1})}return i})(),Ni=(()=>{class i extends ne{static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275dir=Me({type:i,selectors:[["","matCellDef",""]],features:[Py([{provide:ne,useExisting:i}]),Qm]})}return i})(),Ai=(()=>{class i extends re{static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275dir=Me({type:i,selectors:[["","matHeaderCellDef",""]],features:[Py([{provide:re,useExisting:i}]),Qm]})}return i})();var Hi=(()=>{class i extends A{get name(){return this._name}set name(e){this._setNameInput(e);}_updateColumnCssClassName(){super._updateColumnCssClassName(),this._columnCssClassName.push(`mat-column-${this.cssClassFriendlyName}`);}static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275dir=Me({type:i,selectors:[["","matColumnDef",""]],inputs:{name:[0,"matColumnDef","name"]},features:[Py([{provide:A,useExisting:i}]),Qm]})}return i})(),Pi=(()=>{class i extends ot{static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275dir=Me({type:i,selectors:[["mat-header-cell"],["th","mat-header-cell",""]],hostAttrs:["role","columnheader",1,"mat-mdc-header-cell","mdc-data-table__header-cell"],features:[Qm]})}return i})();var Bi=(()=>{class i extends nt{static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275dir=Me({type:i,selectors:[["mat-cell"],["td","mat-cell",""]],hostAttrs:[1,"mat-mdc-cell","mdc-data-table__cell"],features:[Qm]})}return i})();var zi=(()=>{class i extends Y{static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275dir=Me({type:i,selectors:[["","matHeaderRowDef",""]],inputs:{columns:[0,"matHeaderRowDef","columns"],sticky:[2,"matHeaderRowDefSticky","sticky",Fr]},features:[Py([{provide:Y,useExisting:i}]),Qm]})}return i})();var Li=(()=>{class i extends se{static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275dir=Me({type:i,selectors:[["","matRowDef",""]],inputs:{columns:[0,"matRowDefColumns","columns"],when:[0,"matRowDefWhen","when"]},features:[Py([{provide:se,useExisting:i}]),Qm]})}return i})(),ji=(()=>{class i extends _e{static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275cmp=Ql({type:i,selectors:[["mat-header-row"],["tr","mat-header-row",""]],hostAttrs:["role","row",1,"mat-mdc-header-row","mdc-data-table__header-row"],exportAs:["matHeaderRow"],features:[Py([{provide:_e,useExisting:i}]),Qm],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,o){t&1&&cy(0,0);},dependencies:[B],encapsulation:2,changeDetection:1})}return i})();var Ui=(()=>{class i extends pe{static \u0275fac=(()=>{let e;return function(o){return (e||(e=dg(i)))(o||i)}})();static \u0275cmp=Ql({type:i,selectors:[["mat-row"],["tr","mat-row",""]],hostAttrs:["role","row",1,"mat-mdc-row","mdc-data-table__row"],exportAs:["matRow"],features:[Py([{provide:pe,useExisting:i}]),Qm],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,o){t&1&&cy(0,0);},dependencies:[B],encapsulation:2,changeDetection:1})}return i})(),Vi=(()=>{class i extends ae{_cellSelector="td, mat-cell, [mat-cell], .mat-cell";constructor(){super(),this._contentClassNames.push("mat-mdc-no-data-row","mat-mdc-row","mdc-data-table__row"),this._cellClassNames.push("mat-mdc-cell","mdc-data-table__cell","mat-no-data-cell");}static \u0275fac=function(t){return new(t||i)};static \u0275dir=Me({type:i,selectors:[["ng-template","matNoDataRow",""]],features:[Py([{provide:ae,useExisting:i}]),Qm]})}return i})();var Qi=(()=>{class i{static \u0275fac=function(t){return new(t||i)};static \u0275mod=Xe({type:i});static \u0275inj=xe({imports:[rt,G8]})}return i})();export{Ai as A,Bi as B,Hi as H,Ii as I,Li as L,Ni as N,Pi as P,Qi as Q,Ui as U,Vi as V,bt as b,gi as g,ji as j,wi as w,zi as z};