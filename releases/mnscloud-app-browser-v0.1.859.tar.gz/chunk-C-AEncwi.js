import {U as U$1}from'./chunk-De-kdOFr.js';import {aH as Fn,aI as Pt,aK as GU,de as xr,c0 as le,aN as je,br as ye,aS as w,aO as Pn,bB as Ns,aP as WT,g,aL as Cy,aX as Ve,aW as wt,df as Os,a$ as Xt,A as Ae,b1 as dS,b2 as Rt,cl as $v,C as Cl,b7 as mb,cc as Al,b8 as yb,ce as Rl,X as XC,a9 as Fm,a0 as Ml,M as XI,_ as JC,E as Tm,bC as dp,cQ as Em}from'./main-YHDHVBF7.js';var V=["*",[["","matSortHeaderIcon",""]]],q=["*","[matSortHeaderIcon]"];function K(e,c){e&1&&(dp(),Al(0,"svg",3),Em(1,"path",4),Rl());}function U(e,c){e&1&&(Al(0,"div",2),yb(1,1,null,K,2,0),Rl());}var L=new w("MAT_SORT_DEFAULT_OPTIONS"),W=(()=>{class e{_defaultOptions;_initializedStream=new xr(1);sortables=new Map;_stateChanges=new le;active;start="asc";get direction(){return this._direction}set direction(t){this._direction=t;}_direction="";disableClear;disabled=false;sortChange=new je;initialized=this._initializedStream;constructor(t){this._defaultOptions=t;}register(t){this.sortables.set(t.id,t);}deregister(t){this.sortables.delete(t.id);}sort(t){this.active!=t.id?(this.active=t.id,this.direction=t.start?t.start:this.start):this.direction=this.getNextSortDirection(t),this.sortChange.emit({active:this.active,direction:this.direction});}getNextSortDirection(t){if(!t)return "";let i=t?.disableClear??this.disableClear??!!this._defaultOptions?.disableClear,r=Z(t.start||this.start,i),n=r.indexOf(this.direction)+1;return n>=r.length&&(n=0),r[n]}ngOnInit(){this._initializedStream.next();}ngOnChanges(){this._stateChanges.next();}ngOnDestroy(){this._stateChanges.complete(),this._initializedStream.complete();}static \u0275fac=function(i){return new(i||e)(ye(L,8))};static \u0275dir=Pn({type:e,selectors:[["","matSort",""]],hostAttrs:[1,"mat-sort"],inputs:{active:[0,"matSortActive","active"],start:[0,"matSortStart","start"],direction:[0,"matSortDirection","direction"],disableClear:[2,"matSortDisableClear","disableClear",WT],disabled:[2,"matSortDisabled","disabled",WT]},outputs:{sortChange:"matSortChange"},exportAs:["matSort"],features:[Ns]})}return e})();function Z(e,c){let t=["asc","desc"];return e=="desc"&&t.reverse(),c||t.push(""),t}var pt=(()=>{class e{_sort=g(W,{optional:true});_columnDef=g(U$1,{optional:true});_changeDetectorRef=g(Cy);_focusMonitor=g(Ve);_elementRef=g(wt);_ariaDescriber=g(Os,{optional:true});_renderChanges;_animationsDisabled=Xt();_recentlyCleared=Ae(null);_sortButton;id;arrowPosition="after";start;disabled=false;get sortActionDescription(){return this._sortActionDescription}set sortActionDescription(t){this._updateSortActionDescription(t);}_sortActionDescription="Sort";disableClear;constructor(){g(dS).load(Rt);let t=g(L,{optional:true});this._sort,t?.arrowPosition&&(this.arrowPosition=t?.arrowPosition);}ngOnInit(){!this.id&&this._columnDef&&(this.id=this._columnDef.name),this._sort.register(this),this._renderChanges=$v(this._sort._stateChanges,this._sort.sortChange).subscribe(()=>this._changeDetectorRef.markForCheck()),this._sortButton=this._elementRef.nativeElement.querySelector(".mat-sort-header-container"),this._updateSortActionDescription(this._sortActionDescription);}ngAfterViewInit(){this._focusMonitor.monitor(this._elementRef,true).subscribe(()=>{Promise.resolve().then(()=>this._recentlyCleared.set(null));});}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef),this._sort.deregister(this),this._renderChanges?.unsubscribe(),this._sortButton&&this._ariaDescriber?.removeDescription(this._sortButton,this._sortActionDescription);}_toggleOnInteraction(){if(!this._isDisabled()){let t=this._isSorted(),i=this._sort.direction;this._sort.sort(this),this._recentlyCleared.set(t&&!this._isSorted()?i:null);}}_handleKeydown(t){(t.keyCode===32||t.keyCode===13)&&(t.preventDefault(),this._toggleOnInteraction());}_isSorted(){return this._sort.active==this.id&&(this._sort.direction==="asc"||this._sort.direction==="desc")}_isDisabled(){return this._sort.disabled||this.disabled}_getAriaSortAttribute(){return this._isSorted()?this._sort.direction=="asc"?"ascending":"descending":"none"}_renderArrow(){return !this._isDisabled()||this._isSorted()}_updateSortActionDescription(t){this._sortButton&&(this._ariaDescriber?.removeDescription(this._sortButton,this._sortActionDescription),this._ariaDescriber?.describe(this._sortButton,t)),this._sortActionDescription=t;}static \u0275fac=function(i){return new(i||e)};static \u0275cmp=Cl({type:e,selectors:[["","mat-sort-header",""]],hostAttrs:[1,"mat-sort-header"],hostVars:3,hostBindings:function(i,r){i&1&&Tm("click",function(){return r._toggleOnInteraction()})("keydown",function(Y){return r._handleKeydown(Y)})("mouseleave",function(){return r._recentlyCleared.set(null)}),i&2&&(Ml("aria-sort",r._getAriaSortAttribute()),Fm("mat-sort-header-disabled",r._isDisabled()));},inputs:{id:[0,"mat-sort-header","id"],arrowPosition:"arrowPosition",start:"start",disabled:[2,"disabled","disabled",WT],sortActionDescription:"sortActionDescription",disableClear:[2,"disableClear","disableClear",WT]},exportAs:["matSortHeader"],ngContentSelectors:q,decls:4,vars:17,consts:[[1,"mat-sort-header-container","mat-focus-indicator"],[1,"mat-sort-header-content"],[1,"mat-sort-header-arrow"],["viewBox","0 -960 960 960","focusable","false","aria-hidden","true"],["d","M440-240v-368L296-464l-56-56 240-240 240 240-56 56-144-144v368h-80Z"]],template:function(i,r){i&1&&(mb(V),Al(0,"div",0)(1,"div",1),yb(2),Rl(),XC(3,U,3,0,"div",2),Rl()),i&2&&(Fm("mat-sort-header-sorted",r._isSorted())("mat-sort-header-position-before",r.arrowPosition==="before")("mat-sort-header-descending",r._sort.direction==="desc")("mat-sort-header-ascending",r._sort.direction==="asc")("mat-sort-header-recently-cleared-ascending",r._recentlyCleared()==="asc")("mat-sort-header-recently-cleared-descending",r._recentlyCleared()==="desc")("mat-sort-header-animations-disabled",r._animationsDisabled),Ml("tabindex",r._isDisabled()?null:0)("role",r._isDisabled()?null:"button"),XI(3),JC(r._renderArrow()?3:-1));},styles:[`.mat-sort-header {
  cursor: pointer;
}

.mat-sort-header-disabled {
  cursor: default;
}

.mat-sort-header-container {
  display: flex;
  align-items: center;
  letter-spacing: normal;
  outline: 0;
}
[mat-sort-header].cdk-keyboard-focused .mat-sort-header-container, [mat-sort-header].cdk-program-focused .mat-sort-header-container {
  border-bottom: solid 1px currentColor;
}
.mat-sort-header-container::before {
  margin: calc(calc(var(--mat-focus-indicator-border-width, 3px) + 2px) * -1);
}

.mat-sort-header-content {
  display: flex;
  align-items: center;
}

.mat-sort-header-position-before {
  flex-direction: row-reverse;
}

@keyframes _mat-sort-header-recently-cleared-ascending {
  from {
    transform: translateY(0);
    opacity: 1;
  }
  to {
    transform: translateY(-25%);
    opacity: 0;
  }
}
@keyframes _mat-sort-header-recently-cleared-descending {
  from {
    transform: translateY(0) rotate(180deg);
    opacity: 1;
  }
  to {
    transform: translateY(25%) rotate(180deg);
    opacity: 0;
  }
}
.mat-sort-header-arrow {
  height: 12px;
  width: 12px;
  position: relative;
  transition: transform 225ms cubic-bezier(0.4, 0, 0.2, 1), opacity 225ms cubic-bezier(0.4, 0, 0.2, 1);
  opacity: 0;
  overflow: visible;
  color: var(--mat-sort-arrow-color, var(--mat-sys-on-surface));
}
.mat-sort-header.cdk-keyboard-focused .mat-sort-header-arrow, .mat-sort-header.cdk-program-focused .mat-sort-header-arrow, .mat-sort-header:hover .mat-sort-header-arrow {
  opacity: 0.54;
}
.mat-sort-header .mat-sort-header-sorted .mat-sort-header-arrow {
  opacity: 1;
}
.mat-sort-header-descending .mat-sort-header-arrow {
  transform: rotate(180deg);
}
.mat-sort-header-recently-cleared-ascending .mat-sort-header-arrow {
  transform: translateY(-25%);
}
.mat-sort-header-recently-cleared-ascending .mat-sort-header-arrow {
  transition: none;
  animation: _mat-sort-header-recently-cleared-ascending 225ms cubic-bezier(0.4, 0, 0.2, 1) forwards;
}
.mat-sort-header-recently-cleared-descending .mat-sort-header-arrow {
  transition: none;
  animation: _mat-sort-header-recently-cleared-descending 225ms cubic-bezier(0.4, 0, 0.2, 1) forwards;
}
.mat-sort-header-animations-disabled .mat-sort-header-arrow {
  transition-duration: 0ms;
  animation-duration: 0ms;
}
.mat-sort-header-arrow > svg, .mat-sort-header-arrow [matSortHeaderIcon] {
  width: 24px;
  height: 24px;
  fill: currentColor;
  position: absolute;
  top: 50%;
  left: 50%;
  margin: -12px 0 0 -12px;
  transform: translateZ(0);
}
.mat-sort-header-arrow, [dir=rtl] .mat-sort-header-position-before .mat-sort-header-arrow {
  margin: 0 0 0 6px;
}
.mat-sort-header-position-before .mat-sort-header-arrow, [dir=rtl] .mat-sort-header-arrow {
  margin: 0 6px 0 0;
}
`],encapsulation:2})}return e})(),gt=(()=>{class e{static \u0275fac=function(i){return new(i||e)};static \u0275mod=Fn({type:e});static \u0275inj=Pt({imports:[GU]})}return e})();export{W,gt as g,pt as p};